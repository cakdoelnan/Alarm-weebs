package com.example.audio

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class AudioStreamInfo(
    val sampleRateHz: Int,
    val bitDepth: Int,
    val codecLabel: String
)

object AudioFormatProbe {
    private const val TAG = "AudioFormatProbe"

    fun probe(
        context: Context,
        uri: Uri,
        mimeType: String,
        fileName: String
    ): AudioStreamInfo {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        val defaultCodec = inferCodecLabel(mimeType, ext)

        // 1. Try fast native header inspection for FLAC and WAV for exact bit depth & sample rate
        try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                when {
                    ext == "flac" || mimeType.contains("flac", ignoreCase = true) -> {
                        parseFlacStreamInfo(stream)?.let { return it }
                    }
                    ext == "wav" || mimeType.contains("wav", ignoreCase = true) -> {
                        parseWavStreamInfo(stream)?.let { return it }
                    }
                    ext == "m4a" || ext == "alac" || ext == "mp4" || mimeType.contains("mp4", ignoreCase = true) -> {
                        parseMp4AlacOrAacInfo(stream, defaultCodec)?.let { return it }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Header probe fallback for $fileName: ${e.message}")
        }

        // 2. Fallback to Android MediaExtractor
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    val sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    } else 44100

                    val pcmEncoding = if (format.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                        format.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    } else -1

                    val bitDepth = when (pcmEncoding) {
                        android.media.AudioFormat.ENCODING_PCM_8BIT -> 8
                        android.media.AudioFormat.ENCODING_PCM_16BIT -> 16
                        android.media.AudioFormat.ENCODING_PCM_24BIT_PACKED -> 24
                        android.media.AudioFormat.ENCODING_PCM_32BIT -> 32
                        android.media.AudioFormat.ENCODING_PCM_FLOAT -> 32
                        else -> if (mime.contains("alac") || mime.contains("flac")) 24 else 16
                    }

                    val codec = when {
                        mime.contains("alac") -> "ALAC"
                        mime.contains("flac") -> "FLAC"
                        mime.contains("raw") -> "WAV"
                        mime.contains("mp4a") -> "AAC"
                        mime.contains("mpeg") -> "MP3"
                        mime.contains("opus") -> "OPUS"
                        mime.contains("vorbis") -> "OGG"
                        else -> defaultCodec
                    }
                    return AudioStreamInfo(sampleRate, bitDepth, codec)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "MediaExtractor probe failed for $fileName: ${e.message}")
        } finally {
            runCatching { extractor.release() }
        }

        return AudioStreamInfo(
            sampleRateHz = 44100,
            bitDepth = if (defaultCodec == "FLAC" || defaultCodec == "ALAC") 24 else 16,
            codecLabel = defaultCodec
        )
    }

    fun inferCodecLabel(mimeType: String, ext: String): String {
        val m = mimeType.lowercase()
        return when {
            ext == "flac" || m.contains("flac") -> "FLAC"
            ext == "alac" || m.contains("alac") -> "ALAC"
            ext == "wav" || m.contains("wav") || m.contains("x-wav") -> "WAV"
            ext == "m4a" || ext == "aac" || m.contains("mp4") || m.contains("aac") -> "M4A"
            ext == "mp3" || m.contains("mpeg") -> "MP3"
            ext == "opus" || m.contains("opus") -> "OPUS"
            ext == "ogg" || m.contains("ogg") -> "OGG"
            else -> ext.uppercase().ifBlank { "AUDIO" }
        }
    }

    internal fun parseFlacStreamInfo(input: InputStream): AudioStreamInfo? {
        val header = ByteArray(42)
        if (!readFully(input, header)) return null
        if (header[0] != 'f'.code.toByte() ||
            header[1] != 'L'.code.toByte() ||
            header[2] != 'a'.code.toByte() ||
            header[3] != 'C'.code.toByte()
        ) return null

        val blockType = header[4].toInt() and 0x7F
        if (blockType != 0) return null // STREAMINFO must be first block

        // STREAMINFO bytes start at index 8 (34 bytes).
        // Bytes 10..13 inside STREAMINFO (index 18..21 in header):
        // 20 bits sampleRate, 3 bits (channels - 1), 5 bits (bitsPerSample - 1), 36 bits totalSamples
        val b0 = header[18].toInt() and 0xFF
        val b1 = header[19].toInt() and 0xFF
        val b2 = header[20].toInt() and 0xFF
        val b3 = header[21].toInt() and 0xFF

        val sampleRate = (b0 shl 12) or (b1 shl 4) or (b2 ushr 4)
        val bitsPerSample = (((b2 and 0x01) shl 4) or (b3 ushr 4)) + 1

        if (sampleRate <= 0) return null
        return AudioStreamInfo(
            sampleRateHz = sampleRate,
            bitDepth = bitsPerSample.coerceIn(8, 32),
            codecLabel = "FLAC"
        )
    }

    internal fun parseWavStreamInfo(input: InputStream): AudioStreamInfo? {
        val riff = ByteArray(12)
        if (!readFully(input, riff)) return null
        if (String(riff, 0, 4, Charsets.US_ASCII) != "RIFF" ||
            String(riff, 8, 4, Charsets.US_ASCII) != "WAVE"
        ) return null

        var scanned = 0
        val chunkHeader = ByteArray(8)
        while (scanned < 1024 * 256 && readFully(input, chunkHeader)) {
            val id = String(chunkHeader, 0, 4, Charsets.US_ASCII)
            val size = ByteBuffer.wrap(chunkHeader, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL
            if (id == "fmt " && size >= 16) {
                val fmt = ByteArray(16)
                if (!readFully(input, fmt)) return null
                val bb = ByteBuffer.wrap(fmt).order(ByteOrder.LITTLE_ENDIAN)
                bb.short // audioFormat
                bb.short // numChannels
                val sampleRate = bb.int
                bb.int // byteRate
                bb.short // blockAlign
                val bitsPerSample = bb.short.toInt() and 0xFFFF
                if (sampleRate > 0) {
                    return AudioStreamInfo(
                        sampleRateHz = sampleRate,
                        bitDepth = bitsPerSample.coerceIn(8, 32),
                        codecLabel = "WAV"
                    )
                }
                return null
            } else {
                val skipCount = if (size % 2L == 1L) size + 1L else size
                if (skipCount <= 0) break
                skipFully(input, skipCount)
                scanned += 8 + skipCount.toInt()
            }
        }
        return null
    }

    private fun parseMp4AlacOrAacInfo(input: InputStream, fallbackCodec: String): AudioStreamInfo? {
        // Lightweight scan of first 256KB for 'alac' magic atom inside stsd if present
        val buf = ByteArray(256 * 1024)
        var totalRead = 0
        while (totalRead < buf.size) {
            val r = input.read(buf, totalRead, buf.size - totalRead)
            if (r <= 0) break
            totalRead += r
        }
        if (totalRead < 32) return null

        // Look for "alac" sample entry followed by ALACSpecificConfig (24 bytes):
        // frameLength(4), compatibleVersion(1), bitDepth(1), pb(1), mb(1), kb(1), numChannels(1), maxRun(2), maxFrameBytes(4), avgBitRate(4), sampleRate(4)
        for (i in 0 until totalRead - 36) {
            if (buf[i] == 'a'.code.toByte() &&
                buf[i + 1] == 'l'.code.toByte() &&
                buf[i + 2] == 'a'.code.toByte() &&
                buf[i + 3] == 'c'.code.toByte()
            ) {
                // In MP4 stsd, 'alac' SampleEntry has 28 bytes header + inner 'alac' box (4 size + 4 'alac' + 4 versionFlags + 24 config)
                val innerIndex = i + 28
                if (innerIndex + 36 <= totalRead &&
                    buf[innerIndex + 4] == 'a'.code.toByte() &&
                    buf[innerIndex + 5] == 'l'.code.toByte() &&
                    buf[innerIndex + 6] == 'a'.code.toByte() &&
                    buf[innerIndex + 7] == 'c'.code.toByte()
                ) {
                    val configStart = innerIndex + 12
                    val bitDepth = buf[configStart + 5].toInt() and 0xFF
                    val sampleRate = ByteBuffer.wrap(buf, configStart + 20, 4).order(ByteOrder.BIG_ENDIAN).int
                    if (sampleRate in 8000..768000 && bitDepth in listOf(16, 20, 24, 32)) {
                        return AudioStreamInfo(sampleRate, bitDepth, "ALAC")
                    }
                }
            }
        }
        return null.takeIf { fallbackCodec != "ALAC" }
    }

    private fun readFully(input: InputStream, buffer: ByteArray): Boolean {
        var offset = 0
        while (offset < buffer.size) {
            val read = input.read(buffer, offset, buffer.size - offset)
            if (read <= 0) return false
            offset += read
        }
        return true
    }

    private fun skipFully(input: InputStream, bytes: Long) {
        var remaining = bytes
        while (remaining > 0) {
            val skipped = input.skip(remaining)
            if (skipped <= 0) {
                if (input.read() == -1) break
                remaining--
            } else {
                remaining -= skipped
            }
        }
    }
}
