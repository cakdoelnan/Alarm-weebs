package com.example.data

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import android.util.Size
import androidx.palette.graphics.Palette
import com.example.audio.AudioFormatProbe
import com.example.model.Album
import com.example.model.Artist
import com.example.model.MusicFolder
import com.example.model.PaletteColors
import com.example.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class LibraryScanResult(
    val tracks: List<Track> = emptyList(),
    val albums: List<Album> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val folders: List<MusicFolder> = emptyList()
)

class MediaLibraryRepository(private val context: Context) {

    private val supportedExtensions = setOf("flac", "alac", "wav", "m4a", "mp3", "aac", "ogg", "opus")

    suspend fun scanLibrary(): LibraryScanResult = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<Track>()

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DISPLAY_NAME
        )

        val selection = "${MediaStore.Audio.Media.DURATION} >= 1000"
        val sortOrder = "${MediaStore.Audio.Media.ALBUM} ASC, ${MediaStore.Audio.Media.TRACK} ASC, ${MediaStore.Audio.Media.TITLE} ASC"

        runCatching {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val trackCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                val yearCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val displayCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val filePath = cursor.getString(dataCol).orEmpty()
                    val displayName = cursor.getString(displayCol).orEmpty()
                    val mimeType = cursor.getString(mimeCol).orEmpty()
                    val ext = (filePath.ifBlank { displayName }).substringAfterLast('.', "").lowercase()

                    if (ext !in supportedExtensions && !mimeType.startsWith("audio/")) continue

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val albumId = cursor.getLong(albumIdCol)
                    val albumArtUri = ContentUris.withAppendedId(
                        Uri.parse("content://media/external/audio/albumart"),
                        albumId
                    )

                    val fileObj = filePath.takeIf { it.isNotBlank() }?.let(::File)
                    val folderPath = fileObj?.parent ?: "/Music"
                    val folderName = fileObj?.parentFile?.name?.ifBlank { "Music" } ?: "Music"

                    val streamInfo = AudioFormatProbe.probe(
                        context = context,
                        uri = contentUri,
                        mimeType = mimeType,
                        fileName = displayName.ifBlank { filePath }
                    )

                    val rawTitle = cursor.getString(titleCol).orEmpty()
                    val title = rawTitle.ifBlank {
                        displayName.substringBeforeLast('.').ifBlank { "Unknown Track" }
                    }
                    val artist = cursor.getString(artistCol)
                        ?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: "Unknown Artist"
                    val album = cursor.getString(albumCol)
                        ?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: folderName
                    val rawTrackNum = cursor.getInt(trackCol)
                    val normalizedTrackNum = if (rawTrackNum >= 1000) rawTrackNum % 1000 else rawTrackNum

                    tracks.add(
                        Track(
                            id = id,
                            contentUriString = contentUri.toString(),
                            title = title,
                            artist = artist,
                            album = album,
                            albumId = albumId,
                            albumArtUri = albumArtUri,
                            durationMs = cursor.getLong(durationCol).coerceAtLeast(0L),
                            trackNumber = normalizedTrackNum,
                            year = cursor.getInt(yearCol),
                            mimeType = mimeType,
                            filePath = filePath,
                            folderName = folderName,
                            folderPath = folderPath,
                            sampleRateHz = streamInfo.sampleRateHz,
                            bitDepth = streamInfo.bitDepth,
                            codecLabel = streamInfo.codecLabel
                        )
                    )
                }
            }
        }

        buildLibraryResult(tracks)
    }

    suspend fun loadTrackFromUri(uri: Uri): Track? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "Audio Track"
            val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                ?.takeIf { it.isNotBlank() } ?: fileName.substringBeforeLast('.')
            val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                ?.takeIf { it.isNotBlank() } ?: "Unknown Artist"
            val album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
                ?.takeIf { it.isNotBlank() } ?: "Direct File"
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val mimeType = context.contentResolver.getType(uri).orEmpty()
            val streamInfo = AudioFormatProbe.probe(context, uri, mimeType, fileName)

            Track(
                id = uri.toString().hashCode().toLong(),
                contentUriString = uri.toString(),
                title = title,
                artist = artist,
                album = album,
                albumId = album.hashCode().toLong(),
                albumArtUri = null,
                durationMs = durationMs,
                trackNumber = 1,
                year = 0,
                mimeType = mimeType,
                filePath = uri.path.orEmpty(),
                folderName = "Opened Files",
                folderPath = uri.path.orEmpty(),
                sampleRateHz = streamInfo.sampleRateHz,
                bitDepth = streamInfo.bitDepth,
                codecLabel = streamInfo.codecLabel
            )
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    fun buildLibraryResult(tracks: List<Track>): LibraryScanResult {
        val albums = tracks.groupBy { it.albumId to it.album }
            .map { (key, albumTracks) ->
                val sortedTracks = albumTracks.sortedWith(
                    compareBy<Track> { if (it.trackNumber <= 0) Int.MAX_VALUE else it.trackNumber }
                        .thenBy { it.title }
                )
                val first = sortedTracks.first()
                Album(
                    id = key.first,
                    title = key.second,
                    artist = first.artist,
                    artworkUri = first.albumArtUri,
                    year = first.year,
                    tracks = sortedTracks
                )
            }
            .sortedBy { it.title.lowercase() }

        val artists = tracks.groupBy { it.artist }
            .map { (artistName, artistTracks) ->
                val artistAlbums = albums.filter { alb ->
                    artistTracks.any { it.albumId == alb.id }
                }
                Artist(
                    name = artistName,
                    albums = artistAlbums,
                    tracks = artistTracks.sortedBy { it.title.lowercase() }
                )
            }
            .sortedBy { it.name.lowercase() }

        val folders = tracks.groupBy { it.folderPath }
            .map { (path, folderTracks) ->
                val name = folderTracks.first().folderName
                MusicFolder(
                    name = name,
                    path = path,
                    tracks = folderTracks.sortedBy { it.title.lowercase() }
                )
            }
            .sortedBy { it.name.lowercase() }

        return LibraryScanResult(
            tracks = tracks,
            albums = albums,
            artists = artists,
            folders = folders
        )
    }

    suspend fun extractPaletteColors(track: Track): PaletteColors = withContext(Dispatchers.IO) {
        val bitmap = loadAlbumBitmap(track) ?: return@withContext PaletteColors()
        try {
            val palette = Palette.from(bitmap).maximumColorCount(16).generate()
            val c1 = palette.getVibrantColor(
                palette.getDominantColor(0xFFFA2D48.toInt())
            )
            val c2 = palette.getDarkVibrantColor(
                palette.getMutedColor(0xFF5A183D.toInt())
            )
            val c3 = palette.getLightVibrantColor(
                palette.getDarkMutedColor(0xFF1E3A5F.toInt())
            )
            val c4 = palette.getDarkMutedColor(0xFF0D0D16.toInt())
            PaletteColors(c1, c2, c3, c4)
        } finally {
            bitmap.recycle()
        }
    }

    private fun loadAlbumBitmap(track: Track): Bitmap? {
        // 1. Try MediaStore thumbnail first to avoid noisy JNI failures on artless tracks
        runCatching {
            context.contentResolver.loadThumbnail(track.contentUri, Size(256, 256), null)
        }.getOrNull()?.let { return it }

        // 2. Fallback to embedded artwork via MediaMetadataRetriever (handles FLAC, M4A/ALAC, MP3)
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(context, track.contentUri)
            val hasImage = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_IMAGE)
            if (hasImage != null && !hasImage.equals("yes", ignoreCase = true)) {
                return null
            }
            val pic = mmr.embeddedPicture
            if (pic != null && pic.isNotEmpty()) {
                val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
                BitmapFactory.decodeByteArray(pic, 0, pic.size, opts)?.let { return it }
            }
        } catch (_: Exception) {
        } finally {
            runCatching { mmr.release() }
        }

        return null
    }
}
