package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AppleMusicRed = Color(0xFFFA2D48)
val AppleMusicRose = AppleMusicRed
val AppleMusicCrimson = Color(0xFFD91E3A)
val BitPerfectGold = Color(0xFFF5C451)
val BitPerfectEmerald = Color(0xFF30D158)

// OLED Pure Black & iOS 27 BitChord Surface Tokens
val PureBlack = Color(0xFF000000)
val IosGroupedBg = Color(0xFF161618)
val IosGroupedElevated = Color(0xFF242428)
val IosSeparator = Color(0xFF2C2C2E)
val IosSecondaryGray = Color(0xFF8E8E93)
val IosTertiaryGray = Color(0xFF636366)

val ObsidianBg = PureBlack
val ObsidianSurface = IosGroupedBg
val ObsidianSurfaceElevated = IosGroupedElevated

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = IosSecondaryGray
val TextTertiary = IosTertiaryGray

// Preset Accent Palette for Custom Picker
data class AccentPreset(val name: String, val argb: Long)

val AccentColorPresets = listOf(
    AccentPreset("Apple Red", 0xFFFA2D48),
    AccentPreset("Sakura Pink", 0xFFFF6B9E),
    AccentPreset("Ocean Blue", 0xFF0A84FF),
    AccentPreset("Violet", 0xFFBF5AF2),
    AccentPreset("Emerald", 0xFF30D158),
    AccentPreset("Amber", 0xFFFF9F0A)
)
