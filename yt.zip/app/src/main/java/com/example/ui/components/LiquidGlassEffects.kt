package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Usb
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.model.AudioOutputState
import com.example.model.BlurMode
import com.example.ui.theme.BitPerfectEmerald
import com.example.ui.theme.IosGroupedBg
import com.example.ui.theme.IosSeparator
import com.example.ui.theme.LocalAccentColor
import com.example.ui.theme.PureBlack
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeEffect
import kotlin.math.cos
import kotlin.math.sin

/**
 * Applies real Haze frosted glass blur when BlurMode allows it, with optional Liquid Glass
 * specular inner-border (0.5.dp). Falls back cleanly to static frosted or solid OLED #000000.
 */
@Composable
fun Modifier.sonoraFrostedGlass(
    hazeState: HazeState?,
    blurMode: BlurMode,
    liquidGlassEnabled: Boolean,
    shape: Shape,
    tintColor: Color = Color(0x9E0C0C10),
    blurRadius: Dp = 24.dp
): Modifier {
    val base = this.clip(shape)
    val blurred = when {
        blurMode == BlurMode.LIQUID_GLASS && hazeState != null -> {
            base.hazeEffect(state = hazeState) {
                backgroundColor = PureBlack
                this.blurRadius = blurRadius
                tints = listOf(HazeTint(tintColor))
            }
        }
        blurMode == BlurMode.STATIC_FROSTED -> {
            base.background(Color(0xE0141418))
        }
        else -> {
            base.background(Color(0xF50A0A0C))
        }
    }

    return if (liquidGlassEnabled && blurMode != BlurMode.SOLID_DARK) {
        blurred
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.07f),
                        Color.Transparent
                    )
                )
            )
            .border(
                width = 0.5.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.28f),
                        Color.White.copy(alpha = 0.08f),
                        Color.White.copy(alpha = 0.16f)
                    )
                ),
                shape = shape
            )
    } else {
        blurred.border(0.5.dp, IosSeparator.copy(alpha = 0.7f), shape)
    }
}

/**
 * BitChord / Apple Music Now Playing Full-Screen Background:
 * Uses the active album cover scaled 1.5x+, blurred heavily (70.dp),
 * and drifting slowly behind a deep dark frosted veil.
 */
@Composable
fun NowPlayingAlbumBlurBackground(
    artworkUri: Any?,
    blurMode: BlurMode,
    modifier: Modifier = Modifier
) {
    if (blurMode == BlurMode.SOLID_DARK) {
        Box(modifier = modifier.fillMaxSize().background(PureBlack))
        return
    }

    val infiniteTransition = rememberInfiniteTransition(label = "now_playing_drift")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (Math.PI * 2.0).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 28000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "drift_phase"
    )

    val driftX = if (blurMode == BlurMode.LIQUID_GLASS) cos(phase) * 32f else 0f
    val driftY = if (blurMode == BlurMode.LIQUID_GLASS) sin(phase * 0.8f) * 28f else 0f

    Box(modifier = modifier.fillMaxSize().background(PureBlack)) {
        AlbumArtworkImage(
            artworkUri = artworkUri,
            contentDescription = null,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = 1.55f
                    scaleY = 1.55f
                    translationX = driftX
                    translationY = driftY
                }
                .blur(70.dp)
        )

        // Moody dark readability veil so white typography & controls stay crisp
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.44f),
                            Color.Black.copy(alpha = 0.56f),
                            Color.Black.copy(alpha = 0.76f)
                        )
                    )
                )
        )
    }
}

/**
 * iOS 27 Grouped Inset Card (#161618, 16.dp corner radius, zero rigid borders).
 */
@Composable
fun IosGroupedContainer(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(16.dp),
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(IosGroupedBg),
        content = content
    )
}

@Composable
fun IosThinDivider(
    modifier: Modifier = Modifier
) {
    HorizontalDivider(
        thickness = 0.5.dp,
        color = IosSeparator,
        modifier = modifier
    )
}

/**
 * Apple Music / BitChord Top Header Bar backed by real Haze frosted glass blur:
 * Large Bold White Title (32.sp) on left + small circular profile/DAC avatar on right.
 */
@Composable
fun AppleMusicPageHeader(
    title: String,
    audioOutputState: AudioOutputState,
    blurMode: BlurMode,
    hazeState: HazeState,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = LocalAccentColor.current
    val headerModifier = if (blurMode == BlurMode.LIQUID_GLASS) {
        Modifier
            .fillMaxWidth()
            .hazeEffect(state = hazeState) {
                backgroundColor = PureBlack
                blurRadius = 22.dp
                tints = listOf(HazeTint(Color(0xAD000000)))
            }
    } else {
        Modifier
            .fillMaxWidth()
            .background(
                if (blurMode == BlurMode.STATIC_FROSTED) Color(0xDB000000) else PureBlack
            )
    }

    Box(modifier = modifier.then(headerModifier)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.displaySmall,
                color = Color.White
            )

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(IosGroupedBg)
                    .border(
                        width = 0.5.dp,
                        color = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald.copy(alpha = 0.8f)
                        else Color.White.copy(alpha = 0.14f),
                        shape = CircleShape
                    )
                    .clickable(onClick = onProfileClick)
                    .testTag("top_profile_avatar_btn"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (audioOutputState.isUsbDacConnected) Icons.Rounded.Usb else Icons.Rounded.Person,
                    contentDescription = if (audioOutputState.isUsbDacConnected) audioOutputState.modeLabel else "Profile & Appearance",
                    tint = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else accent,
                    modifier = Modifier.size(19.dp)
                )
            }
        }
    }
}

@Composable
fun AlbumArtworkImage(
    artworkUri: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop
) {
    AsyncImage(
        model = ImageRequest.Builder(LocalContext.current)
            .data(artworkUri ?: R.drawable.img_default_album_art)
            .crossfade(true)
            .build(),
        placeholder = painterResource(id = R.drawable.img_default_album_art),
        error = painterResource(id = R.drawable.img_default_album_art),
        contentDescription = contentDescription,
        contentScale = contentScale,
        modifier = modifier
    )
}
