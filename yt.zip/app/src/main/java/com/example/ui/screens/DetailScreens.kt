package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.LibraryScanResult
import com.example.model.BlurMode
import com.example.model.PlaybackMode
import com.example.model.Track
import com.example.ui.DetailDestination
import com.example.ui.components.AlbumArtworkImage
import com.example.ui.components.IosThinDivider
import com.example.ui.theme.IosGroupedBg
import com.example.ui.theme.IosSecondaryGray
import com.example.ui.theme.LocalAccentColor
import com.example.ui.theme.PureBlack
import androidx.compose.runtime.remember
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeEffect
import dev.chrisbanes.haze.hazeSource

@Composable
fun DetailScreenHost(
    destination: DetailDestination,
    library: LibraryScanResult,
    blurMode: BlurMode,
    currentTrackId: Long?,
    bottomContentPadding: Dp,
    onBack: () -> Unit,
    onPlayTracks: (List<Track>, Int, PlaybackMode?) -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = LocalAccentColor.current
    val detailHazeState = remember { HazeState() }

    val title: String
    val subtitle: String
    val artworkUri: Any?
    val tracks: List<Track>

    when (destination) {
        is DetailDestination.AlbumDetail -> {
            val album = library.albums.firstOrNull { it.id == destination.albumId }
            title = album?.title ?: "Album"
            subtitle = album?.let { "${it.artist} • ${it.tracks.size} tracks" } ?: ""
            artworkUri = album?.artworkUri
            tracks = album?.tracks.orEmpty()
        }

        is DetailDestination.ArtistDetail -> {
            val artist = library.artists.firstOrNull { it.name == destination.artistName }
            title = artist?.name ?: destination.artistName
            subtitle = artist?.let { "${it.albums.size} albums • ${it.tracks.size} tracks" } ?: ""
            artworkUri = artist?.albums?.firstOrNull()?.artworkUri
            tracks = artist?.tracks.orEmpty()
        }

        is DetailDestination.FolderDetail -> {
            val folder = library.folders.firstOrNull { it.path == destination.folderPath }
            title = folder?.name ?: "Folder"
            subtitle = folder?.path ?: destination.folderPath
            artworkUri = folder?.tracks?.firstOrNull()?.albumArtUri
            tracks = folder?.tracks.orEmpty()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
    ) {
        LazyColumn(
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = 98.dp,
                bottom = bottomContentPadding
            ),
            modifier = Modifier
                .fillMaxSize()
                .hazeSource(state = detailHazeState)
        ) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (destination is DetailDestination.FolderDetail) {
                        Box(
                            modifier = Modifier
                                .size(160.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(IosGroupedBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Folder,
                                contentDescription = title,
                                tint = accent,
                                modifier = Modifier.size(68.dp)
                            )
                        }
                    } else {
                        AlbumArtworkImage(
                            artworkUri = artworkUri,
                            contentDescription = title,
                            modifier = Modifier
                                .size(220.dp)
                                .shadow(20.dp, RoundedCornerShape(16.dp), ambientColor = Color.Black, spotColor = Color.Black)
                                .clip(RoundedCornerShape(16.dp))
                        )
                    }

                    Spacer(Modifier.height(16.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = IosSecondaryGray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                if (tracks.isNotEmpty()) {
                                    onPlayTracks(tracks, 0, PlaybackMode.NORMAL)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = IosGroupedBg,
                                contentColor = accent
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("detail_play_all_btn")
                        ) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Play", fontWeight = FontWeight.SemiBold)
                        }

                        Button(
                            onClick = {
                                if (tracks.isNotEmpty()) {
                                    onPlayTracks(
                                        tracks,
                                        0,
                                        PlaybackMode.SMART_CROSS_ALBUM_SHUFFLE
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = IosGroupedBg,
                                contentColor = accent
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("detail_shuffle_btn")
                        ) {
                            Icon(Icons.Rounded.Shuffle, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Shuffle", fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    IosThinDivider()
                }
            }

            itemsIndexed(tracks, key = { idx, t -> "${t.id}_$idx" }) { index, track ->
                CleanAppleTrackRow(
                    track = track,
                    isPlayingCurrent = track.id == currentTrackId,
                    onClick = { onPlayTracks(tracks, index, null) }
                )
                if (index < tracks.lastIndex) {
                    IosThinDivider(modifier = Modifier.padding(start = 64.dp))
                }
            }
        }

        // Real Haze Frosted Top Header
        val topBarModifier = if (blurMode == BlurMode.LIQUID_GLASS) {
            Modifier
                .fillMaxWidth()
                .hazeEffect(state = detailHazeState) {
                    backgroundColor = PureBlack
                    blurRadius = 22.dp
                    tints = listOf(HazeTint(Color(0xAD000000)))
                }
        } else {
            Modifier
                .fillMaxWidth()
                .background(if (blurMode == BlurMode.STATIC_FROSTED) Color(0xDB000000) else PureBlack)
        }

        Box(modifier = topBarModifier.align(Alignment.TopCenter)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(IosGroupedBg.copy(alpha = 0.85f))
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("detail_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = accent
                        )
                    }
                }
                Spacer(Modifier.width(12.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
