package com.example.ui

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.data.LibraryScanResult
import com.example.data.UserSettings
import com.example.model.AccentColorMode
import com.example.model.Album
import com.example.model.Artist
import com.example.model.AudioOutputState
import com.example.model.BlurMode
import com.example.model.MusicFolder
import com.example.model.PlaybackMode
import com.example.model.SleepTimerOption
import com.example.model.SleepTimerState
import com.example.model.Track
import com.example.player.PlayerSnapshot
import com.example.player.SonoraPlaybackCoordinator
import com.example.service.SonoraPlaybackService
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class RootTab {
    HOME,
    LIBRARY,
    FOLDERS,
    SETTINGS
}

enum class LibrarySubTab {
    ALBUMS,
    ARTISTS,
    SONGS
}

sealed interface DetailDestination {
    data class AlbumDetail(val albumId: Long) : DetailDestination
    data class ArtistDetail(val artistName: String) : DetailDestination
    data class FolderDetail(val folderPath: String) : DetailDestination
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val coordinator = SonoraPlaybackCoordinator.getInstance(application)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    private val _hasAudioPermission = MutableStateFlow(false)
    val hasAudioPermission: StateFlow<Boolean> = _hasAudioPermission.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _selectedRootTab = MutableStateFlow(RootTab.HOME)
    val selectedRootTab: StateFlow<RootTab> = _selectedRootTab.asStateFlow()

    private val _selectedLibrarySubTab = MutableStateFlow(LibrarySubTab.ALBUMS)
    val selectedLibrarySubTab: StateFlow<LibrarySubTab> = _selectedLibrarySubTab.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _detailStack = MutableStateFlow<List<DetailDestination>>(emptyList())
    val detailStack: StateFlow<List<DetailDestination>> = _detailStack.asStateFlow()

    private val _isNowPlayingExpanded = MutableStateFlow(false)
    val isNowPlayingExpanded: StateFlow<Boolean> = _isNowPlayingExpanded.asStateFlow()

    val playerSnapshot: StateFlow<PlayerSnapshot> = coordinator.playerSnapshot
    val settings: StateFlow<UserSettings> = coordinator.settings
    val audioOutputState: StateFlow<AudioOutputState> = coordinator.audioOutputState
    val sleepTimerState: StateFlow<SleepTimerState> = coordinator.sleepTimerState
    val rawLibrary: StateFlow<LibraryScanResult> = coordinator.library

    val filteredLibrary: StateFlow<LibraryScanResult> = combine(
        coordinator.library,
        _searchQuery
    ) { lib, query ->
        val q = query.trim().lowercase()
        if (q.isEmpty()) {
            lib
        } else {
            val matchingTracks = lib.tracks.filter {
                it.title.lowercase().contains(q) ||
                    it.artist.lowercase().contains(q) ||
                    it.album.lowercase().contains(q) ||
                    it.folderName.lowercase().contains(q) ||
                    it.codecLabel.lowercase().contains(q)
            }
            val matchingAlbums = lib.albums.filter {
                it.title.lowercase().contains(q) ||
                    it.artist.lowercase().contains(q) ||
                    it.tracks.any { t -> t.title.lowercase().contains(q) }
            }
            val matchingArtists = lib.artists.filter {
                it.name.lowercase().contains(q) ||
                    it.tracks.any { t -> t.title.lowercase().contains(q) }
            }
            val matchingFolders = lib.folders.filter {
                it.name.lowercase().contains(q) ||
                    it.path.lowercase().contains(q) ||
                    it.tracks.any { t -> t.title.lowercase().contains(q) }
            }
            LibraryScanResult(
                tracks = matchingTracks,
                albums = matchingAlbums,
                artists = matchingArtists,
                folders = matchingFolders
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LibraryScanResult())

    fun connectMediaService() {
        if (controllerFuture != null) return
        val context = getApplication<Application>()
        val token = SessionToken(context, ComponentName(context, SonoraPlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        controllerFuture = future
        future.addListener({
            runCatching { future.get() }
        }, MoreExecutors.directExecutor())
    }

    fun disconnectMediaService() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
    }

    fun onPermissionStatusChanged(granted: Boolean) {
        _hasAudioPermission.value = granted
        if (granted && coordinator.library.value.tracks.isEmpty()) {
            rescanLibrary()
        }
    }

    fun rescanLibrary() {
        viewModelScope.launch {
            _isScanning.value = true
            coordinator.scanMediaLibrary()
            _isScanning.value = false
        }
    }

    fun openExternalAudioUri(uri: Uri) {
        viewModelScope.launch {
            coordinator.openExternalUri(uri)?.let {
                _isNowPlayingExpanded.value = true
            }
        }
    }

    fun selectRootTab(tab: RootTab) {
        _selectedRootTab.value = tab
        _detailStack.value = emptyList()
    }

    fun openLibraryWithSubTab(subTab: LibrarySubTab) {
        _selectedLibrarySubTab.value = subTab
        _selectedRootTab.value = RootTab.LIBRARY
        _detailStack.value = emptyList()
    }

    fun selectLibrarySubTab(subTab: LibrarySubTab) {
        _selectedLibrarySubTab.value = subTab
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun openAlbum(album: Album) {
        _detailStack.value = _detailStack.value + DetailDestination.AlbumDetail(album.id)
    }

    fun openArtist(artist: Artist) {
        _detailStack.value = _detailStack.value + DetailDestination.ArtistDetail(artist.name)
    }

    fun openFolder(folder: MusicFolder) {
        _detailStack.value = _detailStack.value + DetailDestination.FolderDetail(folder.path)
    }

    fun popDetail() {
        val current = _detailStack.value
        if (current.isNotEmpty()) {
            _detailStack.value = current.dropLast(1)
        }
    }

    fun setNowPlayingExpanded(expanded: Boolean) {
        _isNowPlayingExpanded.value = expanded
    }

    fun playTracks(tracks: List<Track>, startIndex: Int, openNowPlaying: Boolean = true) {
        coordinator.playQueue(tracks, startIndex)
        if (openNowPlaying) {
            _isNowPlayingExpanded.value = true
        }
    }

    fun jumpToQueueIndex(index: Int) = coordinator.jumpToQueueIndex(index)
    fun togglePlayPause() = coordinator.togglePlayPause()
    fun skipToNext() = coordinator.skipToNext()
    fun skipToPrevious() = coordinator.skipToPrevious()
    fun seekTo(positionMs: Long) = coordinator.seekTo(positionMs)
    fun cyclePlaybackMode() = coordinator.cyclePlaybackMode()
    fun setPlaybackMode(mode: PlaybackMode) = coordinator.setPlaybackMode(mode)
    fun setBlurMode(mode: BlurMode) = coordinator.setBlurMode(mode)
    fun setLiquidGlassEnabled(enabled: Boolean) = coordinator.setLiquidGlassEnabled(enabled)
    fun setAccentColorMode(mode: AccentColorMode) = coordinator.setAccentColorMode(mode)
    fun setCustomAccentArgb(argb: Long) = coordinator.setCustomAccentArgb(argb)
    fun setLyricsAutoScroll(enabled: Boolean) = coordinator.setLyricsAutoScroll(enabled)
    fun setLyricsBlurEnabled(enabled: Boolean) = coordinator.setLyricsBlurEnabled(enabled)
    fun setSleepTimer(option: SleepTimerOption) = coordinator.setSleepTimer(option)
    fun refreshAudioRouting() = coordinator.bitPerfectAudioManager.refreshOutputRouting()
}
