package com.example.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import com.example.model.AccentColorMode
import com.example.model.PaletteColors

val LocalAccentColor = staticCompositionLocalOf { AppleMusicRed }

@Composable
fun SonoraTheme(
    accentColorMode: AccentColorMode = AccentColorMode.CUSTOM,
    customAccentArgb: Long = 0xFFFA2D48,
    albumPalette: PaletteColors = PaletteColors(),
    hasActiveTrack: Boolean = false,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val dynamicSystemScheme = dynamicDarkColorScheme(context)

    val targetAccent: Color = when (accentColorMode) {
        AccentColorMode.FOLLOW_DEVICE -> dynamicSystemScheme.primary
        AccentColorMode.DYNAMIC_ALBUM_ART -> {
            if (hasActiveTrack) {
                val raw = Color(albumPalette.color1)
                // Keep accent legible on Pure Black #000000
                if (raw.luminance() < 0.14f) AppleMusicRed else raw
            } else {
                AppleMusicRed
            }
        }
        AccentColorMode.CUSTOM -> Color(customAccentArgb)
    }

    val animatedAccent by animateColorAsState(
        targetValue = targetAccent,
        animationSpec = tween(durationMillis = 550),
        label = "accent_color_transition"
    )

    val colorScheme = darkColorScheme(
        primary = animatedAccent,
        onPrimary = if (animatedAccent.luminance() > 0.55f) Color.Black else Color.White,
        primaryContainer = animatedAccent.copy(alpha = 0.24f),
        onPrimaryContainer = Color.White,
        secondary = BitPerfectGold,
        onSecondary = Color(0xFF141000),
        tertiary = BitPerfectEmerald,
        onTertiary = Color(0xFF001A09),
        background = PureBlack,
        onBackground = TextPrimary,
        surface = IosGroupedBg,
        onSurface = TextPrimary,
        surfaceVariant = IosGroupedElevated,
        onSurfaceVariant = IosSecondaryGray,
        outline = IosSeparator,
        outlineVariant = IosSeparator,
    )

    CompositionLocalProvider(LocalAccentColor provides animatedAccent) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = SonoraTypography,
            content = content
        )
    }
}
