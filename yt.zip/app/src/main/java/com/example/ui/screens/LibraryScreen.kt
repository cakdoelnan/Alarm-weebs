package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.LibraryScanResult
import com.example.model.Album
import com.example.model.Artist
import com.example.model.BlurMode
import com.example.model.Track
import com.example.ui.LibrarySubTab
import com.example.ui.components.AlbumArtworkImage
import com.example.ui.components.IosGroupedContainer
import com.example.ui.components.IosThinDivider
import com.example.ui.theme.IosGroupedBg
import com.example.ui.theme.IosGroupedElevated
import com.example.ui.theme.IosSecondaryGray
import com.example.ui.theme.IosTertiaryGray
import com.example.ui.theme.LocalAccentColor
import com.example.ui.theme.PureBlack

@Composable
fun LibraryScreen(
    library: LibraryScanResult,
    subTab: LibrarySubTab,
    searchQuery: String,
    blurMode: BlurMode,
    hasAudioPermission: Boolean,
    isScanning: Boolean,
    currentTrackId: Long?,
    topContentPadding: Dp,
    bottomContentPadding: Dp,
    onSubTabSelected: (LibrarySubTab) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onArtistClick: (Artist) -> Unit,
    onTrackClick: (List<Track>, Int) -> Unit,
    onRequestPermission: () -> Unit,
    onOpenAudioFile: () -> Unit,
    onRescanLibrary: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = LocalAccentColor.current

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
    ) {
        if (!hasAudioPermission && library.tracks.isEmpty()) {
            LibraryEmptyCard(
                title = stringResource(R.string.permission_audio_title),
                body = stringResource(R.string.permission_audio_body),
                primaryLabel = stringResource(R.string.permission_audio_cta),
                secondaryLabel = stringResource(R.string.open_audio_file),
                accent = accent,
                topPadding = topContentPadding,
                bottomPadding = bottomContentPadding,
                onPrimaryClick = onRequestPermission,
                onSecondaryClick = onOpenAudioFile
            )
            return
        }

        if (isScanning && library.tracks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = accent)
            }
            return
        }

        if (library.tracks.isEmpty() && searchQuery.isBlank()) {
            LibraryEmptyCard(
                title = stringResource(R.string.empty_library_title),
                body = stringResource(R.string.empty_library_body),
                primaryLabel = stringResource(R.string.open_audio_file),
                secondaryLabel = stringResource(R.string.rescan_library),
                accent = accent,
                topPadding = topContentPadding,
                bottomPadding = bottomContentPadding,
                onPrimaryClick = onOpenAudioFile,
                onSecondaryClick = onRescanLibrary
            )
            return
        }

        when (subTab) {
            LibrarySubTab.ALBUMS -> {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 156.dp),
                    contentPadding = PaddingValues(
                        start = 20.dp,
                        end = 20.dp,
                        top = topContentPadding,
                        bottom = bottomContentPadding
                    ),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("library_albums_grid")
                ) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        LibraryControlsHeader(
                            subTab = subTab,
                            searchQuery = searchQuery,
                            accent = accent,
                            onSubTabSelected = onSubTabSelected,
                            onSearchQueryChange = onSearchQueryChange,
                            onRescanLibrary = onRescanLibrary
                        )
                    }

                    items(library.albums, key = { "${it.id}_${it.title}" }) { album ->
                        CleanAlbumGridCard(
                            album = album,
                            onClick = { onAlbumClick(album) }
                        )
                    }
                }
            }

            LibrarySubTab.ARTISTS -> {
                LazyColumn(
                    contentPadding = PaddingValues(
                        start = 20.dp,
                        end = 20.dp,
                        top = topContentPadding,
                        bottom = bottomContentPadding
                    ),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("library_artists_list")
                ) {
                    item {
                        LibraryControlsHeader(
                            subTab = subTab,
                            searchQuery = searchQuery,
                            accent = accent,
                            onSubTabSelected = onSubTabSelected,
                            onSearchQueryChange = onSearchQueryChange,
                            onRescanLibrary = onRescanLibrary
                        )
                        Spacer(Modifier.height(10.dp))
                    }

                    itemsIndexed(library.artists, key = { _, a -> a.name }) { idx, artist ->
                        CleanArtistRow(
                            artist = artist,
                            accent = accent,
                            onClick = { onArtistClick(artist) }
                        )
                        if (idx < library.artists.lastIndex) {
                            IosThinDivider(modifier = Modifier.padding(start = 58.dp))
                        }
                    }
                }
            }

            LibrarySubTab.SONGS -> {
                LazyColumn(
                    contentPadding = PaddingValues(
                        start = 20.dp,
                        end = 20.dp,
                        top = topContentPadding,
                        bottom = bottomContentPadding
                    ),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("library_songs_list")
                ) {
                    item {
                        LibraryControlsHeader(
                            subTab = subTab,
                            searchQuery = searchQuery,
                            accent = accent,
                            onSubTabSelected = onSubTabSelected,
                            onSearchQueryChange = onSearchQueryChange,
                            onRescanLibrary = onRescanLibrary
                        )
                        Spacer(Modifier.height(10.dp))
                    }

                    itemsIndexed(library.tracks, key = { _, t -> t.id }) { index, track ->
                        CleanAppleTrackRow(
                            track = track,
                            isPlayingCurrent = track.id == currentTrackId,
                            onClick = { onTrackClick(library.tracks, index) }
                        )
                        if (index < library.tracks.lastIndex) {
                            IosThinDivider(modifier = Modifier.padding(start = 64.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryControlsHeader(
    subTab: LibrarySubTab,
    searchQuery: String,
    accent: Color,
    onSubTabSelected: (LibrarySubTab) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onRescanLibrary: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        IosSearchBar(
            query = searchQuery,
            onQueryChange = onSearchQueryChange
        )

        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(IosGroupedBg)
                    .padding(3.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    LibrarySubTab.entries.forEach { tab ->
                        val selected = tab == subTab
                        val label = when (tab) {
                            LibrarySubTab.ALBUMS -> stringResource(R.string.library_albums)
                            LibrarySubTab.ARTISTS -> stringResource(R.string.library_artists)
                            LibrarySubTab.SONGS -> stringResource(R.string.library_songs)
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selected) IosGroupedElevated else Color.Transparent)
                                .clickable { onSubTabSelected(tab) }
                                .padding(vertical = 8.dp)
                                .testTag("library_subtab_${tab.name.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontSize = 13.sp,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
                                ),
                                color = if (selected) Color.White else IosSecondaryGray
                            )
                        }
                    }
                }
            }

            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(IosGroupedBg)
                    .clickable(onClick = onRescanLibrary)
                    .testTag("rescan_library_btn"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = stringResource(R.string.rescan_library),
                    tint = accent,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun IosSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = LocalAccentColor.current
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(IosGroupedBg)
            .testTag("liquid_glass_search_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Rounded.Search,
                contentDescription = "Search",
                tint = IosSecondaryGray,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            Box(modifier = Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    Text(
                        text = stringResource(R.string.search_placeholder),
                        style = MaterialTheme.typography.bodyLarge.copy(fontSize = 15.sp),
                        color = IosSecondaryGray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                BasicTextField(
                    value = query,
                    onValueChange = onQueryChange,
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = 15.sp,
                        color = Color.White
                    ),
                    cursorBrush = SolidColor(accent),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (query.isNotEmpty()) {
                IconButton(
                    onClick = { onQueryChange("") },
                    modifier = Modifier.size(22.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Clear search",
                        tint = IosSecondaryGray,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun CleanAlbumGridCard(
    album: Album,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag("album_card_${album.id}")
    ) {
        AlbumArtworkImage(
            artworkUri = album.artworkUri,
            contentDescription = album.title,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .shadow(10.dp, RoundedCornerShape(12.dp), ambientColor = Color.Black, spotColor = Color.Black)
                .clip(RoundedCornerShape(12.dp))
        )
        Spacer(Modifier.height(7.dp))
        Text(
            text = album.title,
            style = MaterialTheme.typography.bodyLarge.copy(
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            ),
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = album.artist,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
            color = IosSecondaryGray,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun CleanArtistRow(
    artist: Artist,
    accent: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(IosGroupedBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.Person,
                contentDescription = artist.name,
                tint = accent,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = artist.name,
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${artist.albums.size} albums • ${artist.tracks.size} songs",
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                color = IosSecondaryGray
            )
        }
        Icon(
            imageVector = Icons.Rounded.ChevronRight,
            contentDescription = null,
            tint = IosTertiaryGray,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun CleanAppleTrackRow(
    track: Track,
    isPlayingCurrent: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = LocalAccentColor.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp)
            .testTag("track_row_${track.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumArtworkImage(
            artworkUri = track.albumArtUri,
            contentDescription = track.album,
            modifier = Modifier
                .size(50.dp)
                .clip(RoundedCornerShape(10.dp))
        )
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = track.title,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                ),
                color = if (isPlayingCurrent) accent else Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = "${track.artist} • ${track.codecLabel} ${track.formattedSampleRate}",
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                color = IosSecondaryGray,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        if (isPlayingCurrent) {
            Icon(
                imageVector = Icons.Rounded.GraphicEq,
                contentDescription = "Now Playing",
                tint = accent,
                modifier = Modifier.size(18.dp)
            )
        } else {
            Text(
                text = formatDuration(track.durationMs),
                style = MaterialTheme.typography.labelSmall,
                color = IosTertiaryGray
            )
        }
    }
}

@Composable
private fun LibraryEmptyCard(
    title: String,
    body: String,
    primaryLabel: String,
    secondaryLabel: String,
    accent: Color,
    topPadding: Dp,
    bottomPadding: Dp,
    onPrimaryClick: () -> Unit,
    onSecondaryClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = topPadding, bottom = bottomPadding, start = 24.dp, end = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        IosGroupedContainer(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(accent.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LibraryMusic,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(30.dp)
                    )
                }
                Spacer(Modifier.height(14.dp))
                Text(title, style = MaterialTheme.typography.titleLarge, color = Color.White)
                Spacer(Modifier.height(6.dp))
                Text(body, style = MaterialTheme.typography.bodyMedium, color = IosSecondaryGray)
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = onPrimaryClick,
                    colors = ButtonDefaults.buttonColors(containerColor = accent),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("empty_primary_btn")
                ) {
                    Text(primaryLabel, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(6.dp))
                TextButton(
                    onClick = onSecondaryClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("empty_secondary_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AudioFile,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(secondaryLabel, color = accent)
                }
            }
        }
    }
}
