package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.BlurOn
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.ColorLens
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Usb
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.ColorUtils
import com.example.data.UserSettings
import com.example.model.AccentColorMode
import com.example.model.AudioOutputState
import com.example.model.BlurMode
import com.example.model.PlaybackMode
import com.example.model.SleepTimerOption
import com.example.model.SleepTimerState
import com.example.ui.components.IosGroupedContainer
import com.example.ui.components.IosThinDivider
import com.example.ui.theme.AccentColorPresets
import com.example.ui.theme.BitPerfectEmerald
import com.example.ui.theme.IosGroupedBg
import com.example.ui.theme.IosSecondaryGray
import com.example.ui.theme.IosTertiaryGray
import com.example.ui.theme.LocalAccentColor
import com.example.ui.theme.PureBlack

/**
 * BitChord / Apple Music iOS 27 Settings Screen:
 * - Pure Black #000000 canvas
 * - iOS Grouped Inset Cards (#161618, 16.dp corner radius, 0.5.dp dividers)
 * - Appearance: Accent Color (Follow Device / Dynamic Album Art / Custom Palette + Hue/Lightness sliders) & Blur Mode
 * - Clean Bottom Sheets for selectors (zero bulky radio buttons)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: UserSettings,
    audioOutputState: AudioOutputState,
    sleepTimerState: SleepTimerState,
    topContentPadding: Dp,
    bottomContentPadding: Dp,
    onSelectAccentMode: (AccentColorMode) -> Unit,
    onSelectCustomAccentArgb: (Long) -> Unit,
    onSelectBlurMode: (BlurMode) -> Unit,
    onToggleLiquidGlass: (Boolean) -> Unit,
    onSelectPlaybackMode: (PlaybackMode) -> Unit,
    onSelectSleepTimer: (SleepTimerOption) -> Unit,
    onToggleLyricsAutoScroll: (Boolean) -> Unit,
    onToggleLyricsBlur: (Boolean) -> Unit,
    onRefreshAudioRouting: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = LocalAccentColor.current

    var showAccentSheet by remember { mutableStateOf(false) }
    var showBlurSheet by remember { mutableStateOf(false) }
    var showPlaybackSheet by remember { mutableStateOf(false) }
    var showSleepSheet by remember { mutableStateOf(false) }
    var showDacSheet by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = topContentPadding,
            bottom = bottomContentPadding
        ),
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
            .testTag("settings_screen")
    ) {
        // 1. Appearance (Accent Color + Haze Blur + Liquid Glass)
        item {
            IosSectionLabel("APPEARANCE")
            IosGroupedContainer(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Accent Color row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showAccentSheet = true }
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                            .testTag("settings_accent_color_row"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ColorLens,
                            contentDescription = null,
                            tint = accent,
                            modifier = Modifier.size(21.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Accent Color",
                                style = MaterialTheme.typography.bodyLarge,
                                color = Color.White
                            )
                            Text(
                                text = settings.accentColorMode.title,
                                style = MaterialTheme.typography.bodyMedium,
                                color = IosSecondaryGray
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(accent)
                                .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape)
                        )
                        Spacer(Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.Rounded.ChevronRight,
                            contentDescription = null,
                            tint = IosTertiaryGray,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IosThinDivider(modifier = Modifier.padding(start = 49.dp))

                    // Blur Engine row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showBlurSheet = true }
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                            .testTag("settings_blur_mode_row"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.BlurOn,
                            contentDescription = null,
                            tint = accent,
                            modifier = Modifier.size(21.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Frosted Blur Engine",
                                style = MaterialTheme.typography.bodyLarge,
                                color = Color.White
                            )
                            Text(
                                text = settings.blurMode.title,
                                style = MaterialTheme.typography.bodyMedium,
                                color = IosSecondaryGray
                            )
                        }
                        Icon(
                            imageVector = Icons.Rounded.ChevronRight,
                            contentDescription = null,
                            tint = IosTertiaryGray,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IosThinDivider(modifier = Modifier.padding(start = 49.dp))

                    // Liquid Glass inner-border toggle
                    IosSwitchRow(
                        title = "Liquid Glass Rim & Sheen",
                        subtitle = "0.5dp specular hairline on Mini-Player & cards",
                        checked = settings.liquidGlassEnabled,
                        accent = accent,
                        onCheckedChange = onToggleLiquidGlass
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }

        // 2. USB DAC & Bit-Perfect Audio
        item {
            IosSectionLabel("AUDIO & BIT-PERFECT USB DAC")
            IosGroupedContainer(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showDacSheet = true }
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                            .testTag("settings_dac_row"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Usb,
                            contentDescription = null,
                            tint = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else accent,
                            modifier = Modifier.size(21.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = audioOutputState.modeLabel,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else Color.White
                            )
                            Text(
                                text = "${audioOutputState.deviceName} • ${audioOutputState.formattedSampleRate} / ${audioOutputState.bitDepth}-bit",
                                style = MaterialTheme.typography.bodyMedium,
                                color = IosSecondaryGray
                            )
                        }
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Refresh DAC",
                            tint = accent,
                            modifier = Modifier
                                .clip(CircleShape)
                                .clickable(onClick = onRefreshAudioRouting)
                                .padding(6.dp)
                                .size(18.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }

        // 3. Queue & Sleep Timer
        item {
            IosSectionLabel("PLAYBACK & QUEUE")
            IosGroupedContainer(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showPlaybackSheet = true }
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                            .testTag("settings_playback_mode_row"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Shuffle,
                            contentDescription = null,
                            tint = accent,
                            modifier = Modifier.size(21.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Queue Shuffle Mode",
                                style = MaterialTheme.typography.bodyLarge,
                                color = Color.White
                            )
                            Text(
                                text = settings.playbackMode.title,
                                style = MaterialTheme.typography.bodyMedium,
                                color = IosSecondaryGray
                            )
                        }
                        Icon(
                            imageVector = Icons.Rounded.ChevronRight,
                            contentDescription = null,
                            tint = IosTertiaryGray,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IosThinDivider(modifier = Modifier.padding(start = 49.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showSleepSheet = true }
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                            .testTag("settings_sleep_timer_row"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Bedtime,
                            contentDescription = null,
                            tint = accent,
                            modifier = Modifier.size(21.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Sleep Timer",
                                style = MaterialTheme.typography.bodyLarge,
                                color = Color.White
                            )
                            val sub = if (sleepTimerState.activeOption != SleepTimerOption.OFF && sleepTimerState.remainingMs > 0L) {
                                "${sleepTimerState.activeOption.label} • ${formatDuration(sleepTimerState.remainingMs)}"
                            } else {
                                sleepTimerState.activeOption.label
                            }
                            Text(
                                text = sub,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (sleepTimerState.activeOption != SleepTimerOption.OFF) accent else IosSecondaryGray
                            )
                        }
                        Icon(
                            imageVector = Icons.Rounded.ChevronRight,
                            contentDescription = null,
                            tint = IosTertiaryGray,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }

        // 4. Synced Lyrics
        item {
            IosSectionLabel("SYNCED LYRICS")
            IosGroupedContainer(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    IosSwitchRow(
                        icon = Icons.Rounded.Lyrics,
                        title = "Auto-Scroll Lyrics",
                        subtitle = "Spring-physics scroll tracking active line",
                        checked = settings.lyricsAutoScroll,
                        accent = accent,
                        onCheckedChange = onToggleLyricsAutoScroll
                    )
                    IosThinDivider(modifier = Modifier.padding(start = 49.dp))
                    IosSwitchRow(
                        icon = Icons.Rounded.BlurOn,
                        title = "Inactive Lyric Blur",
                        subtitle = "Soft 2dp blur on surrounding lines",
                        checked = settings.lyricsBlurEnabled,
                        accent = accent,
                        onCheckedChange = onToggleLyricsBlur
                    )
                }
            }
        }
    }

    // --- Accent Color Sheet (Follow Device / Dynamic Album Art / Custom Palette + HSL Picker) ---
    if (showAccentSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAccentSheet = false },
            containerColor = IosGroupedBg
        ) {
            AccentColorPickerSheet(
                selectedMode = settings.accentColorMode,
                customArgb = settings.customAccentArgb,
                activeAccent = accent,
                onSelectMode = onSelectAccentMode,
                onSelectCustomArgb = onSelectCustomAccentArgb
            )
        }
    }

    // --- Blur Mode Sheet ---
    if (showBlurSheet) {
        ModalBottomSheet(
            onDismissRequest = { showBlurSheet = false },
            containerColor = IosGroupedBg
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Frosted Blur Engine", style = MaterialTheme.typography.titleLarge, color = Color.White)
                Spacer(Modifier.height(12.dp))
                BlurMode.entries.forEachIndexed { idx, mode ->
                    val selected = settings.blurMode == mode
                    IosSheetCheckRow(
                        title = mode.title,
                        subtitle = mode.subtitle,
                        selected = selected,
                        accent = accent,
                        testTag = "blur_mode_${mode.name.lowercase()}",
                        onClick = {
                            onSelectBlurMode(mode)
                            showBlurSheet = false
                        }
                    )
                    if (idx < BlurMode.entries.lastIndex) IosThinDivider()
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    // --- Playback Mode Sheet ---
    if (showPlaybackSheet) {
        ModalBottomSheet(
            onDismissRequest = { showPlaybackSheet = false },
            containerColor = IosGroupedBg
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Queue Shuffle Mode", style = MaterialTheme.typography.titleLarge, color = Color.White)
                Spacer(Modifier.height(12.dp))
                PlaybackMode.entries.forEachIndexed { idx, mode ->
                    val selected = settings.playbackMode == mode
                    IosSheetCheckRow(
                        title = mode.title,
                        subtitle = mode.description,
                        selected = selected,
                        accent = accent,
                        testTag = "settings_playback_mode_${mode.name.lowercase()}",
                        onClick = {
                            onSelectPlaybackMode(mode)
                            showPlaybackSheet = false
                        }
                    )
                    if (idx < PlaybackMode.entries.lastIndex) IosThinDivider()
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    // --- Sleep Timer Sheet ---
    if (showSleepSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSleepSheet = false },
            containerColor = IosGroupedBg
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Sleep Timer", style = MaterialTheme.typography.titleLarge, color = Color.White)
                Text(
                    text = "Smooth 10-second fade-out before pausing",
                    style = MaterialTheme.typography.bodyMedium,
                    color = IosSecondaryGray
                )
                Spacer(Modifier.height(12.dp))
                SleepTimerOption.entries.forEachIndexed { idx, opt ->
                    val selected = sleepTimerState.activeOption == opt
                    IosSheetCheckRow(
                        title = opt.label,
                        subtitle = null,
                        selected = selected,
                        accent = accent,
                        testTag = "sleep_timer_${opt.name.lowercase()}",
                        onClick = {
                            onSelectSleepTimer(opt)
                            showSleepSheet = false
                        }
                    )
                    if (idx < SleepTimerOption.entries.lastIndex) IosThinDivider()
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    // --- DAC Stats Sheet ---
    if (showDacSheet) {
        ModalBottomSheet(
            onDismissRequest = { showDacSheet = false },
            containerColor = IosGroupedBg
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Audio Signal Path", style = MaterialTheme.typography.titleLarge, color = Color.White)
                Spacer(Modifier.height(10.dp))
                Text(
                    text = audioOutputState.modeLabel,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else accent
                )
                Text(
                    text = "${audioOutputState.deviceName} • ${audioOutputState.formattedSampleRate} / ${audioOutputState.bitDepth}-bit",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = audioOutputState.statusDetail,
                    style = MaterialTheme.typography.bodyMedium,
                    color = IosSecondaryGray
                )
                if (audioOutputState.supportedProfiles.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    Text("Supported HAL Mixer Profiles", style = MaterialTheme.typography.titleMedium, color = Color.White)
                    Spacer(Modifier.height(6.dp))
                    audioOutputState.supportedProfiles.take(12).forEach { profile ->
                        Text(
                            text = "• $profile",
                            style = MaterialTheme.typography.labelMedium,
                            color = IosSecondaryGray,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun AccentColorPickerSheet(
    selectedMode: AccentColorMode,
    customArgb: Long,
    activeAccent: Color,
    onSelectMode: (AccentColorMode) -> Unit,
    onSelectCustomArgb: (Long) -> Unit
) {
    val initialHsl = remember(customArgb) {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(customArgb.toInt(), hsl)
        hsl
    }
    var hue by remember(customArgb) { mutableFloatStateOf(initialHsl[0]) }
    var saturation by remember(customArgb) { mutableFloatStateOf(initialHsl[1].coerceIn(0.35f, 1f)) }
    var lightness by remember(customArgb) { mutableFloatStateOf(initialHsl[2].coerceIn(0.40f, 0.72f)) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        Text(
            text = "Accent Color",
            style = MaterialTheme.typography.titleLarge,
            color = Color.White
        )
        Spacer(Modifier.height(12.dp))

        AccentColorMode.entries.forEachIndexed { idx, mode ->
            IosSheetCheckRow(
                title = mode.title,
                subtitle = mode.subtitle,
                selected = selectedMode == mode,
                accent = activeAccent,
                testTag = "accent_mode_${mode.name.lowercase()}",
                onClick = { onSelectMode(mode) }
            )
            if (idx < AccentColorMode.entries.lastIndex) {
                IosThinDivider()
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(
            text = "Custom Presets",
            style = MaterialTheme.typography.labelMedium,
            color = IosSecondaryGray
        )
        Spacer(Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            AccentColorPresets.forEach { preset ->
                val presetColor = Color(preset.argb)
                val isChosen = selectedMode == AccentColorMode.CUSTOM && customArgb == preset.argb
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            onSelectMode(AccentColorMode.CUSTOM)
                            onSelectCustomArgb(preset.argb)
                        }
                        .padding(4.dp)
                        .testTag("accent_preset_${preset.name.lowercase().replace(" ", "_")}")
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(presetColor)
                            .border(
                                width = if (isChosen) 2.5.dp else 0.5.dp,
                                color = if (isChosen) Color.White else Color.White.copy(alpha = 0.2f),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isChosen) {
                            Icon(
                                imageVector = Icons.Rounded.Check,
                                contentDescription = preset.name,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = preset.name.substringBefore(" "),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isChosen) Color.White else IosSecondaryGray
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(
            text = "Custom Color Slider",
            style = MaterialTheme.typography.labelMedium,
            color = IosSecondaryGray
        )
        Spacer(Modifier.height(6.dp))

        // Hue Spectrum Bar + Slider
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(50))
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color.Red,
                            Color.Yellow,
                            Color.Green,
                            Color.Cyan,
                            Color.Blue,
                            Color.Magenta,
                            Color.Red
                        )
                    )
                )
        )
        Slider(
            value = hue,
            onValueChange = { newHue ->
                hue = newHue
                val rgb = ColorUtils.HSLToColor(floatArrayOf(hue, saturation, lightness))
                onSelectMode(AccentColorMode.CUSTOM)
                onSelectCustomArgb(rgb.toLong() and 0xFFFFFFFFL)
            },
            valueRange = 0f..360f,
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Color.Transparent,
                inactiveTrackColor = Color.Transparent
            ),
            modifier = Modifier.testTag("custom_accent_hue_slider")
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Vividness",
                style = MaterialTheme.typography.bodyMedium,
                color = IosSecondaryGray,
                modifier = Modifier.width(68.dp)
            )
            Slider(
                value = lightness,
                onValueChange = { newL ->
                    lightness = newL
                    val rgb = ColorUtils.HSLToColor(floatArrayOf(hue, saturation, lightness))
                    onSelectMode(AccentColorMode.CUSTOM)
                    onSelectCustomArgb(rgb.toLong() and 0xFFFFFFFFL)
                },
                valueRange = 0.38f..0.72f,
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color(ColorUtils.HSLToColor(floatArrayOf(hue, saturation, lightness))),
                    inactiveTrackColor = Color.White.copy(alpha = 0.16f)
                ),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun IosSectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelMedium.copy(
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 0.6.sp
        ),
        color = IosSecondaryGray,
        modifier = Modifier.padding(start = 16.dp, bottom = 8.dp)
    )
}

@Composable
private fun IosSheetCheckRow(
    title: String,
    subtitle: String?,
    selected: Boolean,
    accent: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = if (selected) accent else Color.White
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = IosSecondaryGray
                )
            }
        }
        if (selected) {
            Spacer(Modifier.width(10.dp))
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = "Selected",
                tint = accent,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun IosSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    accent: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(21.dp)
            )
            Spacer(Modifier.width(12.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = IosSecondaryGray
            )
        }
        Spacer(Modifier.width(10.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = accent,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = Color(0xFF39393D),
                uncheckedBorderColor = Color.Transparent
            ),
            modifier = Modifier.scale(0.86f)
        )
    }
}
