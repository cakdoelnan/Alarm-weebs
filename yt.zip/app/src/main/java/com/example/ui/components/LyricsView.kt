package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BlurOn
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.VerticalAlignCenter
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.BlurMode
import com.example.model.LyricLine
import com.example.model.LyricsData
import com.example.ui.theme.LocalAccentColor
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun AppleMusicLyricsView(
    lyricsData: LyricsData,
    positionMs: Long,
    autoScrollEnabled: Boolean,
    lyricBlurEnabled: Boolean,
    blurMode: BlurMode,
    onToggleAutoScroll: (Boolean) -> Unit,
    onToggleLyricBlur: (Boolean) -> Unit,
    onSeekToLine: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    val accent = LocalAccentColor.current

    val activeIndex = remember(lyricsData, positionMs) {
        if (!lyricsData.isSynced || lyricsData.lines.isEmpty()) -1
        else {
            val idx = lyricsData.lines.indexOfLast { it.startTimeMs <= positionMs }
            idx.coerceAtLeast(0)
        }
    }

    LaunchedEffect(activeIndex, autoScrollEnabled) {
        if (autoScrollEnabled && activeIndex >= 0 && activeIndex < lyricsData.lines.size) {
            listState.animateScrollToItem(
                index = activeIndex,
                scrollOffset = -180
            )
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val tagText = buildString {
                append(lyricsData.sourceLabel.ifBlank { "Lyrics" })
                if (lyricsData.isWordSynced) append(" • Word Sync")
                else if (lyricsData.isSynced) append(" • Synced")
            }
            Text(
                text = tagText,
                style = MaterialTheme.typography.labelMedium,
                color = accent
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LyricTogglePill(
                    label = stringResource(R.string.lyrics_auto_scroll),
                    icon = Icons.Rounded.VerticalAlignCenter,
                    active = autoScrollEnabled,
                    accent = accent,
                    testTag = "lyrics_auto_scroll_toggle",
                    onClick = { onToggleAutoScroll(!autoScrollEnabled) }
                )
                LyricTogglePill(
                    label = stringResource(R.string.lyrics_blur),
                    icon = Icons.Rounded.BlurOn,
                    active = lyricBlurEnabled,
                    accent = accent,
                    testTag = "lyrics_blur_toggle",
                    onClick = { onToggleLyricBlur(!lyricBlurEnabled) }
                )
            }
        }

        if (lyricsData.lines.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lyrics,
                        contentDescription = null,
                        tint = TextTertiary,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = stringResource(R.string.lyrics_empty),
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextSecondary
                    )
                }
            }
        } else {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(top = 48.dp, bottom = 140.dp),
                verticalArrangement = Arrangement.spacedBy(22.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("lyrics_lazy_column")
            ) {
                itemsIndexed(lyricsData.lines) { index, line ->
                    val isActive = if (lyricsData.isSynced) index == activeIndex else true
                    val distance = if (activeIndex >= 0) kotlin.math.abs(index - activeIndex) else 0

                    LyricLineItem(
                        line = line,
                        isSynced = lyricsData.isSynced,
                        isActive = isActive,
                        distanceFromActive = distance,
                        lyricBlurEnabled = lyricBlurEnabled,
                        positionMs = positionMs,
                        onClick = {
                            if (lyricsData.isSynced) onSeekToLine(line.startTimeMs)
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LyricLineItem(
    line: LyricLine,
    isSynced: Boolean,
    isActive: Boolean,
    distanceFromActive: Int,
    lyricBlurEnabled: Boolean,
    positionMs: Long,
    onClick: () -> Unit
) {
    val targetScale = when {
        !isSynced -> 1.0f
        isActive -> 1.06f
        else -> 0.91f
    }
    val scale by animateFloatAsState(
        targetValue = targetScale,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "lyric_scale"
    )

    val targetAlpha = when {
        !isSynced -> 0.92f
        isActive -> 1.0f
        distanceFromActive == 1 -> 0.45f
        else -> 0.28f
    }
    val alpha by animateFloatAsState(
        targetValue = targetAlpha,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "lyric_alpha"
    )

    val shouldBlur = isSynced && !isActive && lyricBlurEnabled
    val blurModifier = if (shouldBlur) Modifier.blur(2.dp) else Modifier

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(enabled = isSynced, onClick = onClick)
            .padding(vertical = 4.dp, horizontal = 4.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                transformOrigin = TransformOrigin(0f, 0.5f)
            }
            .then(blurModifier)
            .alpha(alpha)
    ) {
        if (isActive && line.words.isNotEmpty()) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(7.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                line.words.forEach { word ->
                    val span = (word.endTimeMs - word.startTimeMs).coerceAtLeast(120L)
                    val wordProgress = ((positionMs - word.startTimeMs).toFloat() / span.toFloat())
                        .coerceIn(0f, 1f)
                    val wordLift by animateFloatAsState(
                        targetValue = if (wordProgress in 0.01f..0.99f) -2f else 0f,
                        animationSpec = spring(stiffness = Spring.StiffnessMedium),
                        label = "word_lift"
                    )

                    val wordBrush = Brush.linearGradient(
                        0.0f to Color.White,
                        wordProgress.coerceIn(0.01f, 0.99f) to Color.White,
                        (wordProgress + 0.08f).coerceIn(0.02f, 1.0f) to Color.White.copy(alpha = 0.36f),
                        1.0f to Color.White.copy(alpha = 0.36f),
                        start = Offset.Zero,
                        end = Offset(180f, 0f)
                    )

                    Text(
                        text = word.text,
                        style = TextStyle(
                            fontFamily = FontFamily.Default,
                            brush = wordBrush,
                            fontSize = 26.sp,
                            lineHeight = 34.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.graphicsLayer {
                            translationY = wordLift
                        }
                    )
                }
            }
        } else if (isActive && isSynced) {
            val lineSpan = (line.endTimeMs - line.startTimeMs).coerceAtLeast(500L)
            val lineProgress = ((positionMs - line.startTimeMs).toFloat() / lineSpan.toFloat())
                .coerceIn(0f, 1f)
            val lineBrush = Brush.linearGradient(
                0.0f to Color.White,
                lineProgress.coerceIn(0.02f, 0.98f) to Color.White,
                (lineProgress + 0.14f).coerceIn(0.04f, 1.0f) to Color.White.copy(alpha = 0.58f),
                1.0f to Color.White.copy(alpha = 0.58f),
                start = Offset.Zero,
                end = Offset(600f, 120f)
            )
            Text(
                text = line.text,
                style = TextStyle(
                    fontFamily = FontFamily.Default,
                    brush = lineBrush,
                    fontSize = 26.sp,
                    lineHeight = 34.sp,
                    fontWeight = FontWeight.Bold
                )
            )
        } else {
            Text(
                text = line.text,
                style = TextStyle(
                    fontFamily = FontFamily.Default,
                    color = Color.White,
                    fontSize = if (isSynced) 23.sp else 19.sp,
                    lineHeight = 30.sp,
                    fontWeight = FontWeight.SemiBold
                )
            )
        }
    }
}

@Composable
private fun LyricTogglePill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    accent: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (active) accent.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.12f))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (active) accent else Color.White.copy(alpha = 0.72f),
                modifier = Modifier.size(15.dp)
            )
            Spacer(Modifier.width(5.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = if (active) Color.White else Color.White.copy(alpha = 0.75f)
            )
        }
    }
}
