package com.example.haptics

import android.content.Context
import android.os.Build
import android.os.VibrationAttributes
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.model.JihoPattern
import kotlin.math.roundToInt

class VibrationEngine(context: Context) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        manager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    val hasVibrator: Boolean
        get() = vibrator?.hasVibrator() == true

    val hasAmplitudeControl: Boolean
        get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && vibrator?.hasAmplitudeControl() == true

    fun strengthToAmplitude(strengthPercent: Int): Int {
        val clamped = strengthPercent.coerceIn(10, 100)
        return ((clamped / 100f) * 255f).roundToInt().coerceIn(25, 255)
    }

    private fun durationScale(strengthPercent: Int): Float {
        // Scales duration subtly (0.55x at 10% up to 1.25x at 100%) so devices without amplitude control
        // still produce a distinct gentle vs strong tactile feel.
        val clamped = strengthPercent.coerceIn(10, 100)
        return 0.50f + (clamped / 100f) * 0.75f
    }

    fun previewStrength(strengthPercent: Int) {
        val scale = durationScale(strengthPercent)
        val timings = longArrayOf(0, (140 * scale).toLong(), 80, (220 * scale).toLong())
        val amp = strengthToAmplitude(strengthPercent)
        val amplitudes = intArrayOf(0, amp, 0, amp)
        playWaveform(timings, amplitudes, repeat = -1, isAlarm = false)
    }

    fun vibrateJiho(pattern: JihoPattern, strengthPercent: Int, hourOfDay: Int = 12) {
        val scale = durationScale(strengthPercent)
        val amp = strengthToAmplitude(strengthPercent)
        val (timings, amplitudes) = when (pattern) {
            JihoPattern.SINGLE_HEARTBEAT -> {
                longArrayOf(0, (200 * scale).toLong()) to intArrayOf(0, amp)
            }
            JihoPattern.DOUBLE_IDOL -> {
                longArrayOf(0, (130 * scale).toLong(), 95, (180 * scale).toLong()) to
                    intArrayOf(0, amp, 0, amp)
            }
            JihoPattern.TRIPLE_STARLIGHT -> {
                longArrayOf(
                    0,
                    (110 * scale).toLong(),
                    80,
                    (110 * scale).toLong(),
                    80,
                    (220 * scale).toLong()
                ) to intArrayOf(0, (amp * 0.85f).toInt().coerceAtLeast(20), 0, amp, 0, amp)
            }
            JihoPattern.HOUR_COUNT -> {
                // Tactical dash-dot-dash cadence
                longArrayOf(
                    0,
                    (240 * scale).toLong(),
                    90,
                    (90 * scale).toLong(),
                    90,
                    (240 * scale).toLong()
                ) to intArrayOf(0, amp, 0, (amp * 0.75f).toInt().coerceAtLeast(20), 0, amp)
            }
        }
        playWaveform(timings, amplitudes, repeat = -1, isAlarm = false)
    }

    fun startAlarmVibrationLoop(strengthPercent: Int) {
        val scale = durationScale(strengthPercent)
        val amp = strengthToAmplitude(strengthPercent)
        val accentAmp = amp
        val softAmp = (amp * 0.7f).toInt().coerceAtLeast(20)
        // Anime idol beat cadence: da-da-DUM ... pause
        val timings = longArrayOf(
            0,
            (180 * scale).toLong(),
            110,
            (180 * scale).toLong(),
            110,
            (380 * scale).toLong(),
            320
        )
        val amplitudes = intArrayOf(0, softAmp, 0, softAmp, 0, accentAmp, 0)
        playWaveform(timings, amplitudes, repeat = 0, isAlarm = true)
    }

    fun stopVibration() {
        vibrator?.cancel()
    }

    private fun playWaveform(
        timings: LongArray,
        amplitudes: IntArray,
        repeat: Int,
        isAlarm: Boolean
    ) {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        v.cancel()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val effect = if (v.hasAmplitudeControl()) {
                VibrationEffect.createWaveform(timings, amplitudes, repeat)
            } else {
                VibrationEffect.createWaveform(timings, repeat)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val usage = if (isAlarm) {
                    VibrationAttributes.USAGE_ALARM
                } else {
                    VibrationAttributes.USAGE_NOTIFICATION
                }
                val attrs = VibrationAttributes.Builder().setUsage(usage).build()
                v.vibrate(effect, attrs)
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(effect)
            }
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(timings, repeat)
        }
    }
}
