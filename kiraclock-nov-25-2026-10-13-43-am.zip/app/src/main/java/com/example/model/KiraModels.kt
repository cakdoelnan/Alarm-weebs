package com.example.model

import androidx.annotation.DrawableRes
import com.example.R

enum class WorldTheme(
    val id: String,
    val title: String,
    val subtitle: String,
    val companionName: String,
    val companionRole: String,
    val japaneseTag: String,
    val greetingLine: String,
    val wakePrompt: String,
    val clearedLine: String,
    val snoozeLine: String,
    val jihoLines: List<String>,
    @DrawableRes val portraitRes: Int,
    val melodyNotesHz: DoubleArray
) {
    STARLIGHT_BEAT(
        id = "starlight_beat",
        title = "Starlight Beat",
        subtitle = "Idol Band Stage",
        companionName = "Hoshino Hibiki",
        companionRole = "Prism★Beat Lead Guitarist",
        japaneseTag = "きらきらステージ",
        greetingLine = "Ohayou, Producer! Mic check one, two—let's rock this morning!",
        wakePrompt = "Showtime starts now! Hit the beat to clear the stage!",
        clearedLine = "Full combo morning! Today's live is gonna shine bright!",
        snoozeLine = "Five more minutes of backstage rest... don't miss encore!",
        jihoLines = listOf(
            "Time check! Keep your rhythm steady this hour!",
            "Encore pulse! Stay sharp and hydrate, Producer!",
            "New hour, new measure—let's keep the tempo!"
        ),
        portraitRes = R.drawable.img_char_hibiki,
        melodyNotesHz = doubleArrayOf(523.25, 659.25, 783.99, 987.77, 1046.50, 783.99, 659.25, 783.99)
    ),
    TRACEN_TURF(
        id = "tracen_turf",
        title = "Tracen Turf",
        subtitle = "Crown Derby Academy",
        companionName = "Hayabusa Suzuka",
        companionRole = "Turf Sprinter Ace",
        japaneseTag = "全力疾走ダッシュ",
        greetingLine = "Ohayou, Trainer! The morning turf is fresh and ready for a sprint!",
        wakePrompt = "The gate is open! Sprint through your morning stretch!",
        clearedLine = "Photo finish! First place start to the day!",
        snoozeLine = "Quick breather at the paddock—next bell is final lap!",
        jihoLines = listOf(
            "Lap marker! Check your pace for this hour!",
            "Steady stride! Keep eyes on the finish line!",
            "Hourly split time—you're running great!"
        ),
        portraitRes = R.drawable.img_char_suzuka,
        melodyNotesHz = doubleArrayOf(392.00, 523.25, 659.25, 783.99, 659.25, 783.99, 1046.50, 1046.50)
    ),
    SCHALE_HALO(
        id = "schale_halo",
        title = "Schale Halo",
        subtitle = "Tactical Cyber Club",
        companionName = "Aoi Shiroha",
        companionRole = "Tactical Schedule Advisor",
        japaneseTag = "戦略ブリーフィング",
        greetingLine = "Good morning, Sensei. All systems nominal—briefing begins now.",
        wakePrompt = "Verify tactical wake-up code to unlock today's mission log.",
        clearedLine = "Authentication complete. Mission efficiency is at 100%, Sensei!",
        snoozeLine = "Entering 5-minute standby mode. Please resume promptly, Sensei.",
        jihoLines = listOf(
            "Hourly telemetry synced. Stay on schedule, Sensei.",
            "Tactical pulse: take a quick posture & eye break.",
            "Time-signal confirmed. Next objective ready."
        ),
        portraitRes = R.drawable.img_char_shiroha,
        melodyNotesHz = doubleArrayOf(880.00, 659.25, 987.77, 739.99, 1108.73, 880.00, 987.77, 1318.51)
    ),
    ASTRAL_WISH(
        id = "astral_wish",
        title = "Astral Wish",
        subtitle = "Celestial Observatory",
        companionName = "Lumis Astera",
        companionRole = "Stargazer Traveler",
        japaneseTag = "星々の導き",
        greetingLine = "Dawn breaks across the stars, Traveler. Your daily commission awaits.",
        wakePrompt = "Align the morning constellations to awaken the sky.",
        clearedLine = "The stars bless your path today. May your journey be luminous!",
        snoozeLine = "Resting beneath fading starlight... just five brief minutes.",
        jihoLines = listOf(
            "The celestial astrolabe chimes the new hour.",
            "Starlight pulse: pause and breathe beneath the sky.",
            "Another hour turns in the astral wheel."
        ),
        portraitRes = R.drawable.img_char_astera,
        melodyNotesHz = doubleArrayOf(587.33, 880.00, 739.99, 659.25, 587.33, 440.00, 659.25, 880.00)
    );

    companion object {
        fun fromId(id: String?): WorldTheme =
            entries.firstOrNull { it.id == id } ?: STARLIGHT_BEAT
    }
}

enum class WakeChallengeType(
    val id: String,
    val displayName: String,
    val shortBadge: String,
    val description: String
) {
    NORMAL(
        id = "normal",
        displayName = "Quick Clear",
        shortBadge = "Tap",
        description = "Clean single-tap wake-up dismiss"
    ),
    RHYTHM_BEAT(
        id = "rhythm_beat",
        displayName = "Live Beat Tap",
        shortBadge = "Rhythm",
        description = "Hit 6 falling idol star notes on beat to silence"
    ),
    TURF_SPRINT(
        id = "turf_sprint",
        displayName = "Turf Dash Sprint",
        shortBadge = "Sprint",
        description = "Rapid-tap the Last Spurt gauge to 100% finish"
    ),
    HALO_CIPHER(
        id = "halo_cipher",
        displayName = "Tactical Cipher",
        shortBadge = "Cipher",
        description = "Match the 4-symbol anime glyph sequence"
    );

    companion object {
        fun fromId(id: String?): WakeChallengeType =
            entries.firstOrNull { it.id == id } ?: NORMAL
    }
}

enum class JihoPattern(
    val id: String,
    val displayName: String,
    val subtitle: String
) {
    SINGLE_HEARTBEAT(
        id = "single",
        displayName = "Single Heartbeat",
        subtitle = "1 subtle pulse on the hour"
    ),
    DOUBLE_IDOL(
        id = "double",
        displayName = "Double Idol Tap",
        subtitle = "2 crisp anime-beat taps"
    ),
    TRIPLE_STARLIGHT(
        id = "triple",
        displayName = "Starlight Triple",
        subtitle = "3 rhythmic pulses (da-da-dum)"
    ),
    HOUR_COUNT(
        id = "hour_count",
        displayName = "Tactical Chime",
        subtitle = "Long-short-long academy signal"
    );

    companion object {
        fun fromId(id: String?): JihoPattern =
            entries.firstOrNull { it.id == id } ?: DOUBLE_IDOL
    }
}

data class HapticSettings(
    val vibrationStrength: Int = 75,
    val globalVibrateOnlyDefault: Boolean = false,
    val jihoEnabled: Boolean = false,
    val jihoStartHour: Int = 7,
    val jihoEndHour: Int = 22,
    val jihoPattern: JihoPattern = JihoPattern.DOUBLE_IDOL,
    val jihoSilentVibrateOnly: Boolean = true,
    val voiceGreetingEnabled: Boolean = true
) {
    val strengthTierLabel: String
        get() = when {
            vibrationStrength <= 25 -> "Gentle Whisper"
            vibrationStrength <= 55 -> "Balanced Pulse"
            vibrationStrength <= 85 -> "Idol Stage Beat"
            else -> "Max Overdrive"
        }
}

data class CompanionStats(
    val morningStars: Int = 0,
    val wakeStreak: Int = 0,
    val lastWakeDate: String = "",
    val bondXpByWorld: Map<WorldTheme, Int> = WorldTheme.entries.associateWith { 0 }
) {
    fun bondLevel(world: WorldTheme): Int {
        val xp = bondXpByWorld[world] ?: 0
        return (xp / 50) + 1
    }

    fun bondProgress(world: WorldTheme): Float {
        val xp = bondXpByWorld[world] ?: 0
        return (xp % 50) / 50f
    }
}
