package com.example.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.MainActivity
import com.example.data.AlarmEntity
import com.example.model.HapticSettings
import java.util.Calendar

class AlarmScheduler(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun canScheduleExactAlarms(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    fun scheduleAlarm(alarm: AlarmEntity) {
        if (!alarm.enabled) {
            cancelAlarm(alarm.id)
            return
        }
        val triggerAtMillis = alarm.computeNextTriggerMillis()
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_TRIGGER_ALARM
            putExtra(EXTRA_ALARM_ID, alarm.id)
            putExtra(EXTRA_ALARM_LABEL, alarm.label)
            putExtra(EXTRA_VIBRATE_ONLY, alarm.vibrateOnly)
            putExtra(EXTRA_CHALLENGE_TYPE, alarm.challengeType)
            putExtra(EXTRA_WORLD_THEME_ID, alarm.worldThemeId)
            putExtra(EXTRA_STRENGTH_OVERRIDE, alarm.vibrateStrengthOverride ?: -1)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            alarm.id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val showIntent = PendingIntent.getActivity(
            context,
            alarm.id + 10_000,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val info = AlarmManager.AlarmClockInfo(triggerAtMillis, showIntent)
        alarmManager.setAlarmClock(info, pendingIntent)
    }

    fun scheduleSnooze(
        alarmId: Int,
        label: String,
        vibrateOnly: Boolean,
        challengeType: String,
        worldThemeId: String,
        strengthOverride: Int,
        minutes: Int = 5
    ) {
        val triggerAtMillis = System.currentTimeMillis() + minutes * 60_000L
        val requestCode = 50_000 + alarmId
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_TRIGGER_ALARM
            putExtra(EXTRA_ALARM_ID, alarmId)
            putExtra(EXTRA_ALARM_LABEL, "$label (Snooze)")
            putExtra(EXTRA_VIBRATE_ONLY, vibrateOnly)
            putExtra(EXTRA_CHALLENGE_TYPE, challengeType)
            putExtra(EXTRA_WORLD_THEME_ID, worldThemeId)
            putExtra(EXTRA_STRENGTH_OVERRIDE, strengthOverride)
            putExtra(EXTRA_IS_SNOOZE, true)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val showIntent = PendingIntent.getActivity(
            context,
            requestCode + 10_000,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAtMillis, showIntent), pendingIntent)
    }

    fun cancelAlarm(alarmId: Int) {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_TRIGGER_ALARM
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            alarmId,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }

    fun scheduleNextHourlyJiho(settings: HapticSettings) {
        if (!settings.jihoEnabled) {
            cancelHourlyJiho()
            return
        }
        val nextTriggerMillis = computeNextJihoMillis(
            nowMillis = System.currentTimeMillis(),
            startHour = settings.jihoStartHour,
            endHour = settings.jihoEndHour
        ) ?: return

        val intent = Intent(context, HourlyChimeReceiver::class.java).apply {
            action = HourlyChimeReceiver.ACTION_HOURLY_JIHO
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            JIHO_REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (canScheduleExactAlarms()) {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                nextTriggerMillis,
                pendingIntent
            )
        } else {
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                nextTriggerMillis,
                pendingIntent
            )
        }
    }

    fun cancelHourlyJiho() {
        val intent = Intent(context, HourlyChimeReceiver::class.java).apply {
            action = HourlyChimeReceiver.ACTION_HOURLY_JIHO
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            JIHO_REQUEST_CODE,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }

    companion object {
        const val EXTRA_ALARM_ID = "extra_alarm_id"
        const val EXTRA_ALARM_LABEL = "extra_alarm_label"
        const val EXTRA_VIBRATE_ONLY = "extra_vibrate_only"
        const val EXTRA_CHALLENGE_TYPE = "extra_challenge_type"
        const val EXTRA_WORLD_THEME_ID = "extra_world_theme_id"
        const val EXTRA_STRENGTH_OVERRIDE = "extra_strength_override"
        const val EXTRA_IS_SNOOZE = "extra_is_snooze"
        const val EXTRA_IS_PREVIEW = "extra_is_preview"
        private const val JIHO_REQUEST_CODE = 99_001

        fun isHourInWindow(hour: Int, startHour: Int, endHour: Int): Boolean {
            return if (startHour == endHour) {
                true // 24-hour active
            } else if (startHour < endHour) {
                hour in startHour..endHour
            } else {
                hour >= startHour || hour <= endHour
            }
        }

        fun computeNextJihoMillis(nowMillis: Long, startHour: Int, endHour: Int): Long? {
            val cal = Calendar.getInstance().apply {
                timeInMillis = nowMillis
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                add(Calendar.HOUR_OF_DAY, 1)
            }
            for (i in 0..24) {
                val candidateHour = cal.get(Calendar.HOUR_OF_DAY)
                if (isHourInWindow(candidateHour, startHour, endHour)) {
                    return cal.timeInMillis
                }
                cal.add(Calendar.HOUR_OF_DAY, 1)
            }
            return null
        }
    }
}
