package com.example.alarm

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Snooze
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.example.data.AlarmRepository
import com.example.data.AppDatabase
import com.example.data.PreferencesManager
import com.example.model.WakeChallengeType
import com.example.model.WorldTheme
import com.example.ui.theme.KiraClockTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AlarmRingActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        configureLockScreenDisplay()

        val alarmLabel = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_LABEL)
            ?.takeIf { it.isNotBlank() } ?: "Morning Call"
        val vibrateOnly = intent.getBooleanExtra(AlarmScheduler.EXTRA_VIBRATE_ONLY, false)
        val challengeType = WakeChallengeType.fromId(
            intent.getStringExtra(AlarmScheduler.EXTRA_CHALLENGE_TYPE)
        )
        val worldTheme = WorldTheme.fromId(
            intent.getStringExtra(AlarmScheduler.EXTRA_WORLD_THEME_ID)
        )
        val isPreview = intent.getBooleanExtra(AlarmScheduler.EXTRA_IS_PREVIEW, false)

        setContent {
            KiraClockTheme(worldTheme = worldTheme) {
                AlarmRingScreen(
                    world = worldTheme,
                    alarmLabel = alarmLabel,
                    vibrateOnly = vibrateOnly,
                    challengeType = challengeType,
                    isPreview = isPreview,
                    onSnooze = {
                        val snoozeIntent = Intent(this, AlarmRingingService::class.java).apply {
                            action = AlarmRingingService.ACTION_SNOOZE
                        }
                        startService(snoozeIntent)
                        finish()
                    },
                    onClearComplete = {
                        val stopIntent = Intent(this, AlarmRingingService::class.java).apply {
                            action = AlarmRingingService.ACTION_STOP
                        }
                        startService(stopIntent)
                        if (!isPreview) {
                            lifecycleScope.launch {
                                val repo = AlarmRepository(
                                    AppDatabase.getInstance(this@AlarmRingActivity).alarmDao(),
                                    PreferencesManager(this@AlarmRingActivity)
                                )
                                val stars = if (challengeType == WakeChallengeType.NORMAL) 20 else 35
                                repo.recordWakeSuccess(
                                    alarmLabel = alarmLabel,
                                    world = worldTheme,
                                    challengeId = challengeType.id,
                                    vibrateOnly = vibrateOnly,
                                    starsEarned = stars
                                )
                            }
                        }
                        finish()
                    }
                )
            }
        }
    }

    private fun configureLockScreenDisplay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            keyguardManager.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }
    }
}

@Composable
private fun AlarmRingScreen(
    world: WorldTheme,
    alarmLabel: String,
    vibrateOnly: Boolean,
    challengeType: WakeChallengeType,
    isPreview: Boolean,
    onSnooze: () -> Unit,
    onClearComplete: () -> Unit
) {
    // Prevent accidental back-press dismissal when a real challenge is active
    BackHandler(enabled = !isPreview && challengeType != WakeChallengeType.NORMAL) {}

    var cleared by remember { mutableStateOf(false) }
    var currentTime by remember { mutableStateOf(formatNow()) }

    LaunchedEffect(Unit) {
        while (true) {
            currentTime = formatNow()
            delay(1000L)
        }
    }

    LaunchedEffect(cleared) {
        if (cleared) {
            delay(1400L)
            onClearComplete()
        }
    }

    val pulseTransition = rememberInfiniteTransition(label = "ring_pulse")
    val glowAlpha by pulseTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.65f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val bg = MaterialTheme.colorScheme.background

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        primary.copy(alpha = 0.22f),
                        bg,
                        secondary.copy(alpha = 0.14f)
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = primary.copy(alpha = glowAlpha * 0.28f),
                radius = size.minDimension * 0.45f,
                center = Offset(size.width * 0.5f, size.height * 0.22f)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 560.dp)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top badges & Live Clock
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = primary.copy(alpha = 0.20f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, primary.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = if (vibrateOnly) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                                contentDescription = null,
                                tint = primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (vibrateOnly) "VIBRATE ONLY · SILENT" else world.title.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = primary
                            )
                        }
                    }

                    if (isPreview) {
                        Surface(
                            color = secondary.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = "PREVIEW",
                                style = MaterialTheme.typography.labelSmall,
                                color = secondary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = currentTime,
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Text(
                    text = alarmLabel,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            // Companion Portrait & Dialogue Bubble
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(144.dp)
                        .clip(CircleShape)
                        .border(3.dp, primary, CircleShape)
                        .background(MaterialTheme.colorScheme.surface)
                ) {
                    Image(
                        painter = painterResource(id = world.portraitRes),
                        contentDescription = world.companionName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "${world.companionName} • ${world.japaneseTag}",
                            style = MaterialTheme.typography.labelLarge,
                            color = primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (cleared) world.clearedLine else world.wakePrompt,
                            style = MaterialTheme.typography.bodyLarge,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Interactive Wake-Up Challenge Area
            AnimatedContent(
                targetState = cleared,
                label = "challenge_or_cleared"
            ) { isDone ->
                if (isDone) {
                    Surface(
                        color = secondary.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(24.dp),
                        border = BorderStroke(1.5.dp, secondary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = "Cleared",
                                tint = secondary,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "STAGE CLEARED!",
                                style = MaterialTheme.typography.headlineMedium,
                                color = secondary
                            )
                            if (!isPreview) {
                                val bonus = if (challengeType == WakeChallengeType.NORMAL) 20 else 35
                                Text(
                                    text = "+$bonus Morning Stars ★ • +20 Kizuna Bond",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        when (challengeType) {
                            WakeChallengeType.NORMAL -> {
                                Button(
                                    onClick = { cleared = true },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(64.dp)
                                        .testTag("ring_clear_button"),
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = "OHAYOU · CLEAR ALARM",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                }
                            }

                            WakeChallengeType.RHYTHM_BEAT -> {
                                RhythmBeatChallenge(
                                    onCleared = { cleared = true }
                                )
                            }

                            WakeChallengeType.TURF_SPRINT -> {
                                TurfSprintChallenge(
                                    onCleared = { cleared = true }
                                )
                            }

                            WakeChallengeType.HALO_CIPHER -> {
                                HaloCipherChallenge(
                                    onCleared = { cleared = true }
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = onSnooze,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("ring_snooze_button"),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Rounded.Snooze, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Snooze 5 Minutes")
                        }
                    }
                }
            }
        }
    }
}

private data class FallingNote(
    val id: Int,
    val lane: Int,
    var progress: Float
)

@Composable
private fun RhythmBeatChallenge(onCleared: () -> Unit) {
    val targetHits = 6
    var hits by remember { mutableIntStateOf(0) }
    var feedback by remember { mutableStateOf("Tap glowing lanes as stars reach the bar!") }
    val notes = remember { mutableStateListOf<FallingNote>() }
    var nextNoteId by remember { mutableIntStateOf(1) }

    LaunchedEffect(Unit) {
        var tick = 0
        while (hits < targetHits) {
            if (tick % 16 == 0) {
                notes.add(FallingNote(id = nextNoteId++, lane = (0..3).random(), progress = 0f))
            }
            val iterator = notes.listIterator()
            while (iterator.hasNext()) {
                val n = iterator.next()
                val updated = n.progress + 0.032f
                if (updated > 1.12f) {
                    iterator.remove()
                } else {
                    iterator.set(n.copy(progress = updated))
                }
            }
            tick++
            delay(32L)
        }
    }

    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val laneSymbols = listOf("★", "♪", "✦", "♥")

    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, primary.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = primary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("LIVE BEAT TAP", style = MaterialTheme.typography.labelLarge, color = primary)
                }
                Text("$hits / $targetHits COMBO", style = MaterialTheme.typography.labelSmall, color = secondary)
            }

            Spacer(Modifier.height(6.dp))
            Text(feedback, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Black.copy(alpha = 0.35f))
            ) {
                val laneWidth = size.width / 4f
                val hitY = size.height * 0.78f
                for (i in 1..3) {
                    drawLine(
                        color = Color.White.copy(alpha = 0.12f),
                        start = Offset(laneWidth * i, 0f),
                        end = Offset(laneWidth * i, size.height),
                        strokeWidth = 2f
                    )
                }
                drawLine(
                    color = secondary.copy(alpha = 0.85f),
                    start = Offset(0f, hitY),
                    end = Offset(size.width, hitY),
                    strokeWidth = 5f
                )
                notes.forEach { note ->
                    val cx = laneWidth * note.lane + laneWidth / 2f
                    val cy = note.progress * hitY
                    drawCircle(
                        color = primary,
                        radius = 16.dp.toPx(),
                        center = Offset(cx, cy)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 7.dp.toPx(),
                        center = Offset(cx, cy)
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                laneSymbols.forEachIndexed { laneIdx, sym ->
                    val hasReadyNote = notes.any { it.lane == laneIdx && it.progress in 0.55f..1.10f }
                    Button(
                        onClick = {
                            val match = notes.firstOrNull {
                                it.lane == laneIdx && it.progress in 0.45f..1.12f
                            }
                            if (match != null) {
                                notes.remove(match)
                                hits++
                                feedback = if (hits >= targetHits) "FULL COMBO!" else "PERFECT! ★"
                                if (hits >= targetHits) onCleared()
                            } else {
                                feedback = "Wait for a star in lane ${laneIdx + 1}!"
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("rhythm_lane_$laneIdx"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (hasReadyNote) secondary else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (hasReadyNote) Color.Black else MaterialTheme.colorScheme.onSurface
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(sym, style = MaterialTheme.typography.titleLarge)
                    }
                }
            }
        }
    }
}

@Composable
private fun TurfSprintChallenge(onCleared: () -> Unit) {
    var progress by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        while (progress < 1f) {
            delay(120L)
            progress = (progress - 0.015f).coerceAtLeast(0f)
        }
    }

    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary

    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, primary.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("LAST SPURT DASH!", style = MaterialTheme.typography.labelLarge, color = primary)
                Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = secondary)
            }
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(14.dp)
                    .clip(RoundedCornerShape(50)),
                color = primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = {
                    val next = (progress + 0.14f).coerceAtMost(1f)
                    progress = next
                    if (next >= 1f) onCleared()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .testTag("turf_dash_button"),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(Icons.Rounded.Bolt, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("TAP RAPIDLY TO SPRINT!", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@Composable
private fun HaloCipherChallenge(onCleared: () -> Unit) {
    val allGlyphs = remember { listOf("★", "◈", "☾", "⚡", "✿", "❖") }
    val targetSequence = remember { allGlyphs.shuffled().take(4) }
    val shuffledChoices = remember { allGlyphs.shuffled() }
    var stepIndex by remember { mutableIntStateOf(0) }
    var statusText by remember { mutableStateOf("Tap the 4 glyphs in exact order") }

    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary

    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, primary.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("TACTICAL CIPHER", style = MaterialTheme.typography.labelLarge, color = primary)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                targetSequence.forEachIndexed { idx, glyph ->
                    val matched = idx < stepIndex
                    Surface(
                        color = if (matched) secondary.copy(alpha = 0.28f) else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            1.5.dp,
                            if (idx == stepIndex) primary else Color.Transparent
                        )
                    ) {
                        Text(
                            text = glyph,
                            style = MaterialTheme.typography.titleLarge,
                            color = if (matched) secondary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(statusText, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                shuffledChoices.forEach { glyph ->
                    Button(
                        onClick = {
                            if (glyph == targetSequence[stepIndex]) {
                                stepIndex++
                                if (stepIndex >= targetSequence.size) {
                                    statusText = "CIPHER VERIFIED!"
                                    onCleared()
                                } else {
                                    statusText = "Verified ${stepIndex}/${targetSequence.size}"
                                }
                            } else {
                                stepIndex = 0
                                statusText = "Mismatch! Sequence reset—start from glyph 1."
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("cipher_btn_$glyph"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurface
                        )
                    ) {
                        Text(glyph, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private fun formatNow(): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
