package com.example.alarm

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.data.PreferencesManager
import com.example.haptics.VibrationEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

class HourlyChimeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_HOURLY_JIHO) return
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                NotificationChannels.ensureCreated(context)
                val prefs = PreferencesManager(context)
                val settings = prefs.getHapticSettingsSnapshot()
                val world = prefs.getActiveWorldSnapshot()

                if (!settings.jihoEnabled) return@launch

                val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                if (AlarmScheduler.isHourInWindow(currentHour, settings.jihoStartHour, settings.jihoEndHour)) {
                    val vibrationEngine = VibrationEngine(context)
                    vibrationEngine.vibrateJiho(
                        pattern = settings.jihoPattern,
                        strengthPercent = settings.vibrationStrength,
                        hourOfDay = currentHour
                    )

                    postSilentJihoNotification(context, currentHour, world.companionName, world.jihoLines)
                }

                AlarmScheduler(context).scheduleNextHourlyJiho(settings)
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun postSilentJihoNotification(
        context: Context,
        hourOfDay: Int,
        companionName: String,
        lines: List<String>
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }
        val hourLabel = String.format("%02d:00", hourOfDay)
        val quote = lines[hourOfDay % lines.size]
        val openAppIntent = android.app.PendingIntent.getActivity(
            context,
            99_002,
            Intent(context, MainActivity::class.java),
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, NotificationChannels.JIHO_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("$hourLabel 時報 Jihō • $companionName")
            .setContentText(quote)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setSilent(true)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent)
            .build()

        NotificationManagerCompat.from(context).notify(JIHO_NOTIFICATION_ID, notification)
    }

    companion object {
        const val ACTION_HOURLY_JIHO = "com.example.alarm.ACTION_HOURLY_JIHO"
        const val JIHO_NOTIFICATION_ID = 4402
    }
}
