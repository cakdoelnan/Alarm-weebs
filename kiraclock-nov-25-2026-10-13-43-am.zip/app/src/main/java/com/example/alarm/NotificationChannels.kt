package com.example.alarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.example.R

object NotificationChannels {
    const val ALARM_CHANNEL_ID = "kiraclock_alarm_channel_v2"
    const val JIHO_CHANNEL_ID = "kiraclock_jiho_channel_v2"

    fun ensureCreated(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val alarmChannel = NotificationChannel(
            ALARM_CHANNEL_ID,
            context.getString(R.string.alarm_channel_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = context.getString(R.string.alarm_channel_desc)
            // Audio and vibration are managed directly by AlarmRingingService so Vibrate-Only
            // mode and custom vibration strength work accurately.
            setSound(null, null)
            enableVibration(false)
            lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
        }

        val jihoChannel = NotificationChannel(
            JIHO_CHANNEL_ID,
            context.getString(R.string.jiho_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = context.getString(R.string.jiho_channel_desc)
            setSound(null, null)
            enableVibration(false)
        }

        manager.createNotificationChannel(alarmChannel)
        manager.createNotificationChannel(jihoChannel)
    }
}
