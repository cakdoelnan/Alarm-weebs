package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.data.AlarmRepository
import com.example.data.AppDatabase
import com.example.data.PreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_TRIGGER_ALARM) return

        val alarmId = intent.getIntExtra(AlarmScheduler.EXTRA_ALARM_ID, -1)
        val isSnooze = intent.getBooleanExtra(AlarmScheduler.EXTRA_IS_SNOOZE, false)

        val serviceIntent = Intent(context, AlarmRingingService::class.java).apply {
            action = AlarmRingingService.ACTION_START
            putExtras(intent)
        }
        ContextCompat.startForegroundService(context, serviceIntent)

        if (alarmId > 0 && !isSnooze) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val repo = AlarmRepository(
                        AppDatabase.getInstance(context).alarmDao(),
                        PreferencesManager(context)
                    )
                    val alarm = repo.getAlarmById(alarmId)
                    if (alarm != null) {
                        if (alarm.repeatDaysMask == 0) {
                            repo.toggleAlarm(alarm.id, false)
                        } else {
                            AlarmScheduler(context).scheduleAlarm(alarm)
                        }
                    }
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }

    companion object {
        const val ACTION_TRIGGER_ALARM = "com.example.alarm.ACTION_TRIGGER_ALARM"
    }
}
