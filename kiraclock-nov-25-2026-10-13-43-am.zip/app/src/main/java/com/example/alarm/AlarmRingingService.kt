package com.example.alarm

import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.audio.AnimeChimeSynthesizer
import com.example.data.AlarmRepository
import com.example.data.AppDatabase
import com.example.data.PreferencesManager
import com.example.haptics.VibrationEngine
import com.example.model.WakeChallengeType
import com.example.model.WorldTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class AlarmRingingService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var vibrationEngine: VibrationEngine
    private val synthesizer = AnimeChimeSynthesizer()

    private var currentAlarmId: Int = -1
    private var currentLabel: String = "KiraClock Alarm"
    private var currentVibrateOnly: Boolean = false
    private var currentChallengeId: String = WakeChallengeType.NORMAL.id
    private var currentWorldId: String = WorldTheme.STARLIGHT_BEAT.id
    private var currentStrengthOverride: Int = -1
    private var isPreviewMode: Boolean = false

    override fun onCreate() {
        super.onCreate()
        NotificationChannels.ensureCreated(this)
        vibrationEngine = VibrationEngine(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopAlarmAndSelf()
                return START_NOT_STICKY
            }
            ACTION_SNOOZE -> {
                val scheduler = AlarmScheduler(this)
                if (!isPreviewMode && currentAlarmId > 0) {
                    scheduler.scheduleSnooze(
                        alarmId = currentAlarmId,
                        label = currentLabel.removeSuffix(" (Snooze)"),
                        vibrateOnly = currentVibrateOnly,
                        challengeType = currentChallengeId,
                        worldThemeId = currentWorldId,
                        strengthOverride = currentStrengthOverride
                    )
                }
                stopAlarmAndSelf()
                return START_NOT_STICKY
            }
        }

        currentAlarmId = intent?.getIntExtra(AlarmScheduler.EXTRA_ALARM_ID, -1) ?: -1
        currentLabel = intent?.getStringExtra(AlarmScheduler.EXTRA_ALARM_LABEL)
            ?.takeIf { it.isNotBlank() } ?: "Morning Call"
        currentVibrateOnly = intent?.getBooleanExtra(AlarmScheduler.EXTRA_VIBRATE_ONLY, false) ?: false
        currentChallengeId = intent?.getStringExtra(AlarmScheduler.EXTRA_CHALLENGE_TYPE)
            ?: WakeChallengeType.NORMAL.id
        currentWorldId = intent?.getStringExtra(AlarmScheduler.EXTRA_WORLD_THEME_ID)
            ?: WorldTheme.STARLIGHT_BEAT.id
        currentStrengthOverride = intent?.getIntExtra(AlarmScheduler.EXTRA_STRENGTH_OVERRIDE, -1) ?: -1
        isPreviewMode = intent?.getBooleanExtra(AlarmScheduler.EXTRA_IS_PREVIEW, false) ?: false

        val ringIntent = Intent(this, AlarmRingActivity::class.java).apply {
            this.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(AlarmScheduler.EXTRA_ALARM_ID, currentAlarmId)
            putExtra(AlarmScheduler.EXTRA_ALARM_LABEL, currentLabel)
            putExtra(AlarmScheduler.EXTRA_VIBRATE_ONLY, currentVibrateOnly)
            putExtra(AlarmScheduler.EXTRA_CHALLENGE_TYPE, currentChallengeId)
            putExtra(AlarmScheduler.EXTRA_WORLD_THEME_ID, currentWorldId)
            putExtra(AlarmScheduler.EXTRA_IS_PREVIEW, isPreviewMode)
        }
        val fullScreenPending = PendingIntent.getActivity(
            this,
            90_001,
            ringIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val dismissPending = PendingIntent.getService(
            this,
            90_002,
            Intent(this, AlarmRingingService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val world = WorldTheme.fromId(currentWorldId)
        val modeTag = if (currentVibrateOnly) "Vibrate Only (Silent)" else world.title
        val notification = NotificationCompat.Builder(this, NotificationChannels.ALARM_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("${world.companionName} • $currentLabel")
            .setContentText("$modeTag — Tap to clear wake-up")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setAutoCancel(false)
            .setFullScreenIntent(fullScreenPending, true)
            .setContentIntent(fullScreenPending)
            .addAction(0, getString(R.string.dismiss_alarm), dismissPending)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        serviceScope.launch {
            val prefs = PreferencesManager(this@AlarmRingingService)
            val settings = prefs.getHapticSettingsSnapshot()
            val strength = if (currentStrengthOverride in 10..100) {
                currentStrengthOverride
            } else {
                settings.vibrationStrength
            }

            vibrationEngine.startAlarmVibrationLoop(strength)

            if (!currentVibrateOnly) {
                synthesizer.startAlarmLoop(
                    context = this@AlarmRingingService,
                    world = world,
                    speakGreeting = settings.voiceGreetingEnabled
                )
            } else {
                synthesizer.stop()
            }

            // Also launch activity directly if screen is unlocked/interactive
            try {
                startActivity(ringIntent)
            } catch (_: Exception) {
            }
        }

        return START_NOT_STICKY
    }

    private fun stopAlarmAndSelf() {
        vibrationEngine.stopVibration()
        synthesizer.stop()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    override fun onDestroy() {
        vibrationEngine.stopVibration()
        synthesizer.stop()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val NOTIFICATION_ID = 4401
        const val ACTION_START = "com.example.alarm.ACTION_START"
        const val ACTION_STOP = "com.example.alarm.ACTION_STOP"
        const val ACTION_SNOOZE = "com.example.alarm.ACTION_SNOOZE"
    }
}
