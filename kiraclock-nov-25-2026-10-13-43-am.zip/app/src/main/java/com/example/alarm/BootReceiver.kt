package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.AlarmRepository
import com.example.data.AppDatabase
import com.example.data.PreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repo = AlarmRepository(
                    AppDatabase.getInstance(context).alarmDao(),
                    PreferencesManager(context)
                )
                val scheduler = AlarmScheduler(context)
                repo.getEnabledAlarms().forEach { alarm ->
                    scheduler.scheduleAlarm(alarm)
                }
                val settings = repo.getHapticSettingsSnapshot()
                if (settings.jihoEnabled) {
                    scheduler.scheduleNextHourlyJiho(settings)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
