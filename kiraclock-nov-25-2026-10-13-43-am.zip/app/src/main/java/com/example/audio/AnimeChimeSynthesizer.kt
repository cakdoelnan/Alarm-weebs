package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import com.example.model.WorldTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class AnimeChimeSynthesizer {

    private var playJob: Job? = null
    private var audioTrack: AudioTrack? = null
    private var tts: TextToSpeech? = null

    fun startAlarmLoop(
        context: Context,
        world: WorldTheme,
        speakGreeting: Boolean
    ) {
        stop()
        val sampleRate = 44100
        val pcmBuffer = buildMelodyPcm(world.melodyNotesHz, sampleRate)

        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(pcmBuffer.size * 2)

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        val format = AudioFormat.Builder()
            .setSampleRate(sampleRate)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()

        val track = AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(format)
            .setBufferSizeInBytes(minBuf)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack = track
        track.play()

        playJob = CoroutineScope(Dispatchers.Default).launch {
            while (isActive) {
                track.write(pcmBuffer, 0, pcmBuffer.size)
            }
        }

        if (speakGreeting) {
            triggerVoiceGreeting(context.applicationContext, world)
        }
    }

    fun playPreview(world: WorldTheme) {
        stop()
        val sampleRate = 44100
        val pcmBuffer = buildMelodyPcm(world.melodyNotesHz, sampleRate)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val format = AudioFormat.Builder()
            .setSampleRate(sampleRate)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()

        val track = AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(format)
            .setBufferSizeInBytes((pcmBuffer.size * 2).coerceAtLeast(8192))
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        audioTrack = track
        track.write(pcmBuffer, 0, pcmBuffer.size)
        track.play()
    }

    private fun triggerVoiceGreeting(context: Context, world: WorldTheme) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                tts?.setPitch(1.18f)
                tts?.setSpeechRate(1.02f)
                tts?.speak(world.greetingLine, TextToSpeech.QUEUE_FLUSH, null, "kira_greeting")
            }
        }
    }

    fun stop() {
        playJob?.cancel()
        playJob = null
        try {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.release()
        } catch (_: Exception) {
        }
        audioTrack = null
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
    }

    private fun buildMelodyPcm(notesHz: DoubleArray, sampleRate: Int): ShortArray {
        val noteSamples = (sampleRate * 0.24).toInt()
        val pauseSamples = (sampleRate * 0.45).toInt()
        val totalSamples = notesHz.size * noteSamples + pauseSamples
        val output = ShortArray(totalSamples)

        notesHz.forEachIndexed { idx, freq ->
            val offset = idx * noteSamples
            for (i in 0 until noteSamples) {
                val t = i.toDouble() / sampleRate
                val attack = (i / (sampleRate * 0.015)).coerceAtMost(1.0)
                val decay = exp(-t * 5.2)
                val env = attack * decay
                // Warm bell/synth blend: fundamental + soft 2nd harmonic + gentle 3rd shimmer
                val wave = 0.65 * sin(2.0 * PI * freq * t) +
                    0.25 * sin(2.0 * PI * (freq * 2.0) * t) +
                    0.10 * sin(2.0 * PI * (freq * 3.0) * t)
                val sample = (wave * env * 0.42 * Short.MAX_VALUE).toInt()
                    .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                output[offset + i] = sample.toShort()
            }
        }
        return output
    }
}
