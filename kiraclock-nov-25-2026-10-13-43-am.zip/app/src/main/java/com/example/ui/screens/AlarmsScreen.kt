package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.AlarmEntity
import com.example.model.WakeChallengeType
import com.example.model.WorldTheme
import com.example.ui.KiraUiState
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AlarmsScreen(
    uiState: KiraUiState,
    needsNotificationPermission: Boolean,
    onRequestNotificationPermission: () -> Unit,
    onAddAlarmClick: () -> Unit,
    onQuickPresetCreate: (hour: Int, minute: Int, label: String, vibrateOnly: Boolean, challenge: WakeChallengeType) -> Unit,
    onEditAlarm: (AlarmEntity) -> Unit,
    onToggleAlarm: (AlarmEntity, Boolean) -> Unit,
    onToggleAlarmVibrateOnly: (AlarmEntity, Boolean) -> Unit,
    onDeleteAlarm: (Int) -> Unit,
    onPreviewAlarm: (AlarmEntity) -> Unit,
    onPreviewActiveWorld: (vibrateOnly: Boolean) -> Unit,
    onOpenJihoTab: () -> Unit
) {
    var clockText by remember { mutableStateOf(formatClock()) }
    var dateText by remember { mutableStateOf(formatDate()) }

    LaunchedEffect(Unit) {
        while (true) {
            clockText = formatClock()
            dateText = formatDate()
            delay(1000L)
        }
    }

    val world = uiState.activeWorld
    val nextAlarmMillis = remember(uiState.alarms) {
        uiState.alarms.filter { it.enabled }
            .minOfOrNull { it.computeNextTriggerMillis() }
    }
    val nextCountdown = remember(nextAlarmMillis, clockText) {
        nextAlarmMillis?.let { formatCountdown(it - System.currentTimeMillis()) }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 104.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (needsNotificationPermission) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                Icons.Rounded.NotificationsActive,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Enable Alarm & Jiho Alerts",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = "Needed so wake-up screens and hourly Jiho reminders appear reliably.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Button(
                                onClick = onRequestNotificationPermission,
                                modifier = Modifier.testTag("grant_notifications_button")
                            ) {
                                Text("Allow")
                            }
                        }
                    }
                }
            }

            // Anime Companion Hero Stage
            item {
                CompanionStageCard(
                    world = world,
                    clockText = clockText,
                    dateText = dateText,
                    nextCountdown = nextCountdown,
                    morningStars = uiState.companionStats.morningStars,
                    streak = uiState.companionStats.wakeStreak,
                    bondLevel = uiState.companionStats.bondLevel(world),
                    onPreviewSoundChallenge = { onPreviewActiveWorld(false) },
                    onPreviewVibrateOnly = { onPreviewActiveWorld(true) }
                )
            }

            // Quick Haptics & Jiho Summary Strip
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onOpenJihoTab)
                        .testTag("haptic_summary_strip")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                Icons.Rounded.Vibration,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary
                            )
                            Column {
                                Text(
                                    text = "Strength ${uiState.hapticSettings.vibrationStrength}% · ${uiState.hapticSettings.strengthTierLabel}",
                                    style = MaterialTheme.typography.labelLarge
                                )
                                Text(
                                    text = if (uiState.hapticSettings.jihoEnabled) {
                                        val s = String.format("%02d", uiState.hapticSettings.jihoStartHour)
                                        val e = String.format("%02d", uiState.hapticSettings.jihoEndHour)
                                        "Jihō Hourly Pulse ON ($s:00–$e:00)"
                                    } else {
                                        "Jihō Hourly Pulse OFF • Tap to configure"
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Icon(
                            Icons.Rounded.Schedule,
                            contentDescription = "Configure Jiho",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Your Alarms (${uiState.alarms.size})",
                        style = MaterialTheme.typography.titleLarge
                    )
                    FilledTonalButton(
                        onClick = onAddAlarmClick,
                        modifier = Modifier.testTag("top_add_alarm_button")
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("New")
                    }
                }
            }

            if (uiState.alarms.isEmpty()) {
                item {
                    EmptyAlarmsCard(
                        onAddAlarmClick = onAddAlarmClick,
                        onQuickPresetCreate = onQuickPresetCreate
                    )
                }
            } else {
                items(uiState.alarms, key = { it.id }) { alarm ->
                    AlarmCard(
                        alarm = alarm,
                        onClick = { onEditAlarm(alarm) },
                        onToggle = { enabled -> onToggleAlarm(alarm, enabled) },
                        onToggleVibrateOnly = { vibOnly -> onToggleAlarmVibrateOnly(alarm, vibOnly) },
                        onPreview = { onPreviewAlarm(alarm) },
                        onDelete = { onDeleteAlarm(alarm.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CompanionStageCard(
    world: WorldTheme,
    clockText: String,
    dateText: String,
    nextCountdown: String?,
    morningStars: Int,
    streak: Int,
    bondLevel: Int,
    onPreviewSoundChallenge: () -> Unit,
    onPreviewVibrateOnly: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary

    Card(
        shape = RoundedCornerShape(28.dp),
        border = BorderStroke(1.dp, primary.copy(alpha = 0.45f)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            primary.copy(alpha = 0.22f),
                            MaterialTheme.colorScheme.surface,
                            secondary.copy(alpha = 0.14f)
                        )
                    )
                )
                .padding(18.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                color = primary.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = "${world.title} · Lv.$bondLevel",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = primary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                            Surface(
                                color = secondary.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Icon(
                                        Icons.Rounded.Star,
                                        contentDescription = null,
                                        tint = secondary,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = "$morningStars · ${streak}d",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = secondary
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.height(6.dp))

                        Text(
                            text = clockText,
                            style = MaterialTheme.typography.displayLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (nextCountdown != null) {
                                "$dateText  •  Next in $nextCountdown"
                            } else {
                                "$dateText  •  No active alarms"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(Modifier.width(12.dp))

                    Box(
                        modifier = Modifier
                            .size(92.dp)
                            .clip(CircleShape)
                            .border(2.5.dp, primary, CircleShape)
                    ) {
                        Image(
                            painter = painterResource(id = world.portraitRes),
                            contentDescription = world.companionName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                // Dialogue bubble
                Surface(
                    color = MaterialTheme.colorScheme.background.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "\"${world.greetingLine}\" — ${world.companionName}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                    )
                }

                // Quick Preview Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onPreviewVibrateOnly,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("hero_preview_vibrate_only"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Rounded.VolumeOff, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Test Silent", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Button(
                        onClick = onPreviewSoundChallenge,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("hero_preview_anime_alarm"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = primary)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Demo Ring", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun AlarmCard(
    alarm: AlarmEntity,
    onClick: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onToggleVibrateOnly: (Boolean) -> Unit,
    onPreview: () -> Unit,
    onDelete: () -> Unit
) {
    val world = alarm.worldTheme
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (alarm.enabled) {
                MaterialTheme.colorScheme.surface
            } else {
                MaterialTheme.colorScheme.surface.copy(alpha = 0.62f)
            }
        ),
        border = BorderStroke(
            1.dp,
            if (alarm.enabled) primary.copy(alpha = 0.4f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("alarm_card_${alarm.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = alarm.formattedTime(),
                            style = MaterialTheme.typography.displayMedium,
                            color = if (alarm.enabled) {
                                MaterialTheme.colorScheme.onSurface
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                        Surface(
                            color = secondary.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = alarm.challenge.shortBadge,
                                style = MaterialTheme.typography.labelSmall,
                                color = secondary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Text(
                        text = "${alarm.label} • ${alarm.repeatSummary()}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Switch(
                    checked = alarm.enabled,
                    onCheckedChange = onToggle,
                    modifier = Modifier.testTag("alarm_switch_${alarm.id}")
                )
            }

            // Bottom action strip: 1-tap Vibrate-Only pill, companion name, preview & delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = if (alarm.vibrateOnly) {
                            primary.copy(alpha = 0.22f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant
                        },
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(
                            1.dp,
                            if (alarm.vibrateOnly) primary else MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier
                            .clickable { onToggleVibrateOnly(!alarm.vibrateOnly) }
                            .testTag("alarm_vibrate_toggle_${alarm.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = if (alarm.vibrateOnly) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                                contentDescription = "Toggle vibrate only",
                                tint = if (alarm.vibrateOnly) primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = if (alarm.vibrateOnly) "Vibrate Only" else "Sound + Vibrate",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (alarm.vibrateOnly) primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Text(
                        text = world.companionName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onPreview,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("alarm_preview_${alarm.id}")
                    ) {
                        Icon(
                            Icons.Rounded.PlayArrow,
                            contentDescription = "Test alarm",
                            tint = secondary
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("alarm_delete_${alarm.id}")
                    ) {
                        Icon(
                            Icons.Rounded.DeleteOutline,
                            contentDescription = "Delete alarm",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyAlarmsCard(
    onAddAlarmClick: () -> Unit,
    onQuickPresetCreate: (hour: Int, minute: Int, label: String, vibrateOnly: Boolean, challenge: WakeChallengeType) -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.Alarm,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(44.dp)
            )
            Text(
                text = "No Alarms Armed Yet",
                style = MaterialTheme.typography.titleLarge
            )
            Text(
                text = "Create a custom anime wake-up alarm or tap a quick preset below:",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        onQuickPresetCreate(6, 30, "Morning Rehearsal", false, WakeChallengeType.RHYTHM_BEAT)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("preset_rehearsal_btn"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("06:30 · Idol Rehearsal (Rhythm Tap)")
                }

                OutlinedButton(
                    onClick = {
                        onQuickPresetCreate(7, 0, "Silent Morning", true, WakeChallengeType.TURF_SPRINT)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("preset_silent_btn"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Rounded.VolumeOff, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("07:00 · Vibrate Only (Turf Sprint)")
                }

                Button(
                    onClick = onAddAlarmClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("empty_create_custom_btn"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Custom Alarm", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun formatClock(): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

private fun formatDate(): String =
    SimpleDateFormat("EEE, dd MMM", Locale.getDefault()).format(Date())

private fun formatCountdown(deltaMillis: Long): String {
    if (deltaMillis <= 60_000L) return "< 1m"
    val totalMinutes = deltaMillis / 60_000L
    val hours = totalMinutes / 60
    val mins = totalMinutes % 60
    return if (hours > 0) "${hours}h ${mins}m" else "${mins}m"
}
