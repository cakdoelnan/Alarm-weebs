package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Starlight Beat (BanG Dream! inspired neon sakura & stage cyan)
val StarlightPrimary = Color(0xFFFF408C)
val StarlightSecondary = Color(0xFF00E5FF)
val StarlightTertiary = Color(0xFFFFD54F)
val StarlightBackground = Color(0xFF100C1E)
val StarlightSurface = Color(0xFF1A1430)
val StarlightSurfaceVariant = Color(0xFF261E42)

// Tracen Turf (Uma Musume inspired emerald turf & derby gold)
val TracenPrimary = Color(0xFF1CE07B)
val TracenSecondary = Color(0xFFFFCA28)
val TracenTertiary = Color(0xFFFF7043)
val TracenBackground = Color(0xFF0A1711)
val TracenSurface = Color(0xFF12261D)
val TracenSurfaceVariant = Color(0xFF1C382B)

// Schale Halo (Blue Archive inspired sky cyan & crisp tactical slate)
val SchalePrimary = Color(0xFF29B6F6)
val SchaleSecondary = Color(0xFF80D8FF)
val SchaleTertiary = Color(0xFFFF6E96)
val SchaleBackground = Color(0xFF091424)
val SchaleSurface = Color(0xFF112038)
val SchaleSurfaceVariant = Color(0xFF1A2F4F)

// Astral Wish (Genshin Impact inspired celestial gold & starry indigo)
val AstralPrimary = Color(0xFFF5C451)
val AstralSecondary = Color(0xFF8C7AE6)
val AstralTertiary = Color(0xFF4DD0E1)
val AstralBackground = Color(0xFF0B0E1D)
val AstralSurface = Color(0xFF141933)
val AstralSurfaceVariant = Color(0xFF20274D)

val TextPrimaryDark = Color(0xFFF6F7FB)
val TextSecondaryDark = Color(0xFFB5B9D1)
val OutlineDark = Color(0xFF363D63)
val ErrorNeon = Color(0xFFFF526B)
