package com.example.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.alarm.AlarmScheduler
import com.example.model.JihoPattern
import com.example.ui.KiraUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun JihoHapticsScreen(
    uiState: KiraUiState,
    onVibrationStrengthChange: (Int) -> Unit,
    onPreviewStrength: (Int) -> Unit,
    onGlobalVibrateOnlyDefaultChange: (Boolean) -> Unit,
    onPreviewSilentAlarm: () -> Unit,
    onJihoEnabledChange: (Boolean) -> Unit,
    onJihoHoursChange: (Int, Int) -> Unit,
    onJihoPatternSelect: (JihoPattern) -> Unit,
    onJihoSilentVibrateOnlyChange: (Boolean) -> Unit,
    onTestJihoNow: () -> Unit,
    onRequestExactAlarmPermission: () -> Unit
) {
    val settings = uiState.hapticSettings
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary

    val nextJihoFormatted = remember(
        settings.jihoEnabled,
        settings.jihoStartHour,
        settings.jihoEndHour
    ) {
        if (!settings.jihoEnabled) {
            null
        } else {
            AlarmScheduler.computeNextJihoMillis(
                nowMillis = System.currentTimeMillis(),
                startHour = settings.jihoStartHour,
                endHour = settings.jihoEndHour
            )?.let { millis ->
                SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(millis))
            }
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 104.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "時報 Jihō & Haptics",
                        style = MaterialTheme.typography.headlineLarge
                    )
                    Text(
                        text = "Tune vibration intensity, silent vibrate-only defaults, and hourly time-signal pulses.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // 1. Vibration Strength Slider Card
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, primary.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(Icons.Rounded.Vibration, contentDescription = null, tint = primary)
                                Column {
                                    Text("Vibration Strength", style = MaterialTheme.typography.titleLarge)
                                    Text(
                                        text = settings.strengthTierLabel,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = secondary
                                    )
                                }
                            }
                            Surface(
                                color = primary.copy(alpha = 0.18f),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(
                                    text = "${settings.vibrationStrength}%",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = primary,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }

                        // Real-time Haptic Wave Visualizer
                        HapticIntensityWaveform(
                            strengthPercent = settings.vibrationStrength,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                        )

                        Slider(
                            value = settings.vibrationStrength.toFloat(),
                            onValueChange = { onVibrationStrengthChange(it.roundToInt()) },
                            onValueChangeFinished = { onPreviewStrength(settings.vibrationStrength) },
                            valueRange = 10f..100f,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("vibration_strength_slider")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                20 to "20% Soft",
                                50 to "50% Mid",
                                75 to "75% Idol",
                                100 to "100% Max"
                            ).forEach { (value, label) ->
                                FilterChip(
                                    selected = settings.vibrationStrength == value,
                                    onClick = {
                                        onVibrationStrengthChange(value)
                                        onPreviewStrength(value)
                                    },
                                    label = { Text(label) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        if (!uiState.hasAmplitudeControl) {
                            Text(
                                text = "Device uses pulse-duration modulation for strength scaling.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { onPreviewStrength(settings.vibrationStrength) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("test_vibration_button"),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Rounded.Vibration, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Test Pulse")
                            }
                            Button(
                                onClick = onPreviewSilentAlarm,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("preview_silent_alarm_button"),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Rounded.VolumeOff, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Demo Silent")
                            }
                        }

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Default New Alarms to Vibrate-Only",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = "New alarms start with zero sound enabled",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = settings.globalVibrateOnlyDefault,
                                    onCheckedChange = onGlobalVibrateOnlyDefaultChange,
                                    modifier = Modifier.testTag("default_vibrate_only_switch")
                                )
                            }
                        }
                    }
                }
            }

            // 2. Hourly Vibration (Jiho) Card
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, secondary.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(Icons.Rounded.Schedule, contentDescription = null, tint = secondary)
                                Column {
                                    Text("Hourly Vibration (Jihō)", style = MaterialTheme.typography.titleLarge)
                                    Text(
                                        text = if (nextJihoFormatted != null) {
                                            "Active • Next pulse at $nextJihoFormatted"
                                        } else {
                                            "Vibrates every hour on the hour (:00)"
                                        },
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (nextJihoFormatted != null) secondary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = settings.jihoEnabled,
                                onCheckedChange = onJihoEnabledChange,
                                modifier = Modifier.testTag("jiho_master_switch")
                            )
                        }

                        if (!uiState.canScheduleExactAlarms) {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        modifier = Modifier.weight(1f),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Rounded.NotificationsActive, contentDescription = null, tint = primary)
                                        Text(
                                            text = "Allow exact alarms for pinpoint :00 hourly vibration.",
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                    Spacer(Modifier.width(8.dp))
                                    OutlinedButton(onClick = onRequestExactAlarmPermission) {
                                        Text("Enable")
                                    }
                                }
                            }
                        }

                        // Active Hours Window
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("Active Hours Window", style = MaterialTheme.typography.titleMedium)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    HourStepper(
                                        label = "Start Hour",
                                        hour = settings.jihoStartHour,
                                        onChange = { newStart ->
                                            onJihoHoursChange(newStart, settings.jihoEndHour)
                                        },
                                        tagPrefix = "jiho_start"
                                    )
                                    Text("→", style = MaterialTheme.typography.titleLarge, color = secondary)
                                    HourStepper(
                                        label = "End Hour",
                                        hour = settings.jihoEndHour,
                                        onChange = { newEnd ->
                                            onJihoHoursChange(settings.jihoStartHour, newEnd)
                                        },
                                        tagPrefix = "jiho_end"
                                    )
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    FilterChip(
                                        selected = settings.jihoStartHour == 7 && settings.jihoEndHour == 22,
                                        onClick = { onJihoHoursChange(7, 22) },
                                        label = { Text("07–22 Day") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    FilterChip(
                                        selected = settings.jihoStartHour == 9 && settings.jihoEndHour == 18,
                                        onClick = { onJihoHoursChange(9, 18) },
                                        label = { Text("09–18 Work") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    FilterChip(
                                        selected = settings.jihoStartHour == settings.jihoEndHour,
                                        onClick = { onJihoHoursChange(0, 0) },
                                        label = { Text("24 Hours") },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }

                        // Pulse Pattern Selector
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Hourly Pulse Pattern", style = MaterialTheme.typography.titleMedium)
                            JihoPattern.entries.forEach { pattern ->
                                val selected = settings.jihoPattern == pattern
                                Surface(
                                    color = if (selected) {
                                        secondary.copy(alpha = 0.16f)
                                    } else {
                                        MaterialTheme.colorScheme.surfaceVariant
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(
                                        1.dp,
                                        if (selected) secondary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onJihoPatternSelect(pattern) }
                                        .testTag("jiho_pattern_${pattern.id}")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = selected,
                                            onClick = { onJihoPatternSelect(pattern) }
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Column {
                                            Text(pattern.displayName, style = MaterialTheme.typography.titleMedium)
                                            Text(
                                                pattern.subtitle,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Silent Jiho toggle
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Silent Vibrate-Only Jihō", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        text = "Never plays notification sound—pure haptic pulse",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = settings.jihoSilentVibrateOnly,
                                    onCheckedChange = onJihoSilentVibrateOnlyChange,
                                    modifier = Modifier.testTag("jiho_silent_switch")
                                )
                            }
                        }

                        Button(
                            onClick = onTestJihoNow,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("test_jiho_button"),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Rounded.Vibration, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Test Hourly Jihō Pulse Now", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HapticIntensityWaveform(
    strengthPercent: Int,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "haptic_wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1400),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val trackColor = MaterialTheme.colorScheme.surfaceVariant
    val amplitudeFactor = (strengthPercent.coerceIn(10, 100) / 100f)

    Canvas(modifier = modifier) {
        val barCount = 24
        val gap = 4.dp.toPx()
        val barWidth = (size.width - gap * (barCount - 1)) / barCount
        val midY = size.height / 2f

        for (i in 0 until barCount) {
            val norm = i / barCount.toFloat()
            val wave = abs(sin(phase + norm * 4.2f))
            val heightRatio = (0.20f + 0.80f * wave * amplitudeFactor).coerceIn(0.15f, 1f)
            val barH = size.height * heightRatio
            val x = i * (barWidth + gap)
            val color = if (norm <= amplitudeFactor) {
                if (i % 2 == 0) primary else secondary
            } else {
                trackColor
            }
            drawRoundRect(
                color = color,
                topLeft = Offset(x, midY - barH / 2f),
                size = Size(barWidth, barH),
                cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
            )
        }
    }
}

@Composable
private fun HourStepper(
    label: String,
    hour: Int,
    onChange: (Int) -> Unit,
    tagPrefix: String
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = { onChange((hour + 23) % 24) },
                modifier = Modifier
                    .size(48.dp)
                    .testTag("${tagPrefix}_down")
            ) {
                Icon(Icons.Rounded.Remove, contentDescription = "Decrease $label")
            }
            Text(
                text = String.format("%02d:00", hour),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            IconButton(
                onClick = { onChange((hour + 1) % 24) },
                modifier = Modifier
                    .size(48.dp)
                    .testTag("${tagPrefix}_up")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Increase $label")
            }
        }
    }
}
