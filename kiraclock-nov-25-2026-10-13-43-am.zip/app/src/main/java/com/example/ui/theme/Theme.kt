package com.example.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import com.example.model.WorldTheme

private val KiraShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

fun colorSchemeForWorld(world: WorldTheme): ColorScheme {
    return when (world) {
        WorldTheme.STARLIGHT_BEAT -> darkColorScheme(
            primary = StarlightPrimary,
            onPrimary = Color(0xFF2B0013),
            primaryContainer = Color(0xFF4F1131),
            onPrimaryContainer = Color(0xFFFFD8E5),
            secondary = StarlightSecondary,
            onSecondary = Color(0xFF002026),
            secondaryContainer = Color(0xFF00404D),
            onSecondaryContainer = Color(0xFFB3F7FF),
            tertiary = StarlightTertiary,
            onTertiary = Color(0xFF2B1F00),
            background = StarlightBackground,
            onBackground = TextPrimaryDark,
            surface = StarlightSurface,
            onSurface = TextPrimaryDark,
            surfaceVariant = StarlightSurfaceVariant,
            onSurfaceVariant = TextSecondaryDark,
            outline = Color(0xFF473A73),
            error = ErrorNeon
        )

        WorldTheme.TRACEN_TURF -> darkColorScheme(
            primary = TracenPrimary,
            onPrimary = Color(0xFF002912),
            primaryContainer = Color(0xFF0E4728),
            onPrimaryContainer = Color(0xFFB9FCD4),
            secondary = TracenSecondary,
            onSecondary = Color(0xFF281D00),
            secondaryContainer = Color(0xFF4A3800),
            onSecondaryContainer = Color(0xFFFFECC0),
            tertiary = TracenTertiary,
            onTertiary = Color(0xFF2B0D00),
            background = TracenBackground,
            onBackground = TextPrimaryDark,
            surface = TracenSurface,
            onSurface = TextPrimaryDark,
            surfaceVariant = TracenSurfaceVariant,
            onSurfaceVariant = TextSecondaryDark,
            outline = Color(0xFF2D5944),
            error = ErrorNeon
        )

        WorldTheme.SCHALE_HALO -> darkColorScheme(
            primary = SchalePrimary,
            onPrimary = Color(0xFF001F33),
            primaryContainer = Color(0xFF0F3D5E),
            onPrimaryContainer = Color(0xFFC8ECFF),
            secondary = SchaleSecondary,
            onSecondary = Color(0xFF002333),
            secondaryContainer = Color(0xFF194259),
            onSecondaryContainer = Color(0xFFD9F4FF),
            tertiary = SchaleTertiary,
            onTertiary = Color(0xFF2D0011),
            background = SchaleBackground,
            onBackground = TextPrimaryDark,
            surface = SchaleSurface,
            onSurface = TextPrimaryDark,
            surfaceVariant = SchaleSurfaceVariant,
            onSurfaceVariant = TextSecondaryDark,
            outline = Color(0xFF2E4E7E),
            error = ErrorNeon
        )

        WorldTheme.ASTRAL_WISH -> darkColorScheme(
            primary = AstralPrimary,
            onPrimary = Color(0xFF2B1E00),
            primaryContainer = Color(0xFF4D3809),
            onPrimaryContainer = Color(0xFFFFECC2),
            secondary = AstralSecondary,
            onSecondary = Color(0xFF120B38),
            secondaryContainer = Color(0xFF2F2666),
            onSecondaryContainer = Color(0xFFE1DCFF),
            tertiary = AstralTertiary,
            onTertiary = Color(0xFF002429),
            background = AstralBackground,
            onBackground = TextPrimaryDark,
            surface = AstralSurface,
            onSurface = TextPrimaryDark,
            surfaceVariant = AstralSurfaceVariant,
            onSurfaceVariant = TextSecondaryDark,
            outline = OutlineDark,
            error = ErrorNeon
        )
    }
}

@Composable
fun KiraClockTheme(
    worldTheme: WorldTheme = WorldTheme.STARLIGHT_BEAT,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = colorSchemeForWorld(worldTheme),
        typography = KiraTypography,
        shapes = KiraShapes,
        content = content
    )
}
