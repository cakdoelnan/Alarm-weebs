package com.example.ui

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.alarm.AlarmRingingService
import com.example.alarm.AlarmScheduler
import com.example.alarm.HourlyChimeReceiver
import com.example.alarm.NotificationChannels
import com.example.audio.AnimeChimeSynthesizer
import com.example.data.AlarmEntity
import com.example.data.AlarmRepository
import com.example.data.AppDatabase
import com.example.data.PreferencesManager
import com.example.data.WakeLogEntity
import com.example.haptics.VibrationEngine
import com.example.model.CompanionStats
import com.example.model.HapticSettings
import com.example.model.JihoPattern
import com.example.model.WakeChallengeType
import com.example.model.WorldTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class KiraUiState(
    val alarms: List<AlarmEntity> = emptyList(),
    val wakeLogs: List<WakeLogEntity> = emptyList(),
    val activeWorld: WorldTheme = WorldTheme.STARLIGHT_BEAT,
    val hapticSettings: HapticSettings = HapticSettings(),
    val companionStats: CompanionStats = CompanionStats(),
    val canScheduleExactAlarms: Boolean = true,
    val hasVibrator: Boolean = true,
    val hasAmplitudeControl: Boolean = true
)

class KiraClockViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AlarmRepository(
        AppDatabase.getInstance(application).alarmDao(),
        PreferencesManager(application)
    )
    private val scheduler = AlarmScheduler(application)
    private val vibrationEngine = VibrationEngine(application)
    private val previewSynth = AnimeChimeSynthesizer()

    private val exactPermissionTick = MutableStateFlow(0)

    init {
        NotificationChannels.ensureCreated(application)
    }

    val uiState: StateFlow<KiraUiState> = combine(
        repo.alarmsFlow,
        repo.wakeLogsFlow,
        repo.activeWorldFlow,
        repo.hapticSettingsFlow,
        repo.companionStatsFlow,
        exactPermissionTick
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val alarms = values[0] as List<AlarmEntity>
        @Suppress("UNCHECKED_CAST")
        val logs = values[1] as List<WakeLogEntity>
        val world = values[2] as WorldTheme
        val haptics = values[3] as HapticSettings
        val stats = values[4] as CompanionStats

        KiraUiState(
            alarms = alarms,
            wakeLogs = logs,
            activeWorld = world,
            hapticSettings = haptics,
            companionStats = stats,
            canScheduleExactAlarms = scheduler.canScheduleExactAlarms(),
            hasVibrator = vibrationEngine.hasVibrator,
            hasAmplitudeControl = vibrationEngine.hasAmplitudeControl
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = KiraUiState(
            canScheduleExactAlarms = scheduler.canScheduleExactAlarms(),
            hasVibrator = vibrationEngine.hasVibrator,
            hasAmplitudeControl = vibrationEngine.hasAmplitudeControl
        )
    )

    fun refreshPermissionsState() {
        exactPermissionTick.value++
    }

    fun saveAlarm(
        existingId: Int = 0,
        hour: Int,
        minute: Int,
        label: String,
        repeatDaysMask: Int,
        vibrateOnly: Boolean,
        vibrateStrengthOverride: Int?,
        challengeType: WakeChallengeType,
        worldTheme: WorldTheme
    ) {
        viewModelScope.launch {
            val saved = repo.saveAlarm(
                AlarmEntity(
                    id = existingId,
                    hour = hour,
                    minute = minute,
                    label = label.ifBlank { "Morning Call" },
                    enabled = true,
                    repeatDaysMask = repeatDaysMask,
                    vibrateOnly = vibrateOnly,
                    vibrateStrengthOverride = vibrateStrengthOverride,
                    challengeType = challengeType.id,
                    worldThemeId = worldTheme.id
                )
            )
            scheduler.scheduleAlarm(saved)
        }
    }

    fun toggleAlarm(alarm: AlarmEntity, enabled: Boolean) {
        viewModelScope.launch {
            repo.toggleAlarm(alarm.id, enabled)
            val updated = alarm.copy(enabled = enabled)
            if (enabled) scheduler.scheduleAlarm(updated) else scheduler.cancelAlarm(alarm.id)
        }
    }

    fun toggleAlarmVibrateOnly(alarm: AlarmEntity, vibrateOnly: Boolean) {
        viewModelScope.launch {
            val updated = repo.updateVibrateOnly(alarm, vibrateOnly)
            if (updated.enabled) {
                scheduler.scheduleAlarm(updated)
            }
        }
    }

    fun deleteAlarm(alarmId: Int) {
        viewModelScope.launch {
            scheduler.cancelAlarm(alarmId)
            repo.deleteAlarm(alarmId)
        }
    }

    fun selectWorld(world: WorldTheme) {
        viewModelScope.launch {
            repo.setActiveWorld(world)
        }
    }

    fun setVibrationStrength(strength: Int) {
        viewModelScope.launch {
            repo.setVibrationStrength(strength)
        }
    }

    fun previewVibrationStrength(strength: Int) {
        vibrationEngine.previewStrength(strength)
    }

    fun setGlobalVibrateOnlyDefault(enabled: Boolean) {
        viewModelScope.launch {
            repo.setGlobalVibrateOnlyDefault(enabled)
        }
    }

    fun setVoiceGreetingEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repo.setVoiceGreetingEnabled(enabled)
        }
    }

    fun setJihoEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repo.setJihoEnabled(enabled)
            val latest = repo.getHapticSettingsSnapshot().copy(jihoEnabled = enabled)
            if (enabled) {
                scheduler.scheduleNextHourlyJiho(latest)
            } else {
                scheduler.cancelHourlyJiho()
            }
        }
    }

    fun setJihoHours(startHour: Int, endHour: Int) {
        viewModelScope.launch {
            repo.setJihoHours(startHour, endHour)
            val latest = repo.getHapticSettingsSnapshot().copy(
                jihoStartHour = startHour,
                jihoEndHour = endHour
            )
            if (latest.jihoEnabled) {
                scheduler.scheduleNextHourlyJiho(latest)
            }
        }
    }

    fun setJihoPattern(pattern: JihoPattern) {
        viewModelScope.launch {
            repo.setJihoPattern(pattern)
        }
    }

    fun setJihoSilentVibrateOnly(silent: Boolean) {
        viewModelScope.launch {
            repo.setJihoSilentVibrateOnly(silent)
        }
    }

    fun testJihoNow() {
        val current = uiState.value.hapticSettings
        vibrationEngine.vibrateJiho(current.jihoPattern, current.vibrationStrength)
    }

    fun previewChimeSound(world: WorldTheme) {
        previewSynth.playPreview(world)
    }

    fun launchAlarmPreview(
        vibrateOnly: Boolean,
        challengeType: WakeChallengeType,
        worldTheme: WorldTheme,
        strengthOverride: Int? = null
    ) {
        val app = getApplication<Application>()
        val serviceIntent = Intent(app, AlarmRingingService::class.java).apply {
            action = AlarmRingingService.ACTION_START
            putExtra(AlarmScheduler.EXTRA_ALARM_ID, -1)
            putExtra(
                AlarmScheduler.EXTRA_ALARM_LABEL,
                if (vibrateOnly) "Silent Vibrate Preview" else "${worldTheme.title} Preview"
            )
            putExtra(AlarmScheduler.EXTRA_VIBRATE_ONLY, vibrateOnly)
            putExtra(AlarmScheduler.EXTRA_CHALLENGE_TYPE, challengeType.id)
            putExtra(AlarmScheduler.EXTRA_WORLD_THEME_ID, worldTheme.id)
            putExtra(AlarmScheduler.EXTRA_STRENGTH_OVERRIDE, strengthOverride ?: -1)
            putExtra(AlarmScheduler.EXTRA_IS_PREVIEW, true)
        }
        ContextCompat.startForegroundService(app, serviceIntent)
    }

    override fun onCleared() {
        previewSynth.stop()
        super.onCleared()
    }
}
