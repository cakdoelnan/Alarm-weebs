package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.AlarmEntity
import com.example.model.WakeChallengeType
import com.example.model.WorldTheme
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlarmEditorSheet(
    existingAlarm: AlarmEntity?,
    defaultWorld: WorldTheme,
    defaultVibrateOnly: Boolean,
    globalStrength: Int,
    onDismiss: () -> Unit,
    onPreviewVibration: (Int) -> Unit,
    onSave: (
        existingId: Int,
        hour: Int,
        minute: Int,
        label: String,
        repeatDaysMask: Int,
        vibrateOnly: Boolean,
        vibrateStrengthOverride: Int?,
        challengeType: WakeChallengeType,
        worldTheme: WorldTheme
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var hour by remember { mutableIntStateOf(existingAlarm?.hour ?: 7) }
    var minute by remember { mutableIntStateOf(existingAlarm?.minute ?: 0) }
    var label by remember { mutableStateOf(existingAlarm?.label ?: "") }
    var repeatMask by remember { mutableIntStateOf(existingAlarm?.repeatDaysMask ?: 0b0011111) }
    var vibrateOnly by remember {
        mutableStateOf(existingAlarm?.vibrateOnly ?: defaultVibrateOnly)
    }
    var useCustomStrength by remember {
        mutableStateOf(existingAlarm?.vibrateStrengthOverride != null)
    }
    var customStrength by remember {
        mutableIntStateOf(existingAlarm?.vibrateStrengthOverride ?: globalStrength)
    }
    var challengeType by remember {
        mutableStateOf(existingAlarm?.challenge ?: WakeChallengeType.RHYTHM_BEAT)
    }
    var selectedWorld by remember {
        mutableStateOf(existingAlarm?.worldTheme ?: defaultWorld)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = if (existingAlarm == null) "New Anime Alarm" else "Edit Alarm",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Tabular Time Stepper Card
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        TimeUnitStepper(
                            value = hour,
                            label = "HOUR",
                            onDecrement = { hour = (hour + 23) % 24 },
                            onIncrement = { hour = (hour + 1) % 24 },
                            tagPrefix = "editor_hour"
                        )
                        Text(
                            text = ":",
                            style = MaterialTheme.typography.displayMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        TimeUnitStepper(
                            value = minute,
                            label = "MIN",
                            onDecrement = { minute = (minute + 59) % 60 },
                            onIncrement = { minute = (minute + 1) % 60 },
                            tagPrefix = "editor_minute"
                        )
                    }

                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            "05:30" to (5 to 30),
                            "06:00" to (6 to 0),
                            "06:30" to (6 to 30),
                            "07:00" to (7 to 0),
                            "08:00" to (8 to 0)
                        ).forEach { (text, hm) ->
                            FilterChip(
                                selected = hour == hm.first && minute == hm.second,
                                onClick = {
                                    hour = hm.first
                                    minute = hm.second
                                },
                                label = { Text(text) }
                            )
                        }
                    }
                }
            }

            // Label & quick presets
            OutlinedTextField(
                value = label,
                onValueChange = { label = it },
                label = { Text("Alarm Title") },
                placeholder = { Text("e.g., Morning Rehearsal / Turf Run") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("editor_label_input"),
                shape = RoundedCornerShape(16.dp)
            )

            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "Morning Rehearsal",
                    "Turf Training",
                    "Schale Briefing",
                    "Daily Commissions",
                    "Power Nap"
                ).forEach { preset ->
                    FilterChip(
                        selected = label == preset,
                        onClick = { label = preset },
                        label = { Text(preset) }
                    )
                }
            }

            // Repeat days
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Repeat Days", style = MaterialTheme.typography.labelLarge)
                val dayLabels = listOf("M", "T", "W", "T", "F", "S", "S")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    dayLabels.forEachIndexed { idx, d ->
                        val active = (repeatMask and (1 shl idx)) != 0
                        Surface(
                            shape = CircleShape,
                            color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .size(44.dp)
                                .clickable {
                                    repeatMask = repeatMask xor (1 shl idx)
                                }
                                .testTag("editor_day_$idx")
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = d,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            // Vibrate-Only (Silent Mode) Card
            Surface(
                color = if (vibrateOnly) {
                    MaterialTheme.colorScheme.primaryContainer
                } else {
                    MaterialTheme.colorScheme.surfaceVariant
                },
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(
                    1.dp,
                    if (vibrateOnly) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = if (vibrateOnly) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                            contentDescription = null,
                            tint = if (vibrateOnly) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                        )
                        Column {
                            Text(
                                text = "Vibrate Only (No Sound)",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = if (vibrateOnly) {
                                    "Silent mode active — zero chime or voice"
                                } else {
                                    "Plays anime chime + companion greeting"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = vibrateOnly,
                        onCheckedChange = { vibrateOnly = it },
                        modifier = Modifier.testTag("editor_vibrate_only_switch")
                    )
                }
            }

            // Vibration Strength Override
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Rounded.Vibration, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                            Column {
                                Text("Custom Vibration Strength", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = if (useCustomStrength) "$customStrength% custom" else "Following global ($globalStrength%)",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = useCustomStrength,
                            onCheckedChange = { useCustomStrength = it },
                            modifier = Modifier.testTag("editor_custom_strength_switch")
                        )
                    }
                    if (useCustomStrength) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Slider(
                                value = customStrength.toFloat(),
                                onValueChange = { customStrength = it.roundToInt() },
                                onValueChangeFinished = { onPreviewVibration(customStrength) },
                                valueRange = 10f..100f,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("editor_strength_slider")
                            )
                            OutlinedButton(
                                onClick = { onPreviewVibration(customStrength) },
                                modifier = Modifier.testTag("editor_test_strength_button")
                            ) {
                                Text("Test")
                            }
                        }
                    }
                }
            }

            // Wake-Up Challenge Picker
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Wake-Up Challenge", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    WakeChallengeType.entries.forEach { challenge ->
                        FilterChip(
                            selected = challengeType == challenge,
                            onClick = { challengeType = challenge },
                            label = { Text(challenge.displayName) },
                            modifier = Modifier.testTag("editor_challenge_${challenge.id}")
                        )
                    }
                }
                Text(
                    text = challengeType.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Companion Theme Picker
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Companion Persona", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    WorldTheme.entries.forEach { world ->
                        FilterChip(
                            selected = selectedWorld == world,
                            onClick = { selectedWorld = world },
                            label = { Text("${world.companionName} (${world.title})") },
                            modifier = Modifier.testTag("editor_world_${world.id}")
                        )
                    }
                }
            }

            Spacer(Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Cancel")
                }
                Button(
                    onClick = {
                        onSave(
                            existingAlarm?.id ?: 0,
                            hour,
                            minute,
                            label,
                            repeatMask,
                            vibrateOnly,
                            if (useCustomStrength) customStrength else null,
                            challengeType,
                            selectedWorld
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("editor_save_button"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Save Alarm", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun TimeUnitStepper(
    value: Int,
    label: String,
    onDecrement: () -> Unit,
    onIncrement: () -> Unit,
    tagPrefix: String
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
            onClick = onIncrement,
            modifier = Modifier
                .size(48.dp)
                .testTag("${tagPrefix}_up")
        ) {
            Icon(Icons.Rounded.Add, contentDescription = "Increase $label")
        }
        Text(
            text = String.format("%02d", value),
            style = MaterialTheme.typography.displayMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        IconButton(
            onClick = onDecrement,
            modifier = Modifier
                .size(48.dp)
                .testTag("${tagPrefix}_down")
        ) {
            Icon(Icons.Rounded.Remove, contentDescription = "Decrease $label")
        }
    }
}
