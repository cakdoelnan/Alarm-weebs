package com.example.data

import com.example.model.WorldTheme
import kotlinx.coroutines.flow.Flow

class AlarmRepository(
    private val alarmDao: AlarmDao,
    private val prefs: PreferencesManager
) {
    val alarmsFlow: Flow<List<AlarmEntity>> = alarmDao.observeAllAlarms()
    val wakeLogsFlow: Flow<List<WakeLogEntity>> = alarmDao.observeRecentWakeLogs()
    val activeWorldFlow = prefs.activeWorldFlow
    val hapticSettingsFlow = prefs.hapticSettingsFlow
    val companionStatsFlow = prefs.companionStatsFlow

    suspend fun getEnabledAlarms(): List<AlarmEntity> = alarmDao.getEnabledAlarms()
    suspend fun getAlarmById(id: Int): AlarmEntity? = alarmDao.getAlarmById(id)

    suspend fun saveAlarm(alarm: AlarmEntity): AlarmEntity {
        val insertedId = alarmDao.insertAlarm(alarm).toInt()
        return if (alarm.id == 0) alarm.copy(id = insertedId) else alarm
    }

    suspend fun toggleAlarm(id: Int, enabled: Boolean) {
        alarmDao.setAlarmEnabled(id, enabled)
    }

    suspend fun updateVibrateOnly(alarm: AlarmEntity, vibrateOnly: Boolean): AlarmEntity {
        val updated = alarm.copy(vibrateOnly = vibrateOnly)
        alarmDao.updateAlarm(updated)
        return updated
    }

    suspend fun deleteAlarm(id: Int) {
        alarmDao.deleteAlarmById(id)
    }

    suspend fun recordWakeSuccess(
        alarmLabel: String,
        world: WorldTheme,
        challengeId: String,
        vibrateOnly: Boolean,
        starsEarned: Int
    ) {
        alarmDao.insertWakeLog(
            WakeLogEntity(
                alarmLabel = alarmLabel,
                worldThemeId = world.id,
                challengeType = challengeId,
                vibrateOnly = vibrateOnly,
                starsEarned = starsEarned
            )
        )
        prefs.recordWakeClear(world, starsEarned, bondXpEarned = 20)
    }

    suspend fun setActiveWorld(world: WorldTheme) = prefs.setActiveWorld(world)
    suspend fun setVibrationStrength(strength: Int) = prefs.setVibrationStrength(strength)
    suspend fun setGlobalVibrateOnlyDefault(enabled: Boolean) = prefs.setGlobalVibrateOnlyDefault(enabled)
    suspend fun setJihoEnabled(enabled: Boolean) = prefs.setJihoEnabled(enabled)
    suspend fun setJihoHours(startHour: Int, endHour: Int) = prefs.setJihoHours(startHour, endHour)
    suspend fun setJihoPattern(pattern: com.example.model.JihoPattern) = prefs.setJihoPattern(pattern)
    suspend fun setJihoSilentVibrateOnly(silent: Boolean) = prefs.setJihoSilentVibrateOnly(silent)
    suspend fun setVoiceGreetingEnabled(enabled: Boolean) = prefs.setVoiceGreetingEnabled(enabled)
    suspend fun getHapticSettingsSnapshot() = prefs.getHapticSettingsSnapshot()
    suspend fun getActiveWorldSnapshot() = prefs.getActiveWorldSnapshot()
}
