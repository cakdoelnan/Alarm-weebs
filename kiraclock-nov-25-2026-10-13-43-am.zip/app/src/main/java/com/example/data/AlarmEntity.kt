package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.WakeChallengeType
import com.example.model.WorldTheme
import java.util.Calendar

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val hour: Int,
    val minute: Int,
    val label: String,
    val enabled: Boolean = true,
    val repeatDaysMask: Int = 0, // Bit 0 = Mon .. Bit 6 = Sun
    val vibrateOnly: Boolean = false,
    val vibrateStrengthOverride: Int? = null, // null = follow global slider
    val challengeType: String = WakeChallengeType.NORMAL.id,
    val worldThemeId: String = WorldTheme.STARLIGHT_BEAT.id,
    val createdAt: Long = System.currentTimeMillis()
) {
    val challenge: WakeChallengeType
        get() = WakeChallengeType.fromId(challengeType)

    val worldTheme: WorldTheme
        get() = WorldTheme.fromId(worldThemeId)

    fun formattedTime(): String = String.format("%02d:%02d", hour, minute)

    fun isDaySelected(dayIndexMonZero: Int): Boolean =
        (repeatDaysMask and (1 shl dayIndexMonZero)) != 0

    fun repeatSummary(): String {
        if (repeatDaysMask == 0) return "Once"
        if (repeatDaysMask == 0b1111111) return "Every day"
        if (repeatDaysMask == 0b0011111) return "Weekdays"
        if (repeatDaysMask == 0b1100000) return "Weekends"
        val names = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        return names.filterIndexed { index, _ -> isDaySelected(index) }.joinToString(" · ")
    }

    fun computeNextTriggerMillis(nowMillis: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = nowMillis
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
        }

        if (repeatDaysMask == 0) {
            if (cal.timeInMillis <= nowMillis) {
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }
            return cal.timeInMillis
        }

        for (offset in 0..7) {
            val candidate = (cal.clone() as Calendar).apply {
                add(Calendar.DAY_OF_YEAR, offset)
            }
            val monZeroIndex = calendarDayToMonZero(candidate.get(Calendar.DAY_OF_WEEK))
            if (isDaySelected(monZeroIndex) && candidate.timeInMillis > nowMillis) {
                return candidate.timeInMillis
            }
        }
        cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    companion object {
        fun calendarDayToMonZero(calendarDayOfWeek: Int): Int = when (calendarDayOfWeek) {
            Calendar.MONDAY -> 0
            Calendar.TUESDAY -> 1
            Calendar.WEDNESDAY -> 2
            Calendar.THURSDAY -> 3
            Calendar.FRIDAY -> 4
            Calendar.SATURDAY -> 5
            Calendar.SUNDAY -> 6
            else -> 0
        }
    }
}

@Entity(tableName = "wake_logs")
data class WakeLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val alarmLabel: String,
    val worldThemeId: String,
    val challengeType: String,
    val vibrateOnly: Boolean,
    val starsEarned: Int,
    val timestamp: Long = System.currentTimeMillis()
)
