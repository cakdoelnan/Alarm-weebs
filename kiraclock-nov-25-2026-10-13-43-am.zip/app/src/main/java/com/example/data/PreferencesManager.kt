package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.CompanionStats
import com.example.model.HapticSettings
import com.example.model.JihoPattern
import com.example.model.WorldTheme
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "kiraclock_prefs")

class PreferencesManager(private val context: Context) {

    private object Keys {
        val ACTIVE_WORLD = stringPreferencesKey("active_world")
        val VIBRATION_STRENGTH = intPreferencesKey("vibration_strength")
        val GLOBAL_VIBRATE_ONLY_DEFAULT = booleanPreferencesKey("global_vibrate_only_default")
        val JIHO_ENABLED = booleanPreferencesKey("jiho_enabled")
        val JIHO_START_HOUR = intPreferencesKey("jiho_start_hour")
        val JIHO_END_HOUR = intPreferencesKey("jiho_end_hour")
        val JIHO_PATTERN = stringPreferencesKey("jiho_pattern")
        val JIHO_SILENT_VIBRATE_ONLY = booleanPreferencesKey("jiho_silent_vibrate_only")
        val VOICE_GREETING_ENABLED = booleanPreferencesKey("voice_greeting_enabled")

        val MORNING_STARS = intPreferencesKey("morning_stars")
        val WAKE_STREAK = intPreferencesKey("wake_streak")
        val LAST_WAKE_DATE = stringPreferencesKey("last_wake_date")
        val BOND_HIBIKI = intPreferencesKey("bond_hibiki")
        val BOND_SUZUKA = intPreferencesKey("bond_suzuka")
        val BOND_SHIROHA = intPreferencesKey("bond_shiroha")
        val BOND_ASTERA = intPreferencesKey("bond_astera")
    }

    val activeWorldFlow: Flow<WorldTheme> = context.dataStore.data.map { prefs ->
        WorldTheme.fromId(prefs[Keys.ACTIVE_WORLD])
    }

    val hapticSettingsFlow: Flow<HapticSettings> = context.dataStore.data.map { prefs ->
        HapticSettings(
            vibrationStrength = (prefs[Keys.VIBRATION_STRENGTH] ?: 75).coerceIn(10, 100),
            globalVibrateOnlyDefault = prefs[Keys.GLOBAL_VIBRATE_ONLY_DEFAULT] ?: false,
            jihoEnabled = prefs[Keys.JIHO_ENABLED] ?: false,
            jihoStartHour = (prefs[Keys.JIHO_START_HOUR] ?: 7).coerceIn(0, 23),
            jihoEndHour = (prefs[Keys.JIHO_END_HOUR] ?: 22).coerceIn(0, 23),
            jihoPattern = JihoPattern.fromId(prefs[Keys.JIHO_PATTERN]),
            jihoSilentVibrateOnly = prefs[Keys.JIHO_SILENT_VIBRATE_ONLY] ?: true,
            voiceGreetingEnabled = prefs[Keys.VOICE_GREETING_ENABLED] ?: true
        )
    }

    val companionStatsFlow: Flow<CompanionStats> = context.dataStore.data.map { prefs ->
        CompanionStats(
            morningStars = prefs[Keys.MORNING_STARS] ?: 0,
            wakeStreak = prefs[Keys.WAKE_STREAK] ?: 0,
            lastWakeDate = prefs[Keys.LAST_WAKE_DATE] ?: "",
            bondXpByWorld = mapOf(
                WorldTheme.STARLIGHT_BEAT to (prefs[Keys.BOND_HIBIKI] ?: 0),
                WorldTheme.TRACEN_TURF to (prefs[Keys.BOND_SUZUKA] ?: 0),
                WorldTheme.SCHALE_HALO to (prefs[Keys.BOND_SHIROHA] ?: 0),
                WorldTheme.ASTRAL_WISH to (prefs[Keys.BOND_ASTERA] ?: 0)
            )
        )
    }

    suspend fun getHapticSettingsSnapshot(): HapticSettings = hapticSettingsFlow.first()
    suspend fun getActiveWorldSnapshot(): WorldTheme = activeWorldFlow.first()

    suspend fun setActiveWorld(world: WorldTheme) {
        context.dataStore.edit { it[Keys.ACTIVE_WORLD] = world.id }
    }

    suspend fun setVibrationStrength(strength: Int) {
        context.dataStore.edit { it[Keys.VIBRATION_STRENGTH] = strength.coerceIn(10, 100) }
    }

    suspend fun setGlobalVibrateOnlyDefault(enabled: Boolean) {
        context.dataStore.edit { it[Keys.GLOBAL_VIBRATE_ONLY_DEFAULT] = enabled }
    }

    suspend fun setJihoEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.JIHO_ENABLED] = enabled }
    }

    suspend fun setJihoHours(startHour: Int, endHour: Int) {
        context.dataStore.edit {
            it[Keys.JIHO_START_HOUR] = startHour.coerceIn(0, 23)
            it[Keys.JIHO_END_HOUR] = endHour.coerceIn(0, 23)
        }
    }

    suspend fun setJihoPattern(pattern: JihoPattern) {
        context.dataStore.edit { it[Keys.JIHO_PATTERN] = pattern.id }
    }

    suspend fun setJihoSilentVibrateOnly(silent: Boolean) {
        context.dataStore.edit { it[Keys.JIHO_SILENT_VIBRATE_ONLY] = silent }
    }

    suspend fun setVoiceGreetingEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.VOICE_GREETING_ENABLED] = enabled }
    }

    suspend fun recordWakeClear(world: WorldTheme, starsEarned: Int, bondXpEarned: Int) {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        context.dataStore.edit { prefs ->
            prefs[Keys.MORNING_STARS] = (prefs[Keys.MORNING_STARS] ?: 0) + starsEarned
            val lastDate = prefs[Keys.LAST_WAKE_DATE] ?: ""
            val currentStreak = prefs[Keys.WAKE_STREAK] ?: 0
            if (lastDate != today) {
                prefs[Keys.WAKE_STREAK] = currentStreak + 1
                prefs[Keys.LAST_WAKE_DATE] = today
            }
            val bondKey = when (world) {
                WorldTheme.STARLIGHT_BEAT -> Keys.BOND_HIBIKI
                WorldTheme.TRACEN_TURF -> Keys.BOND_SUZUKA
                WorldTheme.SCHALE_HALO -> Keys.BOND_SHIROHA
                WorldTheme.ASTRAL_WISH -> Keys.BOND_ASTERA
            }
            prefs[bondKey] = (prefs[bondKey] ?: 0) + bondXpEarned
        }
    }
}
