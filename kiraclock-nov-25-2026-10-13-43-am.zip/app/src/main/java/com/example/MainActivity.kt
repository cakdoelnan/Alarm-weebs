package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Alarm
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Vibration
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.AlarmEntity
import com.example.model.WakeChallengeType
import com.example.ui.KiraClockViewModel
import com.example.ui.screens.AlarmEditorSheet
import com.example.ui.screens.AlarmsScreen
import com.example.ui.screens.CompanionsScreen
import com.example.ui.screens.JihoHapticsScreen
import com.example.ui.theme.KiraClockTheme
import kotlinx.coroutines.launch

private enum class KiraDestination(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    ALARMS(
        route = "alarms",
        labelRes = R.string.nav_alarms,
        selectedIcon = Icons.Rounded.Alarm,
        unselectedIcon = Icons.Outlined.Alarm
    ),
    JIHO(
        route = "jiho_haptics",
        labelRes = R.string.nav_jiho,
        selectedIcon = Icons.Rounded.Vibration,
        unselectedIcon = Icons.Outlined.Vibration
    ),
    COMPANIONS(
        route = "companions",
        labelRes = R.string.nav_worlds,
        selectedIcon = Icons.Rounded.AutoAwesome,
        unselectedIcon = Icons.Outlined.AutoAwesome
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KiraClockApp()
        }
    }
}

@Composable
fun KiraClockApp(viewModel: KiraClockViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    var notificationGranted by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        notificationGranted = granted
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshPermissionsState()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notificationGranted = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    var showEditorSheet by remember { mutableStateOf(false) }
    var editingAlarm by remember { mutableStateOf<AlarmEntity?>(null) }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val onAlarmsTab = currentDestination?.route == KiraDestination.ALARMS.route

    KiraClockTheme(worldTheme = uiState.activeWorld) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Row(modifier = Modifier.fillMaxSize()) {
                if (useRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        KiraDestination.entries.forEach { dest ->
                            val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(dest.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes)
                                    )
                                },
                                label = { Text(stringResource(dest.labelRes)) },
                                modifier = Modifier.testTag("nav_rail_${dest.route}")
                            )
                        }
                    }
                }

                Scaffold(
                    modifier = Modifier.weight(1f),
                    contentWindowInsets = WindowInsets.safeDrawing,
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    floatingActionButton = {
                        if (onAlarmsTab) {
                            FloatingActionButton(
                                onClick = {
                                    editingAlarm = null
                                    showEditorSheet = true
                                },
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.testTag("fab_add_alarm")
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = "Add Alarm")
                            }
                        }
                    },
                    bottomBar = {
                        if (!useRail) {
                            NavigationBar(
                                containerColor = MaterialTheme.colorScheme.surface
                            ) {
                                KiraDestination.entries.forEach { dest ->
                                    val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                                    NavigationBarItem(
                                        selected = selected,
                                        onClick = {
                                            navController.navigate(dest.route) {
                                                popUpTo(navController.graph.findStartDestination().id) {
                                                    saveState = true
                                                }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                                contentDescription = stringResource(dest.labelRes)
                                            )
                                        },
                                        label = { Text(stringResource(dest.labelRes)) },
                                        modifier = Modifier.testTag("nav_bar_${dest.route}")
                                    )
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = KiraDestination.ALARMS.route,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        composable(KiraDestination.ALARMS.route) {
                            AlarmsScreen(
                                uiState = uiState,
                                needsNotificationPermission = !notificationGranted &&
                                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU,
                                onRequestNotificationPermission = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                },
                                onAddAlarmClick = {
                                    editingAlarm = null
                                    showEditorSheet = true
                                },
                                onQuickPresetCreate = { hour, minute, label, vibrateOnly, challenge ->
                                    viewModel.saveAlarm(
                                        hour = hour,
                                        minute = minute,
                                        label = label,
                                        repeatDaysMask = 0b0011111,
                                        vibrateOnly = vibrateOnly,
                                        vibrateStrengthOverride = null,
                                        challengeType = challenge,
                                        worldTheme = uiState.activeWorld
                                    )
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar("Armed $label at %02d:%02d".format(hour, minute))
                                    }
                                },
                                onEditAlarm = { alarm ->
                                    editingAlarm = alarm
                                    showEditorSheet = true
                                },
                                onToggleAlarm = { alarm, enabled ->
                                    viewModel.toggleAlarm(alarm, enabled)
                                },
                                onToggleAlarmVibrateOnly = { alarm, vibOnly ->
                                    viewModel.toggleAlarmVibrateOnly(alarm, vibOnly)
                                    coroutineScope.launch {
                                        val msg = if (vibOnly) "Switched to Vibrate Only (Silent)" else "Sound + Vibrate enabled"
                                        snackbarHostState.showSnackbar(msg)
                                    }
                                },
                                onDeleteAlarm = { id ->
                                    viewModel.deleteAlarm(id)
                                },
                                onPreviewAlarm = { alarm ->
                                    viewModel.launchAlarmPreview(
                                        vibrateOnly = alarm.vibrateOnly,
                                        challengeType = alarm.challenge,
                                        worldTheme = alarm.worldTheme,
                                        strengthOverride = alarm.vibrateStrengthOverride
                                    )
                                },
                                onPreviewActiveWorld = { vibOnly ->
                                    val defaultChallenge = when (uiState.activeWorld) {
                                        com.example.model.WorldTheme.STARLIGHT_BEAT -> WakeChallengeType.RHYTHM_BEAT
                                        com.example.model.WorldTheme.TRACEN_TURF -> WakeChallengeType.TURF_SPRINT
                                        com.example.model.WorldTheme.SCHALE_HALO -> WakeChallengeType.HALO_CIPHER
                                        com.example.model.WorldTheme.ASTRAL_WISH -> WakeChallengeType.HALO_CIPHER
                                    }
                                    viewModel.launchAlarmPreview(
                                        vibrateOnly = vibOnly,
                                        challengeType = defaultChallenge,
                                        worldTheme = uiState.activeWorld
                                    )
                                },
                                onOpenJihoTab = {
                                    navController.navigate(KiraDestination.JIHO.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            )
                        }

                        composable(KiraDestination.JIHO.route) {
                            JihoHapticsScreen(
                                uiState = uiState,
                                onVibrationStrengthChange = { strength ->
                                    viewModel.setVibrationStrength(strength)
                                },
                                onPreviewStrength = { strength ->
                                    viewModel.previewVibrationStrength(strength)
                                },
                                onGlobalVibrateOnlyDefaultChange = { enabled ->
                                    viewModel.setGlobalVibrateOnlyDefault(enabled)
                                },
                                onPreviewSilentAlarm = {
                                    viewModel.launchAlarmPreview(
                                        vibrateOnly = true,
                                        challengeType = WakeChallengeType.NORMAL,
                                        worldTheme = uiState.activeWorld
                                    )
                                },
                                onJihoEnabledChange = { enabled ->
                                    viewModel.setJihoEnabled(enabled)
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar(
                                            if (enabled) "Hourly Jihō pulse enabled" else "Hourly Jihō paused"
                                        )
                                    }
                                },
                                onJihoHoursChange = { start, end ->
                                    viewModel.setJihoHours(start, end)
                                },
                                onJihoPatternSelect = { pattern ->
                                    viewModel.setJihoPattern(pattern)
                                    viewModel.previewVibrationStrength(uiState.hapticSettings.vibrationStrength)
                                },
                                onJihoSilentVibrateOnlyChange = { silent ->
                                    viewModel.setJihoSilentVibrateOnly(silent)
                                },
                                onTestJihoNow = {
                                    viewModel.testJihoNow()
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar(
                                            "Sent Jihō pulse (${uiState.hapticSettings.vibrationStrength}%)"
                                        )
                                    }
                                },
                                onRequestExactAlarmPermission = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                        val intent = Intent(
                                            Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                            Uri.parse("package:${context.packageName}")
                                        )
                                        context.startActivity(intent)
                                    }
                                }
                            )
                        }

                        composable(KiraDestination.COMPANIONS.route) {
                            CompanionsScreen(
                                uiState = uiState,
                                onSelectWorld = { world ->
                                    viewModel.selectWorld(world)
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar("Equipped ${world.companionName} (${world.title})")
                                    }
                                },
                                onPreviewWorldChime = { world ->
                                    viewModel.previewChimeSound(world)
                                },
                                onVoiceGreetingToggle = { enabled ->
                                    viewModel.setVoiceGreetingEnabled(enabled)
                                }
                            )
                        }
                    }
                }
            }

            if (showEditorSheet) {
                AlarmEditorSheet(
                    existingAlarm = editingAlarm,
                    defaultWorld = uiState.activeWorld,
                    defaultVibrateOnly = uiState.hapticSettings.globalVibrateOnlyDefault,
                    globalStrength = uiState.hapticSettings.vibrationStrength,
                    onDismiss = { showEditorSheet = false },
                    onPreviewVibration = { strength -> viewModel.previewVibrationStrength(strength) },
                    onSave = { existingId, hour, minute, label, repeatMask, vibrateOnly, strengthOverride, challenge, world ->
                        viewModel.saveAlarm(
                            existingId = existingId,
                            hour = hour,
                            minute = minute,
                            label = label,
                            repeatDaysMask = repeatMask,
                            vibrateOnly = vibrateOnly,
                            vibrateStrengthOverride = strengthOverride,
                            challengeType = challenge,
                            worldTheme = world
                        )
                        showEditorSheet = false
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar(
                                "Saved %02d:%02d • %s".format(
                                    hour,
                                    minute,
                                    if (vibrateOnly) "Vibrate Only" else world.title
                                )
                            )
                        }
                    }
                )
            }
        }
    }
}
