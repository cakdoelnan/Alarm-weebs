package com.example

import com.example.alarm.AlarmScheduler
import com.example.data.AlarmEntity
import com.example.model.HapticSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar
import kotlin.math.roundToInt

class KiraClockLogicTest {

    @Test
    fun oneShotAlarmAdvancesToNextDayIfTimePassed() {
        val now = Calendar.getInstance().apply {
            set(2026, Calendar.MARCH, 10, 8, 30, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val alarm = AlarmEntity(hour = 7, minute = 0, label = "Morning", repeatDaysMask = 0)
        val next = Calendar.getInstance().apply {
            timeInMillis = alarm.computeNextTriggerMillis(now)
        }
        assertEquals(11, next.get(Calendar.DAY_OF_MONTH))
        assertEquals(7, next.get(Calendar.HOUR_OF_DAY))
        assertEquals(0, next.get(Calendar.MINUTE))
    }

    @Test
    fun jihoWindowHandlesStandardOvernightAndAllDay() {
        assertTrue(AlarmScheduler.isHourInWindow(7, 7, 22))
        assertTrue(AlarmScheduler.isHourInWindow(22, 7, 22))
        assertFalse(AlarmScheduler.isHourInWindow(23, 7, 22))
        assertFalse(AlarmScheduler.isHourInWindow(6, 7, 22))

        // Overnight window 22 -> 05
        assertTrue(AlarmScheduler.isHourInWindow(23, 22, 5))
        assertTrue(AlarmScheduler.isHourInWindow(3, 22, 5))
        assertFalse(AlarmScheduler.isHourInWindow(12, 22, 5))

        // 24h mode
        assertTrue(AlarmScheduler.isHourInWindow(4, 0, 0))
    }

    @Test
    fun computeNextJihoSkipsOutsideWindow() {
        val now = Calendar.getInstance().apply {
            set(2026, Calendar.MARCH, 10, 22, 15, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val nextMillis = AlarmScheduler.computeNextJihoMillis(now, startHour = 7, endHour = 22)
        assertNotNull(nextMillis)
        val next = Calendar.getInstance().apply { timeInMillis = nextMillis!! }
        assertEquals(11, next.get(Calendar.DAY_OF_MONTH))
        assertEquals(7, next.get(Calendar.HOUR_OF_DAY))
        assertEquals(0, next.get(Calendar.MINUTE))
    }

    @Test
    fun hapticStrengthTiersAndAmplitudeRangeAreValid() {
        assertEquals("Gentle Whisper", HapticSettings(vibrationStrength = 20).strengthTierLabel)
        assertEquals("Balanced Pulse", HapticSettings(vibrationStrength = 50).strengthTierLabel)
        assertEquals("Idol Stage Beat", HapticSettings(vibrationStrength = 75).strengthTierLabel)
        assertEquals("Max Overdrive", HapticSettings(vibrationStrength = 95).strengthTierLabel)

        val minAmp = ((10 / 100f) * 255f).roundToInt().coerceIn(25, 255)
        val maxAmp = ((100 / 100f) * 255f).roundToInt().coerceIn(25, 255)
        assertEquals(26, minAmp)
        assertEquals(255, maxAmp)
    }
}
