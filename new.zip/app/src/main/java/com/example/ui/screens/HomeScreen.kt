package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.LibraryScanResult
import com.example.model.Album
import com.example.model.Track
import com.example.ui.components.AlbumArtworkImage
import com.example.ui.components.IosGroupedContainer
import com.example.ui.components.IosThinDivider
import com.example.ui.theme.AppleMusicRed
import com.example.ui.theme.IosSecondaryGray
import com.example.ui.theme.PureBlack

@Composable
fun HomeScreen(
    library: LibraryScanResult,
    recentlyPlayed: List<Track>,
    hasAudioPermission: Boolean,
    isScanning: Boolean,
    currentTrackId: Long?,
    topContentPadding: Dp,
    bottomContentPadding: Dp,
    onAlbumClick: (Album) -> Unit,
    onTrackClick: (List<Track>, Int) -> Unit,
    onSeeAllSongs: () -> Unit,
    onSeeAllAlbums: () -> Unit,
    onRequestPermission: () -> Unit,
    onOpenAudioFile: () -> Unit,
    onRescanLibrary: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
    ) {
        if (!hasAudioPermission && library.tracks.isEmpty()) {
            HomeEmptyState(
                title = stringResource(R.string.permission_audio_title),
                body = stringResource(R.string.permission_audio_body),
                primaryLabel = stringResource(R.string.permission_audio_cta),
                secondaryLabel = stringResource(R.string.open_audio_file),
                topPadding = topContentPadding,
                bottomPadding = bottomContentPadding,
                onPrimaryClick = onRequestPermission,
                onSecondaryClick = onOpenAudioFile
            )
            return
        }

        if (isScanning && library.tracks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AppleMusicRed)
            }
            return
        }

        if (library.tracks.isEmpty()) {
            HomeEmptyState(
                title = stringResource(R.string.empty_library_title),
                body = stringResource(R.string.empty_library_body),
                primaryLabel = stringResource(R.string.open_audio_file),
                secondaryLabel = stringResource(R.string.rescan_library),
                topPadding = topContentPadding,
                bottomPadding = bottomContentPadding,
                onPrimaryClick = onOpenAudioFile,
                onSecondaryClick = onRescanLibrary
            )
            return
        }

        val recentCarouselTracks = if (recentlyPlayed.isNotEmpty()) {
            recentlyPlayed
        } else {
            library.tracks.take(12)
        }
        val hiResTracks = library.tracks.filter { it.bitDepth >= 24 || it.sampleRateHz > 48000 }
            .ifEmpty { library.tracks }
            .take(8)

        LazyColumn(
            contentPadding = PaddingValues(
                top = topContentPadding,
                bottom = bottomContentPadding
            ),
            modifier = Modifier
                .fillMaxSize()
                .testTag("home_feed_list")
        ) {
            // 1. Recently Played > Horizontal Carousel
            item {
                AppleSectionHeader(
                    title = "Recently Played",
                    onClick = onSeeAllSongs
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.testTag("home_recently_played_carousel")
                ) {
                    itemsIndexed(recentCarouselTracks, key = { idx, t -> "recent_${t.id}_$idx" }) { index, track ->
                        SquareCarouselCard(
                            artworkUri = track.albumArtUri,
                            title = track.title,
                            subtitle = track.artist,
                            cardWidth = 148.dp,
                            isActive = track.id == currentTrackId,
                            onClick = { onTrackClick(recentCarouselTracks, index) }
                        )
                    }
                }
                Spacer(Modifier.height(28.dp))
            }

            // 2. Albums > Horizontal Carousel
            if (library.albums.isNotEmpty()) {
                item {
                    AppleSectionHeader(
                        title = "Albums",
                        onClick = onSeeAllAlbums
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.testTag("home_albums_carousel")
                    ) {
                        items(library.albums.take(15), key = { "home_alb_${it.id}_${it.title}" }) { album ->
                            SquareCarouselCard(
                                artworkUri = album.artworkUri,
                                title = album.title,
                                subtitle = album.artist,
                                cardWidth = 158.dp,
                                isActive = false,
                                onClick = { onAlbumClick(album) }
                            )
                        }
                    }
                    Spacer(Modifier.height(28.dp))
                }
            }

            // 3. Lossless Picks > Clean Borderless Rows with 0.5dp Hairlines
            item {
                AppleSectionHeader(
                    title = "Lossless Picks",
                    onClick = onSeeAllSongs
                )
            }

            itemsIndexed(hiResTracks, key = { idx, t -> "hires_${t.id}_$idx" }) { index, track ->
                Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                    CleanAppleTrackRow(
                        track = track,
                        isPlayingCurrent = track.id == currentTrackId,
                        onClick = { onTrackClick(hiResTracks, index) }
                    )
                    if (index < hiResTracks.lastIndex) {
                        IosThinDivider(modifier = Modifier.padding(start = 64.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun AppleSectionHeader(
    title: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge.copy(
                fontSize = 21.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.3).sp
            ),
            color = Color.White
        )
        Spacer(Modifier.width(2.dp))
        Icon(
            imageVector = Icons.Rounded.ChevronRight,
            contentDescription = title,
            tint = IosSecondaryGray,
            modifier = Modifier.size(22.dp)
        )
    }
}

@Composable
fun SquareCarouselCard(
    artworkUri: Any?,
    title: String,
    subtitle: String,
    cardWidth: Dp,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .width(cardWidth)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        AlbumArtworkImage(
            artworkUri = artworkUri,
            contentDescription = title,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(12.dp))
        )
        Spacer(Modifier.height(7.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge.copy(
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            ),
            color = if (isActive) AppleMusicRed else Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
            color = IosSecondaryGray,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun HomeEmptyState(
    title: String,
    body: String,
    primaryLabel: String,
    secondaryLabel: String,
    topPadding: Dp,
    bottomPadding: Dp,
    onPrimaryClick: () -> Unit,
    onSecondaryClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = topPadding, bottom = bottomPadding, start = 24.dp, end = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        IosGroupedContainer(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(AppleMusicRed.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LibraryMusic,
                        contentDescription = null,
                        tint = AppleMusicRed,
                        modifier = Modifier.size(30.dp)
                    )
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = body,
                    style = MaterialTheme.typography.bodyMedium,
                    color = IosSecondaryGray
                )
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = onPrimaryClick,
                    colors = ButtonDefaults.buttonColors(containerColor = AppleMusicRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("empty_primary_btn")
                ) {
                    Text(primaryLabel, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(6.dp))
                TextButton(
                    onClick = onSecondaryClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .testTag("empty_secondary_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AudioFile,
                        contentDescription = null,
                        tint = AppleMusicRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(secondaryLabel, color = AppleMusicRed)
                }
            }
        }
    }
}
