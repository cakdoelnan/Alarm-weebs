package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Usb
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.UserSettings
import com.example.model.AudioOutputState
import com.example.model.PlaybackMode
import com.example.model.SleepTimerOption
import com.example.model.SleepTimerState
import com.example.player.PlayerSnapshot
import com.example.ui.components.AlbumArtworkImage
import com.example.ui.components.AnimatedMeshGradientBackground
import com.example.ui.components.AppleMusicLyricsView
import com.example.ui.components.IosThinDivider
import com.example.ui.theme.AppleMusicRed
import com.example.ui.theme.BitPerfectEmerald
import com.example.ui.theme.BitPerfectGold
import com.example.ui.theme.IosGroupedBg
import com.example.ui.theme.IosSecondaryGray
import com.example.ui.theme.IosTertiaryGray

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(
    snapshot: PlayerSnapshot,
    settings: UserSettings,
    audioOutputState: AudioOutputState,
    sleepTimerState: SleepTimerState,
    onCollapse: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onCyclePlaybackMode: () -> Unit,
    onSelectPlaybackMode: (PlaybackMode) -> Unit,
    onSelectSleepTimer: (SleepTimerOption) -> Unit,
    onToggleLyricsAutoScroll: (Boolean) -> Unit,
    onToggleLyricsBlur: (Boolean) -> Unit,
    onJumpToQueueIndex: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val track = snapshot.currentTrack ?: return
    var showLyrics by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }
    var showSleepSheet by remember { mutableStateOf(false) }
    var showDacSheet by remember { mutableStateOf(false) }
    var showModeSheet by remember { mutableStateOf(false) }

    var isScrubbing by remember { mutableStateOf(false) }
    var scrubPositionMs by remember { mutableFloatStateOf(0f) }

    val displayedPositionMs = if (isScrubbing) scrubPositionMs.toLong() else snapshot.positionMs
    val totalMs = snapshot.durationMs.coerceAtLeast(1L)

    Box(modifier = modifier.fillMaxSize()) {
        // Deep, refined Apple Music iOS Live Gaussian Blur Mesh
        AnimatedMeshGradientBackground(
            paletteColors = snapshot.paletteColors,
            blurMode = settings.blurMode
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Subtle iOS grabber bar
            Box(
                modifier = Modifier
                    .padding(top = 8.dp, bottom = 10.dp)
                    .width(38.dp)
                    .height(4.5.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = 0.30f))
                    .clickable(onClick = onCollapse)
            )

            // Minimalist top bar: Collapse + Bit-Perfect DAC Pill + Sleep Timer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onCollapse,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("now_playing_collapse_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowDown,
                        contentDescription = "Collapse Now Playing",
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(28.dp)
                    )
                }

                AudioSignalBadge(
                    audioOutputState = audioOutputState,
                    onClick = { showDacSheet = true },
                    modifier = Modifier.weight(1f, fill = false)
                )

                IconButton(
                    onClick = { showSleepSheet = true },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("sleep_timer_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Bedtime,
                        contentDescription = "Sleep Timer",
                        tint = if (sleepTimerState.activeOption != SleepTimerOption.OFF) {
                            BitPerfectGold
                        } else Color.White.copy(alpha = 0.72f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            if (sleepTimerState.activeOption != SleepTimerOption.OFF) {
                val label = if (sleepTimerState.isFadingOut) {
                    "Fading out • ${formatDuration(sleepTimerState.remainingMs)}"
                } else if (sleepTimerState.activeOption == SleepTimerOption.END_OF_SONG) {
                    "Sleep at End of Song • ${formatDuration(sleepTimerState.remainingMs)}"
                } else {
                    "Sleep in ${formatDuration(sleepTimerState.remainingMs)}"
                }
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = BitPerfectGold,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            Spacer(Modifier.height(10.dp))

            // Centered Large Album Art (16.dp corners + soft ambient shadow) OR Synced Lyrics
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .widthIn(max = 500.dp),
                contentAlignment = Alignment.Center
            ) {
                AnimatedContent(
                    targetState = showLyrics,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "artwork_or_lyrics"
                ) { lyricsMode ->
                    if (lyricsMode) {
                        AppleMusicLyricsView(
                            lyricsData = snapshot.lyricsData,
                            positionMs = snapshot.positionMs,
                            autoScrollEnabled = settings.lyricsAutoScroll,
                            lyricBlurEnabled = settings.lyricsBlurEnabled,
                            blurMode = settings.blurMode,
                            onToggleAutoScroll = onToggleLyricsAutoScroll,
                            onToggleLyricBlur = onToggleLyricsBlur,
                            onSeekToLine = onSeekTo
                        )
                    } else {
                        val artScale by animateFloatAsState(
                            targetValue = if (snapshot.isPlaying) 1.0f else 0.90f,
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                stiffness = Spring.StiffnessLow
                            ),
                            label = "artwork_scale"
                        )
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            AlbumArtworkImage(
                                artworkUri = track.albumArtUri,
                                contentDescription = track.album,
                                modifier = Modifier
                                    .fillMaxWidth(0.90f)
                                    .aspectRatio(1f)
                                    .graphicsLayer {
                                        scaleX = artScale
                                        scaleY = artScale
                                    }
                                    .shadow(
                                        elevation = if (snapshot.isPlaying) 28.dp else 10.dp,
                                        shape = RoundedCornerShape(16.dp),
                                        ambientColor = Color.Black,
                                        spotColor = Color.Black
                                    )
                                    .clip(RoundedCornerShape(16.dp))
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))

            // Track Title, Artist & Lossless Format Indicator
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 500.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = track.title,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            ),
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "${track.artist} — ${track.album}",
                            style = MaterialTheme.typography.bodyLarge.copy(fontSize = 16.sp),
                            color = Color.White.copy(alpha = 0.68f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(Modifier.width(10.dp))

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.White.copy(alpha = 0.12f))
                            .padding(horizontal = 7.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${track.codecLabel} ${track.bitDepth}b",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Minimalist iOS Scrubber
                Slider(
                    value = displayedPositionMs.toFloat().coerceIn(0f, totalMs.toFloat()),
                    onValueChange = {
                        isScrubbing = true
                        scrubPositionMs = it
                    },
                    onValueChangeFinished = {
                        onSeekTo(scrubPositionMs.toLong())
                        isScrubbing = false
                    },
                    valueRange = 0f..totalMs.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color.White.copy(alpha = 0.92f),
                        inactiveTrackColor = Color.White.copy(alpha = 0.22f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("now_playing_slider")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = formatDuration(displayedPositionMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.55f)
                    )
                    val remaining = (totalMs - displayedPositionMs).coerceAtLeast(0L)
                    Text(
                        text = "-${formatDuration(remaining)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.55f)
                    )
                }

                Spacer(Modifier.height(16.dp))

                // Clean Minimalist iOS Transport Controls (no bulky frame boxes)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onSkipPrevious,
                        modifier = Modifier
                            .size(58.dp)
                            .testTag("now_playing_prev")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SkipPrevious,
                            contentDescription = "Previous",
                            tint = Color.White,
                            modifier = Modifier.size(42.dp)
                        )
                    }

                    IconButton(
                        onClick = onTogglePlayPause,
                        modifier = Modifier
                            .size(72.dp)
                            .testTag("now_playing_play_pause")
                    ) {
                        Icon(
                            imageVector = if (snapshot.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (snapshot.isPlaying) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(54.dp)
                        )
                    }

                    IconButton(
                        onClick = onSkipNext,
                        modifier = Modifier
                            .size(58.dp)
                            .testTag("now_playing_next")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SkipNext,
                            contentDescription = "Next",
                            tint = Color.White,
                            modifier = Modifier.size(42.dp)
                        )
                    }
                }

                Spacer(Modifier.height(18.dp))

                // Clean Bottom Utility Icons (Lyrics, Playback Mode, Queue)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 14.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NowPlayingIconTrigger(
                        icon = Icons.Rounded.Lyrics,
                        label = "Lyrics",
                        active = showLyrics,
                        testTag = "toggle_lyrics_btn",
                        onClick = { showLyrics = !showLyrics }
                    )

                    NowPlayingIconTrigger(
                        icon = when (snapshot.playbackMode) {
                            PlaybackMode.NORMAL -> Icons.Rounded.Repeat
                            PlaybackMode.SMART_CROSS_ALBUM_SHUFFLE -> Icons.Rounded.Shuffle
                            PlaybackMode.ALBUM_SHUFFLE -> Icons.Rounded.Album
                        },
                        label = snapshot.playbackMode.title,
                        active = snapshot.playbackMode != PlaybackMode.NORMAL,
                        testTag = "playback_mode_btn",
                        onClick = { showModeSheet = true }
                    )

                    NowPlayingIconTrigger(
                        icon = Icons.AutoMirrored.Rounded.QueueMusic,
                        label = "Queue",
                        active = false,
                        testTag = "open_queue_btn",
                        onClick = { showQueueSheet = true }
                    )
                }
            }
        }
    }

    if (showDacSheet) {
        ModalBottomSheet(
            onDismissRequest = { showDacSheet = false },
            containerColor = IosGroupedBg
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Audio Signal Path",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = audioOutputState.modeLabel,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else BitPerfectGold
                )
                Text(
                    text = "Output: ${audioOutputState.deviceName} • ${audioOutputState.formattedSampleRate} / ${audioOutputState.bitDepth}-bit",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = audioOutputState.statusDetail,
                    style = MaterialTheme.typography.bodyMedium,
                    color = IosSecondaryGray
                )
                if (audioOutputState.supportedProfiles.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = "Hardware DAC Mixer Profiles",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                    Spacer(Modifier.height(6.dp))
                    audioOutputState.supportedProfiles.take(12).forEach { profile ->
                        Text(
                            text = "• $profile",
                            style = MaterialTheme.typography.labelMedium,
                            color = IosSecondaryGray,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    if (showModeSheet) {
        ModalBottomSheet(
            onDismissRequest = { showModeSheet = false },
            containerColor = IosGroupedBg
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Queue Playback Mode",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
                Spacer(Modifier.height(12.dp))
                PlaybackMode.entries.forEachIndexed { idx, mode ->
                    val selected = snapshot.playbackMode == mode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectPlaybackMode(mode)
                                showModeSheet = false
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = mode.title,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                                color = if (selected) AppleMusicRed else Color.White
                            )
                            Text(
                                text = mode.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = IosSecondaryGray
                            )
                        }
                        if (selected) {
                            Icon(
                                imageVector = Icons.Rounded.Check,
                                contentDescription = "Selected",
                                tint = AppleMusicRed
                            )
                        }
                    }
                    if (idx < PlaybackMode.entries.lastIndex) {
                        IosThinDivider()
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showSleepSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSleepSheet = false },
            containerColor = IosGroupedBg
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = stringResource(R.string.sleep_timer_title),
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
                Text(
                    text = "Smooth 10-second fade-out before pausing",
                    style = MaterialTheme.typography.bodyMedium,
                    color = IosSecondaryGray
                )
                Spacer(Modifier.height(12.dp))
                SleepTimerOption.entries.forEachIndexed { idx, opt ->
                    val selected = sleepTimerState.activeOption == opt
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectSleepTimer(opt)
                                showSleepSheet = false
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = opt.label,
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (selected) AppleMusicRed else Color.White,
                            modifier = Modifier.weight(1f)
                        )
                        if (selected) {
                            Icon(
                                imageVector = Icons.Rounded.Check,
                                contentDescription = "Selected",
                                tint = AppleMusicRed
                            )
                        }
                    }
                    if (idx < SleepTimerOption.entries.lastIndex) {
                        IosThinDivider()
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showQueueSheet) {
        ModalBottomSheet(
            onDismissRequest = { showQueueSheet = false },
            containerColor = IosGroupedBg
        ) {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) {
                Text(
                    text = "Playing Next (${snapshot.playbackMode.title})",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
                Spacer(Modifier.height(12.dp))
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp)
                ) {
                    itemsIndexed(snapshot.queue) { index, item ->
                        val isCurrent = index == snapshot.queueIndex
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onJumpToQueueIndex(index)
                                    showQueueSheet = false
                                }
                                .padding(vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AlbumArtworkImage(
                                artworkUri = item.albumArtUri,
                                contentDescription = item.album,
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                                    color = if (isCurrent) AppleMusicRed else Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${item.artist} • ${item.album}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = IosSecondaryGray,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        if (index < snapshot.queue.lastIndex) {
                            IosThinDivider(modifier = Modifier.padding(start = 56.dp))
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun AudioSignalBadge(
    audioOutputState: AudioOutputState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isBitPerfect = audioOutputState.isBitPerfectActive
    val tint = if (isBitPerfect) BitPerfectEmerald else Color.White.copy(alpha = 0.78f)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.10f))
            .clickable(onClick = onClick)
            .testTag("audio_signal_badge")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (audioOutputState.isUsbDacConnected) Icons.Rounded.Usb else Icons.Rounded.GraphicEq,
                contentDescription = audioOutputState.modeLabel,
                tint = tint,
                modifier = Modifier.size(13.dp)
            )
            Spacer(Modifier.width(5.dp))
            val text = if (isBitPerfect) {
                "BIT-PERFECT USB DIRECT • ${audioOutputState.deviceName} • ${audioOutputState.formattedSampleRate}/${audioOutputState.bitDepth}b"
            } else {
                "SYSTEM MIXER • ${audioOutputState.formattedSampleRate}/${audioOutputState.bitDepth}b"
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = if (isBitPerfect) BitPerfectGold else Color.White.copy(alpha = 0.85f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun NowPlayingIconTrigger(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .minimumInteractiveComponentSize()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag(testTag),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(if (active) Color.White.copy(alpha = 0.22f) else Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (active) Color.White else Color.White.copy(alpha = 0.68f),
                modifier = Modifier.size(21.dp)
            )
        }
        Spacer(Modifier.height(2.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = if (active) Color.White else Color.White.copy(alpha = 0.56f),
            maxLines = 1
        )
    }
}

fun formatDuration(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val mins = totalSec / 60L
    val secs = totalSec % 60L
    return String.format(java.util.Locale.US, "%d:%02d", mins, secs)
}
