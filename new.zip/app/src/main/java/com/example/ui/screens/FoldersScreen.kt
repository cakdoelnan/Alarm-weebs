package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.BlurMode
import com.example.model.MusicFolder
import com.example.ui.components.IosGroupedContainer
import com.example.ui.components.IosThinDivider
import com.example.ui.theme.AppleMusicRed
import com.example.ui.theme.IosGroupedBg
import com.example.ui.theme.IosSecondaryGray
import com.example.ui.theme.IosTertiaryGray
import com.example.ui.theme.PureBlack

@Composable
fun FoldersScreen(
    folders: List<MusicFolder>,
    searchQuery: String,
    blurMode: BlurMode,
    topContentPadding: Dp,
    bottomContentPadding: Dp,
    onSearchQueryChange: (String) -> Unit,
    onFolderClick: (MusicFolder) -> Unit,
    onOpenAudioFile: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = topContentPadding,
            bottom = bottomContentPadding
        ),
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
            .testTag("folders_list")
    ) {
        item {
            IosSearchBar(
                query = searchQuery,
                onQueryChange = onSearchQueryChange
            )
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${folders.size} Folders",
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                    color = IosSecondaryGray
                )
                TextButton(
                    onClick = onOpenAudioFile,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("folders_open_file_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AudioFile,
                        contentDescription = null,
                        tint = AppleMusicRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        text = stringResource(R.string.open_audio_file),
                        color = AppleMusicRed,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            Spacer(Modifier.height(2.dp))
        }

        if (folders.isEmpty()) {
            item {
                IosGroupedContainer(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Folder,
                            contentDescription = null,
                            tint = IosTertiaryGray,
                            modifier = Modifier.size(38.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "No audio folders detected yet (ALAC, AAC, HiByMusic, FLAC).",
                            style = MaterialTheme.typography.bodyMedium,
                            color = IosSecondaryGray
                        )
                    }
                }
            }
        } else {
            itemsIndexed(folders, key = { _, f -> f.path }) { index, folder ->
                val codecs = folder.tracks.map { it.codecLabel }.distinct().take(3).joinToString(" • ")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onFolderClick(folder) }
                        .padding(vertical = 12.dp)
                        .testTag("folder_row_${folder.name}"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(IosGroupedBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Folder,
                            contentDescription = folder.name,
                            tint = AppleMusicRed,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = folder.name,
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${folder.tracks.size} tracks • $codecs",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                            color = IosSecondaryGray,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Icon(
                        imageVector = Icons.Rounded.ChevronRight,
                        contentDescription = "Open folder",
                        tint = IosTertiaryGray,
                        modifier = Modifier.size(20.dp)
                    )
                }
                if (index < folders.lastIndex) {
                    IosThinDivider(modifier = Modifier.padding(start = 58.dp))
                }
            }
        }
    }
}
