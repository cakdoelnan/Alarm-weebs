package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AppleMusicRed = Color(0xFFFA2D48)
val AppleMusicRose = AppleMusicRed
val AppleMusicCrimson = Color(0xFFD91E3A)
val BitPerfectGold = Color(0xFFF5C451)
val BitPerfectEmerald = Color(0xFF30D158)

// Apple Music OLED Pure Black Palette
val PureBlack = Color(0xFF000000)
val IosGroupedBg = Color(0xFF1C1C1E)
val IosGroupedElevated = Color(0xFF2C2C2E)
val IosSeparator = Color(0xFF2C2C2E)
val IosSecondaryGray = Color(0xFF8E8E93)
val IosTertiaryGray = Color(0xFF636366)

val ObsidianBg = PureBlack
val ObsidianSurface = IosGroupedBg
val ObsidianSurfaceElevated = IosGroupedElevated
val GlassBorderLight = Color(0x26FFFFFF)
val GlassBorderSubtle = IosSeparator

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = IosSecondaryGray
val TextTertiary = IosTertiaryGray
