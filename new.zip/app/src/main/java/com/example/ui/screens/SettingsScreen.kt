package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Usb
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserSettings
import com.example.model.AudioOutputState
import com.example.model.BlurMode
import com.example.model.PlaybackMode
import com.example.model.SleepTimerOption
import com.example.model.SleepTimerState
import com.example.ui.components.IosGroupedContainer
import com.example.ui.components.IosThinDivider
import com.example.ui.theme.AppleMusicRed
import com.example.ui.theme.BitPerfectEmerald
import com.example.ui.theme.IosSecondaryGray
import com.example.ui.theme.IosTertiaryGray
import com.example.ui.theme.PureBlack

/**
 * Apple Music / iOS Settings screen:
 * - Pure Black #000000 canvas
 * - iOS Grouped Inset Lists (#1C1C1E, 12.dp corner radius)
 * - 0.5.dp #2C2C2E thin dividers
 * - Crisp iOS checkmarks (#FA2D48) & sleek iOS switches (no bulky radio buttons or thick borders)
 */
@Composable
fun SettingsScreen(
    settings: UserSettings,
    audioOutputState: AudioOutputState,
    sleepTimerState: SleepTimerState,
    topContentPadding: Dp,
    bottomContentPadding: Dp,
    onSelectBlurMode: (BlurMode) -> Unit,
    onSelectPlaybackMode: (PlaybackMode) -> Unit,
    onSelectSleepTimer: (SleepTimerOption) -> Unit,
    onToggleLyricsAutoScroll: (Boolean) -> Unit,
    onToggleLyricsBlur: (Boolean) -> Unit,
    onRefreshAudioRouting: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        contentPadding = PaddingValues(
            start = 20.dp,
            end = 20.dp,
            top = topContentPadding,
            bottom = bottomContentPadding
        ),
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
            .testTag("settings_screen")
    ) {
        // 1. USB DAC & Bit-Perfect Audio Output
        item {
            IosSectionLabel("USB DAC & BIT-PERFECT OUTPUT")
            IosGroupedContainer(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onRefreshAudioRouting)
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Usb,
                            contentDescription = null,
                            tint = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else AppleMusicRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = audioOutputState.modeLabel,
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else Color.White
                            )
                            Text(
                                text = "${audioOutputState.deviceName} • ${audioOutputState.formattedSampleRate} / ${audioOutputState.bitDepth}-bit",
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                                color = IosSecondaryGray
                            )
                        }
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = "Refresh USB DAC",
                            tint = AppleMusicRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IosThinDivider(modifier = Modifier.padding(start = 16.dp))
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Text(
                            text = audioOutputState.statusDetail,
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                            color = IosSecondaryGray
                        )
                        if (audioOutputState.supportedProfiles.isNotEmpty()) {
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "HAL Profiles: ${audioOutputState.supportedProfiles.take(6).joinToString(" • ")}",
                                style = MaterialTheme.typography.labelSmall,
                                color = IosTertiaryGray
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }

        // 2. Visual & Blur Engine (3 Modes)
        item {
            IosSectionLabel("VISUAL & BLUR ENGINE")
            IosGroupedContainer(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    BlurMode.entries.forEachIndexed { idx, mode ->
                        val selected = settings.blurMode == mode
                        IosCheckmarkRow(
                            title = mode.title,
                            subtitle = mode.subtitle,
                            selected = selected,
                            testTag = "blur_mode_${mode.name.lowercase()}",
                            onClick = { onSelectBlurMode(mode) }
                        )
                        if (idx < BlurMode.entries.lastIndex) {
                            IosThinDivider(modifier = Modifier.padding(start = 16.dp))
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }

        // 3. Queue & Shuffle Mode
        item {
            IosSectionLabel("QUEUE & SHUFFLE ENGINE")
            IosGroupedContainer(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    PlaybackMode.entries.forEachIndexed { idx, mode ->
                        val selected = settings.playbackMode == mode
                        IosCheckmarkRow(
                            title = mode.title,
                            subtitle = mode.description,
                            selected = selected,
                            testTag = "settings_playback_mode_${mode.name.lowercase()}",
                            onClick = { onSelectPlaybackMode(mode) }
                        )
                        if (idx < PlaybackMode.entries.lastIndex) {
                            IosThinDivider(modifier = Modifier.padding(start = 16.dp))
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }

        // 4. Synced Lyrics Switches
        item {
            IosSectionLabel("SYNCED LYRICS")
            IosGroupedContainer(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    IosSwitchRow(
                        title = "Auto-Scroll Lyrics",
                        subtitle = "Spring-physics scroll tracking active line",
                        checked = settings.lyricsAutoScroll,
                        onCheckedChange = onToggleLyricsAutoScroll
                    )
                    IosThinDivider(modifier = Modifier.padding(start = 16.dp))
                    IosSwitchRow(
                        title = "Inactive Lyric Blur",
                        subtitle = "Soft 2dp blur on surrounding lines",
                        checked = settings.lyricsBlurEnabled,
                        onCheckedChange = onToggleLyricsBlur
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }

        // 5. Sleep Timer
        item {
            IosSectionLabel("SLEEP TIMER (10S SMOOTH FADE-OUT)")
            IosGroupedContainer(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    SleepTimerOption.entries.forEachIndexed { idx, opt ->
                        val selected = sleepTimerState.activeOption == opt
                        val rightHint = if (selected && sleepTimerState.remainingMs > 0L) {
                            formatDuration(sleepTimerState.remainingMs)
                        } else null

                        IosCheckmarkRow(
                            title = opt.label,
                            subtitle = rightHint,
                            selected = selected,
                            testTag = "sleep_timer_${opt.name.lowercase()}",
                            onClick = { onSelectSleepTimer(opt) }
                        )
                        if (idx < SleepTimerOption.entries.lastIndex) {
                            IosThinDivider(modifier = Modifier.padding(start = 16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IosSectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelMedium.copy(
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 0.6.sp
        ),
        color = IosSecondaryGray,
        modifier = Modifier.padding(start = 16.dp, bottom = 8.dp)
    )
}

@Composable
private fun IosCheckmarkRow(
    title: String,
    subtitle: String?,
    selected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 16.sp),
                color = Color.White
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                    color = IosSecondaryGray
                )
            }
        }
        if (selected) {
            Spacer(Modifier.width(10.dp))
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = "Selected",
                tint = AppleMusicRed,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun IosSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 16.sp),
                color = Color.White
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                color = IosSecondaryGray
            )
        }
        Spacer(Modifier.width(10.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = BitPerfectEmerald,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = Color(0xFF39393D),
                uncheckedBorderColor = Color.Transparent
            ),
            modifier = Modifier.scale(0.86f)
        )
    }
}
