package com.example.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.compose.PredictiveBackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.BlurMode
import com.example.ui.components.AppleMusicPageHeader
import com.example.ui.components.FloatingMiniPlayer
import com.example.ui.components.IosPredictiveBackContainer
import com.example.ui.components.IosThinDivider
import com.example.ui.screens.DetailScreenHost
import com.example.ui.screens.FoldersScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.NowPlayingScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AppleMusicRed
import com.example.ui.theme.IosSecondaryGray
import com.example.ui.theme.PureBlack
import kotlinx.coroutines.CancellationException

@Composable
fun SonoraApp(viewModel: MainViewModel) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val hasAudioPermission by viewModel.hasAudioPermission.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()
    val selectedRootTab by viewModel.selectedRootTab.collectAsStateWithLifecycle()
    val selectedLibrarySubTab by viewModel.selectedLibrarySubTab.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val detailStack by viewModel.detailStack.collectAsStateWithLifecycle()
    val isNowPlayingExpanded by viewModel.isNowPlayingExpanded.collectAsStateWithLifecycle()
    val snapshot by viewModel.playerSnapshot.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val audioOutputState by viewModel.audioOutputState.collectAsStateWithLifecycle()
    val sleepTimerState by viewModel.sleepTimerState.collectAsStateWithLifecycle()
    val rawLibrary by viewModel.rawLibrary.collectAsStateWithLifecycle()
    val filteredLibrary by viewModel.filteredLibrary.collectAsStateWithLifecycle()

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val audioGranted = results[Manifest.permission.READ_MEDIA_AUDIO] == true ||
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_MEDIA_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        viewModel.onPermissionStatusChanged(audioGranted)
    }

    val openAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            viewModel.openExternalAudioUri(uri)
        }
    }

    fun requestAudioAccess() {
        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.POST_NOTIFICATIONS
            )
        )
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_MEDIA_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                viewModel.onPermissionStatusChanged(granted)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(Unit) {
        val granted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_MEDIA_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        viewModel.onPermissionStatusChanged(granted)
    }

    val currentDetail = detailStack.lastOrNull()
    val hasMiniPlayer = snapshot.currentTrack != null

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
    ) {
        val useRail = maxWidth >= 700.dp

        // Generous bottom clearance so scrollable items never collide with Mini-Player or Bottom Tab Bar
        val bottomBarClearance = when {
            useRail && hasMiniPlayer -> 104.dp
            useRail -> 32.dp
            hasMiniPlayer -> 182.dp
            else -> 108.dp
        }
        val topHeaderClearance = 104.dp

        Row(modifier = Modifier.fillMaxSize()) {
            if (useRail) {
                NavigationRail(
                    containerColor = PureBlack,
                    modifier = Modifier.fillMaxHeight()
                ) {
                    Spacer(Modifier.height(16.dp))
                    RootTab.entries.forEach { tab ->
                        val selected = selectedRootTab == tab
                        NavigationRailItem(
                            selected = selected,
                            onClick = { viewModel.selectRootTab(tab) },
                            icon = {
                                Icon(
                                    imageVector = rootTabIcon(tab, selected),
                                    contentDescription = rootTabLabel(tab)
                                )
                            },
                            label = { Text(rootTabLabel(tab)) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = AppleMusicRed,
                                selectedTextColor = AppleMusicRed,
                                indicatorColor = AppleMusicRed.copy(alpha = 0.14f),
                                unselectedIconColor = IosSecondaryGray,
                                unselectedTextColor = IosSecondaryGray
                            )
                        )
                    }
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                IosPredictiveBackContainer(
                    canGoBack = currentDetail != null && !isNowPlayingExpanded,
                    onBackCompleted = { viewModel.popDetail() },
                    backgroundContent = {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(PureBlack)
                        ) {
                            when (selectedRootTab) {
                                RootTab.HOME -> {
                                    HomeScreen(
                                        library = rawLibrary,
                                        recentlyPlayed = snapshot.recentlyPlayed,
                                        hasAudioPermission = hasAudioPermission,
                                        isScanning = isScanning,
                                        currentTrackId = snapshot.currentTrack?.id,
                                        topContentPadding = topHeaderClearance,
                                        bottomContentPadding = bottomBarClearance,
                                        onAlbumClick = viewModel::openAlbum,
                                        onTrackClick = { list, idx ->
                                            viewModel.playTracks(list, idx, openNowPlaying = false)
                                        },
                                        onSeeAllSongs = {
                                            viewModel.openLibraryWithSubTab(LibrarySubTab.SONGS)
                                        },
                                        onSeeAllAlbums = {
                                            viewModel.openLibraryWithSubTab(LibrarySubTab.ALBUMS)
                                        },
                                        onRequestPermission = ::requestAudioAccess,
                                        onOpenAudioFile = {
                                            openAudioLauncher.launch(arrayOf("audio/*"))
                                        },
                                        onRescanLibrary = viewModel::rescanLibrary
                                    )
                                }

                                RootTab.LIBRARY -> {
                                    LibraryScreen(
                                        library = filteredLibrary,
                                        subTab = selectedLibrarySubTab,
                                        searchQuery = searchQuery,
                                        blurMode = settings.blurMode,
                                        hasAudioPermission = hasAudioPermission,
                                        isScanning = isScanning,
                                        currentTrackId = snapshot.currentTrack?.id,
                                        topContentPadding = topHeaderClearance,
                                        bottomContentPadding = bottomBarClearance,
                                        onSubTabSelected = viewModel::selectLibrarySubTab,
                                        onSearchQueryChange = viewModel::updateSearchQuery,
                                        onAlbumClick = viewModel::openAlbum,
                                        onArtistClick = viewModel::openArtist,
                                        onTrackClick = { list, idx ->
                                            viewModel.playTracks(list, idx, openNowPlaying = false)
                                        },
                                        onRequestPermission = ::requestAudioAccess,
                                        onOpenAudioFile = {
                                            openAudioLauncher.launch(arrayOf("audio/*"))
                                        },
                                        onRescanLibrary = viewModel::rescanLibrary
                                    )
                                }

                                RootTab.FOLDERS -> {
                                    FoldersScreen(
                                        folders = filteredLibrary.folders,
                                        searchQuery = searchQuery,
                                        blurMode = settings.blurMode,
                                        topContentPadding = topHeaderClearance,
                                        bottomContentPadding = bottomBarClearance,
                                        onSearchQueryChange = viewModel::updateSearchQuery,
                                        onFolderClick = viewModel::openFolder,
                                        onOpenAudioFile = {
                                            openAudioLauncher.launch(arrayOf("audio/*"))
                                        }
                                    )
                                }

                                RootTab.SETTINGS -> {
                                    SettingsScreen(
                                        settings = settings,
                                        audioOutputState = audioOutputState,
                                        sleepTimerState = sleepTimerState,
                                        topContentPadding = topHeaderClearance,
                                        bottomContentPadding = bottomBarClearance,
                                        onSelectBlurMode = viewModel::setBlurMode,
                                        onSelectPlaybackMode = viewModel::setPlaybackMode,
                                        onSelectSleepTimer = viewModel::setSleepTimer,
                                        onToggleLyricsAutoScroll = viewModel::setLyricsAutoScroll,
                                        onToggleLyricsBlur = viewModel::setLyricsBlurEnabled,
                                        onRefreshAudioRouting = viewModel::refreshAudioRouting
                                    )
                                }
                            }

                            // Apple Music Top Header: Large 32.sp Bold Title left + Circular Profile Icon right
                            AppleMusicPageHeader(
                                title = rootTabLabel(selectedRootTab),
                                audioOutputState = audioOutputState,
                                blurMode = settings.blurMode,
                                paletteColors = snapshot.paletteColors,
                                onProfileClick = { viewModel.selectRootTab(RootTab.SETTINGS) },
                                modifier = Modifier.align(Alignment.TopCenter)
                            )
                        }
                    },
                    foregroundContent = {
                        if (currentDetail != null) {
                            DetailScreenHost(
                                destination = currentDetail,
                                library = rawLibrary,
                                blurMode = settings.blurMode,
                                paletteColors = snapshot.paletteColors,
                                currentTrackId = snapshot.currentTrack?.id,
                                bottomContentPadding = bottomBarClearance,
                                onBack = viewModel::popDetail,
                                onPlayTracks = { tracks, idx, modeOverride ->
                                    if (modeOverride != null) {
                                        viewModel.setPlaybackMode(modeOverride)
                                    }
                                    viewModel.playTracks(tracks, idx, openNowPlaying = false)
                                }
                            )
                        }
                    }
                )

                // Floating Frosted Dark Mini-Player + Seamless Frosted Bottom Navigation Bar
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                ) {
                    val activeTrack = snapshot.currentTrack
                    if (activeTrack != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color.Transparent, Color(0x88000000))
                                    )
                                )
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            FloatingMiniPlayer(
                                track = activeTrack,
                                isPlaying = snapshot.isPlaying,
                                positionMs = snapshot.positionMs,
                                durationMs = snapshot.durationMs,
                                blurMode = settings.blurMode,
                                audioOutputState = audioOutputState,
                                onExpandNowPlaying = { viewModel.setNowPlayingExpanded(true) },
                                onTogglePlayPause = viewModel::togglePlayPause,
                                onSkipNext = viewModel::skipToNext
                            )
                        }
                    }

                    if (!useRail) {
                        AppleMusicBottomTabBar(
                            selectedTab = selectedRootTab,
                            blurMode = settings.blurMode,
                            onSelectTab = viewModel::selectRootTab
                        )
                    }
                }
            }
        }

        // Full-Screen Apple Music Now Playing Overlay with PredictiveBackHandler
        var nowPlayingBackProgress by remember { mutableFloatStateOf(0f) }

        if (isNowPlayingExpanded && snapshot.currentTrack != null) {
            PredictiveBackHandler(enabled = true) { progressFlow ->
                try {
                    progressFlow.collect { event ->
                        nowPlayingBackProgress = event.progress.coerceIn(0f, 1f)
                    }
                    nowPlayingBackProgress = 0f
                    viewModel.setNowPlayingExpanded(false)
                } catch (e: CancellationException) {
                    nowPlayingBackProgress = 0f
                    throw e
                }
            }
        }

        AnimatedVisibility(
            visible = isNowPlayingExpanded && snapshot.currentTrack != null,
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            ) + fadeIn(),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = spring(stiffness = Spring.StiffnessMedium)
            ) + fadeOut()
        ) {
            val scale = 1f - (0.08f * nowPlayingBackProgress)
            val corner = (28f * nowPlayingBackProgress).dp
            NowPlayingScreen(
                snapshot = snapshot,
                settings = settings,
                audioOutputState = audioOutputState,
                sleepTimerState = sleepTimerState,
                onCollapse = { viewModel.setNowPlayingExpanded(false) },
                onTogglePlayPause = viewModel::togglePlayPause,
                onSkipNext = viewModel::skipToNext,
                onSkipPrevious = viewModel::skipToPrevious,
                onSeekTo = viewModel::seekTo,
                onCyclePlaybackMode = viewModel::cyclePlaybackMode,
                onSelectPlaybackMode = viewModel::setPlaybackMode,
                onSelectSleepTimer = viewModel::setSleepTimer,
                onToggleLyricsAutoScroll = viewModel::setLyricsAutoScroll,
                onToggleLyricsBlur = viewModel::setLyricsBlurEnabled,
                onJumpToQueueIndex = viewModel::jumpToQueueIndex,
                modifier = Modifier
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = size.width * nowPlayingBackProgress * 0.65f
                        translationY = size.height * nowPlayingBackProgress * 0.12f
                    }
                    .clip(RoundedCornerShape(corner))
            )
        }
    }
}

@Composable
private fun AppleMusicBottomTabBar(
    selectedTab: RootTab,
    blurMode: BlurMode,
    onSelectTab: (RootTab) -> Unit
) {
    val barBg = when (blurMode) {
        BlurMode.LIQUID_GLASS -> Color(0xD90A0A0C)
        BlurMode.STATIC_FROSTED -> Color(0xEB0A0A0C)
        BlurMode.SOLID_DARK -> PureBlack
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(barBg)
            .navigationBarsPadding()
            .testTag("bottom_nav_bar")
    ) {
        IosThinDivider()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RootTab.entries.forEach { tab ->
                val selected = selectedTab == tab
                val label = rootTabLabel(tab)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSelectTab(tab) }
                        .minimumInteractiveComponentSize()
                        .padding(vertical = 6.dp)
                        .testTag("bottom_tab_${tab.name.lowercase()}"),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = rootTabIcon(tab, selected),
                        contentDescription = label,
                        tint = if (selected) AppleMusicRed else IosSecondaryGray,
                        modifier = Modifier.size(23.dp)
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 10.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                        ),
                        color = if (selected) AppleMusicRed else IosSecondaryGray,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun rootTabLabel(tab: RootTab): String = when (tab) {
    RootTab.HOME -> stringResource(R.string.tab_home)
    RootTab.LIBRARY -> stringResource(R.string.tab_library)
    RootTab.FOLDERS -> stringResource(R.string.tab_folders)
    RootTab.SETTINGS -> stringResource(R.string.tab_settings)
}

private fun rootTabIcon(tab: RootTab, selected: Boolean) = when (tab) {
    RootTab.HOME -> if (selected) Icons.Rounded.Home else Icons.Outlined.Home
    RootTab.LIBRARY -> if (selected) Icons.Rounded.LibraryMusic else Icons.Outlined.LibraryMusic
    RootTab.FOLDERS -> if (selected) Icons.Rounded.Folder else Icons.Outlined.Folder
    RootTab.SETTINGS -> if (selected) Icons.Rounded.Settings else Icons.Outlined.Settings
}
