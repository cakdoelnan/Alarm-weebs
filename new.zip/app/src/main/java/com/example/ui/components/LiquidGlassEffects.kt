package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Usb
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.model.AudioOutputState
import com.example.model.BlurMode
import com.example.model.PaletteColors
import com.example.ui.theme.AppleMusicRed
import com.example.ui.theme.BitPerfectEmerald
import com.example.ui.theme.IosGroupedBg
import com.example.ui.theme.IosSeparator
import com.example.ui.theme.PureBlack
import kotlin.math.cos
import kotlin.math.sin

/**
 * Soft, moody Apple Music iOS Now Playing Mesh Gradient with live Gaussian blur.
 * Deepened with a dark readability veil so colors feel rich, atmospheric, and refined.
 */
@Composable
fun AnimatedMeshGradientBackground(
    paletteColors: PaletteColors,
    blurMode: BlurMode,
    modifier: Modifier = Modifier
) {
    val c1 by animateColorAsState(Color(paletteColors.color1), tween(900), label = "mesh_c1")
    val c2 by animateColorAsState(Color(paletteColors.color2), tween(900), label = "mesh_c2")
    val c3 by animateColorAsState(Color(paletteColors.color3), tween(900), label = "mesh_c3")
    val c4 by animateColorAsState(Color(paletteColors.color4), tween(900), label = "mesh_c4")

    when (blurMode) {
        BlurMode.SOLID_DARK -> {
            Box(modifier = modifier.fillMaxSize().background(PureBlack))
        }

        BlurMode.STATIC_FROSTED -> {
            Box(
                modifier = modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                c1.copy(alpha = 0.28f),
                                c2.copy(alpha = 0.36f),
                                c4.copy(alpha = 0.72f),
                                PureBlack
                            )
                        )
                    )
            )
        }

        BlurMode.LIQUID_GLASS -> {
            val infiniteTransition = rememberInfiniteTransition(label = "lava_mesh")
            val phase by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = (Math.PI * 2.0).toFloat(),
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 22000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "mesh_phase"
            )

            Box(modifier = modifier.fillMaxSize().background(PureBlack)) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .blur(55.dp)
                ) {
                    val w = size.width
                    val h = size.height

                    val p1 = Offset(
                        x = w * (0.28f + 0.18f * cos(phase)),
                        y = h * (0.22f + 0.14f * sin(phase * 0.9f))
                    )
                    val p2 = Offset(
                        x = w * (0.74f + 0.16f * sin(phase + 1.4f)),
                        y = h * (0.34f + 0.18f * cos(phase * 0.8f))
                    )
                    val p3 = Offset(
                        x = w * (0.35f + 0.20f * sin(phase + 2.8f)),
                        y = h * (0.70f + 0.16f * cos(phase * 1.1f))
                    )
                    val p4 = Offset(
                        x = w * (0.72f + 0.18f * cos(phase + 4.1f)),
                        y = h * (0.78f + 0.14f * sin(phase * 0.7f))
                    )

                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(c1.copy(alpha = 0.62f), Color.Transparent),
                            center = p1,
                            radius = w * 0.82f
                        ),
                        center = p1,
                        radius = w * 0.82f
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(c2.copy(alpha = 0.60f), Color.Transparent),
                            center = p2,
                            radius = w * 0.78f
                        ),
                        center = p2,
                        radius = w * 0.78f
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(c3.copy(alpha = 0.50f), Color.Transparent),
                            center = p3,
                            radius = w * 0.82f
                        ),
                        center = p3,
                        radius = w * 0.82f
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(c4.copy(alpha = 0.75f), Color.Transparent),
                            center = p4,
                            radius = w * 0.88f
                        ),
                        center = p4,
                        radius = w * 0.88f
                    )
                }

                // Deep dark frosted veil so Now Playing stays sleek and high-contrast
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.36f),
                                    Color.Black.copy(alpha = 0.48f),
                                    Color.Black.copy(alpha = 0.68f)
                                )
                            )
                        )
                )
            }
        }
    }
}

/**
 * Refined iOS Frosted Dark Surface (subtle, restrained specular hairline — never noisy).
 */
@Composable
fun LiquidGlassSurface(
    blurMode: BlurMode,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(14.dp),
    borderWidth: Dp = 0.5.dp,
    tintAlpha: Float = 0.22f,
    content: @Composable BoxScope.() -> Unit
) {
    val bgColor = when (blurMode) {
        BlurMode.LIQUID_GLASS -> Color(0xCC18181C)
        BlurMode.STATIC_FROSTED -> Color(0xE01A1A1E)
        BlurMode.SOLID_DARK -> IosGroupedBg
    }

    val borderBrush = when (blurMode) {
        BlurMode.LIQUID_GLASS -> Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = (0.14f + tintAlpha * 0.1f).coerceAtMost(0.22f)),
                Color.White.copy(alpha = 0.05f),
                Color.White.copy(alpha = 0.10f)
            )
        )
        BlurMode.STATIC_FROSTED -> Brush.linearGradient(
            colors = listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.04f))
        )
        BlurMode.SOLID_DARK -> Brush.linearGradient(
            colors = listOf(IosSeparator, IosSeparator)
        )
    }

    Box(
        modifier = modifier
            .clip(shape)
            .background(bgColor)
            .border(width = borderWidth, brush = borderBrush, shape = shape),
        content = content
    )
}

/**
 * iOS Grouped Inset Container (#1C1C1E, 12.dp rounded corners, zero outer border clutter).
 */
@Composable
fun IosGroupedContainer(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(12.dp),
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(IosGroupedBg),
        content = content
    )
}

@Composable
fun IosThinDivider(
    modifier: Modifier = Modifier
) {
    HorizontalDivider(
        thickness = 0.5.dp,
        color = IosSeparator,
        modifier = modifier
    )
}

/**
 * Progressive iOS top/bottom edge frosted dark blur backdrop for Pure Black #000000 screens.
 */
@Composable
fun EdgeFrostedBackdrop(
    blurMode: BlurMode,
    paletteColors: PaletteColors,
    isTopEdge: Boolean,
    modifier: Modifier = Modifier
) {
    val baseColor = when (blurMode) {
        BlurMode.LIQUID_GLASS -> Color(0xD9000000)
        BlurMode.STATIC_FROSTED -> Color(0xEB000000)
        BlurMode.SOLID_DARK -> PureBlack
    }

    val colors = if (isTopEdge) {
        listOf(baseColor, baseColor.copy(alpha = 0.85f), Color.Transparent)
    } else {
        listOf(Color.Transparent, baseColor.copy(alpha = 0.88f), baseColor)
    }

    Box(
        modifier = modifier.background(Brush.verticalGradient(colors = colors))
    )
}

/**
 * Apple Music style Top Page Header:
 * Large Bold White Title (32.sp) on left + small circular profile/DAC avatar on right.
 */
@Composable
fun AppleMusicPageHeader(
    title: String,
    audioOutputState: AudioOutputState,
    blurMode: BlurMode,
    paletteColors: PaletteColors,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxWidth()) {
        EdgeFrostedBackdrop(
            blurMode = blurMode,
            paletteColors = paletteColors,
            isTopEdge = true,
            modifier = Modifier
                .fillMaxWidth()
                .height(96.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.displaySmall.copy(
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.6).sp
                ),
                color = Color.White
            )

            // Small circular profile / USB DAC status icon at top-right
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(IosGroupedBg)
                    .border(
                        width = 0.5.dp,
                        color = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald.copy(alpha = 0.7f)
                        else IosSeparator,
                        shape = CircleShape
                    )
                    .clickable(onClick = onProfileClick)
                    .testTag("top_profile_avatar_btn"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (audioOutputState.isUsbDacConnected) Icons.Rounded.Usb else Icons.Rounded.Person,
                    contentDescription = if (audioOutputState.isUsbDacConnected) audioOutputState.modeLabel else "Profile & Audio Settings",
                    tint = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else AppleMusicRed,
                    modifier = Modifier.size(19.dp)
                )
            }
        }
    }
}

@Composable
fun AlbumArtworkImage(
    artworkUri: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop
) {
    AsyncImage(
        model = ImageRequest.Builder(LocalContext.current)
            .data(artworkUri ?: R.drawable.img_default_album_art)
            .crossfade(true)
            .build(),
        placeholder = painterResource(id = R.drawable.img_default_album_art),
        error = painterResource(id = R.drawable.img_default_album_art),
        contentDescription = contentDescription,
        contentScale = contentScale,
        modifier = modifier
    )
}
