package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SonoraDarkColorScheme = darkColorScheme(
    primary = AppleMusicRed,
    onPrimary = Color.White,
    primaryContainer = AppleMusicCrimson,
    onPrimaryContainer = Color.White,
    secondary = BitPerfectGold,
    onSecondary = Color(0xFF141000),
    tertiary = BitPerfectEmerald,
    onTertiary = Color(0xFF001A09),
    background = PureBlack,
    onBackground = TextPrimary,
    surface = IosGroupedBg,
    onSurface = TextPrimary,
    surfaceVariant = IosGroupedElevated,
    onSurfaceVariant = IosSecondaryGray,
    outline = IosSeparator,
    outlineVariant = IosSeparator,
)

@Composable
fun SonoraTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SonoraDarkColorScheme,
        typography = SonoraTypography,
        content = content
    )
}
