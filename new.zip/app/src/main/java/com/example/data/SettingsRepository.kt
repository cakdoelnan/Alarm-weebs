package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.BlurMode
import com.example.model.PlaybackMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.sonoraDataStore: DataStore<Preferences> by preferencesDataStore(name = "sonora_settings")

data class UserSettings(
    val blurMode: BlurMode = BlurMode.LIQUID_GLASS,
    val playbackMode: PlaybackMode = PlaybackMode.NORMAL,
    val lyricsAutoScroll: Boolean = true,
    val lyricsBlurEnabled: Boolean = true
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val BLUR_MODE = stringPreferencesKey("blur_mode")
        val PLAYBACK_MODE = stringPreferencesKey("playback_mode")
        val LYRICS_AUTO_SCROLL = booleanPreferencesKey("lyrics_auto_scroll")
        val LYRICS_BLUR_ENABLED = booleanPreferencesKey("lyrics_blur_enabled")
    }

    val settingsFlow: Flow<UserSettings> = context.sonoraDataStore.data.map { prefs ->
        UserSettings(
            blurMode = prefs[Keys.BLUR_MODE]?.let { runCatching { BlurMode.valueOf(it) }.getOrNull() }
                ?: BlurMode.LIQUID_GLASS,
            playbackMode = prefs[Keys.PLAYBACK_MODE]?.let { runCatching { PlaybackMode.valueOf(it) }.getOrNull() }
                ?: PlaybackMode.NORMAL,
            lyricsAutoScroll = prefs[Keys.LYRICS_AUTO_SCROLL] ?: true,
            lyricsBlurEnabled = prefs[Keys.LYRICS_BLUR_ENABLED] ?: true
        )
    }

    suspend fun setBlurMode(mode: BlurMode) {
        context.sonoraDataStore.edit { it[Keys.BLUR_MODE] = mode.name }
    }

    suspend fun setPlaybackMode(mode: PlaybackMode) {
        context.sonoraDataStore.edit { it[Keys.PLAYBACK_MODE] = mode.name }
    }

    suspend fun setLyricsAutoScroll(enabled: Boolean) {
        context.sonoraDataStore.edit { it[Keys.LYRICS_AUTO_SCROLL] = enabled }
    }

    suspend fun setLyricsBlurEnabled(enabled: Boolean) {
        context.sonoraDataStore.edit { it[Keys.LYRICS_BLUR_ENABLED] = enabled }
    }
}
