package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.MainViewModel
import com.example.ui.SonoraApp
import com.example.ui.theme.SonoraTheme

class MainActivity : ComponentActivity() {

    private val mainViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            SonoraTheme {
                SonoraApp(viewModel = mainViewModel)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        mainViewModel.connectMediaService()
    }

    override fun onStop() {
        mainViewModel.disconnectMediaService()
        super.onStop()
    }
}
