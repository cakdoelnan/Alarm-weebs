package com.example.player

import android.content.Context
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import com.example.audio.BitPerfectAudioManager
import com.example.data.LibraryScanResult
import com.example.data.MediaLibraryRepository
import com.example.data.SettingsRepository
import com.example.data.UserSettings
import com.example.lyrics.LyricsRepository
import com.example.model.AudioOutputState
import com.example.model.BlurMode
import com.example.model.LyricsData
import com.example.model.PaletteColors
import com.example.model.PlaybackMode
import com.example.model.SleepTimerOption
import com.example.model.SleepTimerState
import com.example.model.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PlayerSnapshot(
    val currentTrack: Track? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val queue: List<Track> = emptyList(),
    val queueIndex: Int = -1,
    val playbackMode: PlaybackMode = PlaybackMode.NORMAL,
    val lyricsData: LyricsData = LyricsData(),
    val paletteColors: PaletteColors = PaletteColors(),
    val recentlyPlayed: List<Track> = emptyList()
)

/**
 * Process-scoped coordinator uniting ExoPlayer (inside MediaSessionService),
 * BitPerfectAudioManager, QueueEngine, SleepTimerManager, Palette extraction, and Lyrics loading
 * so background playback, lockscreen controls, and UI stay perfectly in sync.
 */
class SonoraPlaybackCoordinator private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    val settingsRepository = SettingsRepository(appContext)
    val mediaLibraryRepository = MediaLibraryRepository(appContext)
    val lyricsRepository = LyricsRepository(appContext)
    val bitPerfectAudioManager = BitPerfectAudioManager(appContext)
    val queueEngine = QueueEngine()

    private val _library = MutableStateFlow(LibraryScanResult())
    val library: StateFlow<LibraryScanResult> = _library.asStateFlow()

    private val _playerSnapshot = MutableStateFlow(PlayerSnapshot())
    val playerSnapshot: StateFlow<PlayerSnapshot> = _playerSnapshot.asStateFlow()

    private val _settings = MutableStateFlow(UserSettings())
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    val audioOutputState: StateFlow<AudioOutputState> = bitPerfectAudioManager.outputState

    private var player: Player? = null
    private var positionTickerJob: Job? = null
    private var lyricsPaletteJob: Job? = null

    val sleepTimerManager = SleepTimerManager(
        scope = scope,
        getTrackRemainingMs = {
            val p = player
            if (p != null && p.duration > 0L) {
                (p.duration - p.currentPosition).coerceAtLeast(0L)
            } else {
                val snap = _playerSnapshot.value
                (snap.durationMs - snap.positionMs).coerceAtLeast(0L)
            }
        },
        setPlayerVolume = { volume ->
            player?.volume = volume
        },
        onTimerExpiredPause = {
            player?.pause()
            player?.volume = 1f
        }
    )

    val sleepTimerState: StateFlow<SleepTimerState> = sleepTimerManager.state

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _playerSnapshot.update { it.copy(isPlaying = isPlaying) }
            if (isPlaying) {
                startPositionTicker()
            } else {
                stopPositionTicker()
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val p = player ?: return
            val dur = p.duration.takeIf { it > 0L } ?: _playerSnapshot.value.currentTrack?.durationMs ?: 0L
            _playerSnapshot.update { it.copy(durationMs = dur, positionMs = p.currentPosition.coerceAtLeast(0L)) }

            if (playbackState == Player.STATE_ENDED) {
                if (sleepTimerManager.onTrackEndedDuringEndOfSongTimer()) {
                    return
                }
                skipToNext()
            }
        }
    }

    init {
        bitPerfectAudioManager.start()
        scope.launch {
            settingsRepository.settingsFlow.collect { userSettings ->
                _settings.value = userSettings
                queueEngine.setPlaybackMode(userSettings.playbackMode)
                _playerSnapshot.update {
                    it.copy(
                        playbackMode = userSettings.playbackMode,
                        queue = queueEngine.currentQueue(),
                        queueIndex = queueEngine.currentQueueIndex()
                    )
                }
            }
        }
    }

    fun attachPlayer(exoPlayer: Player) {
        if (player === exoPlayer) return
        player?.removeListener(playerListener)
        player = exoPlayer
        exoPlayer.addListener(playerListener)
        _playerSnapshot.update {
            it.copy(
                isPlaying = exoPlayer.isPlaying,
                positionMs = exoPlayer.currentPosition.coerceAtLeast(0L),
                durationMs = exoPlayer.duration.takeIf { d -> d > 0L } ?: it.durationMs
            )
        }
        if (exoPlayer.isPlaying) {
            startPositionTicker()
        }
    }

    fun detachPlayer(exoPlayer: Player) {
        if (player === exoPlayer) {
            stopPositionTicker()
            exoPlayer.removeListener(playerListener)
            player = null
        }
    }

    suspend fun scanMediaLibrary() {
        val result = mediaLibraryRepository.scanLibrary()
        _library.value = result
        queueEngine.updateLibrary(result.tracks, result.albums)
    }

    suspend fun openExternalUri(uri: android.net.Uri): Track? {
        val track = mediaLibraryRepository.loadTrackFromUri(uri) ?: return null
        val updatedTracks = listOf(track) + _library.value.tracks.filterNot { it.id == track.id }
        val rebuilt = mediaLibraryRepository.buildLibraryResult(updatedTracks)
        _library.value = rebuilt
        queueEngine.updateLibrary(rebuilt.tracks, rebuilt.albums)
        playQueue(listOf(track), 0)
        return track
    }

    fun playQueue(tracks: List<Track>, startIndex: Int) {
        val chosen = queueEngine.startQueue(tracks, startIndex) ?: return
        loadAndPlayTrack(chosen)
    }

    fun jumpToQueueIndex(index: Int) {
        val track = queueEngine.jumpToQueueIndex(index) ?: return
        loadAndPlayTrack(track)
    }

    fun togglePlayPause() {
        val p = player ?: return
        if (p.isPlaying) {
            p.pause()
        } else {
            if (p.playbackState == Player.STATE_IDLE && _playerSnapshot.value.currentTrack != null) {
                _playerSnapshot.value.currentTrack?.let(::loadAndPlayTrack)
            } else {
                p.play()
            }
        }
    }

    fun skipToNext() {
        val next = queueEngine.nextTrack()
        if (next != null) {
            loadAndPlayTrack(next)
        } else {
            player?.pause()
            player?.seekTo(0L)
        }
    }

    fun skipToPrevious() {
        val p = player
        if (p != null && p.currentPosition > 3500L) {
            p.seekTo(0L)
            _playerSnapshot.update { it.copy(positionMs = 0L) }
            return
        }
        val prev = queueEngine.previousTrack() ?: return
        loadAndPlayTrack(prev)
    }

    fun seekTo(positionMs: Long) {
        player?.seekTo(positionMs.coerceAtLeast(0L))
        _playerSnapshot.update { it.copy(positionMs = positionMs.coerceAtLeast(0L)) }
    }

    fun cyclePlaybackMode() {
        val modes = PlaybackMode.entries
        val nextIdx = (modes.indexOf(_settings.value.playbackMode) + 1) % modes.size
        setPlaybackMode(modes[nextIdx])
    }

    fun setPlaybackMode(mode: PlaybackMode) {
        queueEngine.setPlaybackMode(mode)
        scope.launch {
            settingsRepository.setPlaybackMode(mode)
        }
        _playerSnapshot.update {
            it.copy(
                playbackMode = mode,
                queue = queueEngine.currentQueue(),
                queueIndex = queueEngine.currentQueueIndex()
            )
        }
    }

    fun setBlurMode(mode: BlurMode) {
        scope.launch { settingsRepository.setBlurMode(mode) }
    }

    fun setLyricsAutoScroll(enabled: Boolean) {
        scope.launch { settingsRepository.setLyricsAutoScroll(enabled) }
    }

    fun setLyricsBlurEnabled(enabled: Boolean) {
        scope.launch { settingsRepository.setLyricsBlurEnabled(enabled) }
    }

    fun setSleepTimer(option: SleepTimerOption) {
        sleepTimerManager.startTimer(option)
    }

    @OptIn(UnstableApi::class)
    private fun loadAndPlayTrack(track: Track) {
        // Configure Bit-Perfect USB DAC routing BEFORE AudioTrack initialization for this track
        bitPerfectAudioManager.configureForTrack(track)

        val p = player
        if (p == null) {
            Log.w(TAG, "Player not attached yet; updating snapshot only")
        } else {
            val metadata = MediaMetadata.Builder()
                .setTitle(track.title)
                .setArtist(track.artist)
                .setAlbumTitle(track.album)
                .setArtworkUri(track.albumArtUri)
                .build()

            val mediaItem = MediaItem.Builder()
                .setUri(track.contentUri)
                .setMediaId(track.id.toString())
                .setMediaMetadata(metadata)
                .build()

            p.setMediaItem(mediaItem)
            p.prepare()
            p.play()
        }

        _playerSnapshot.update {
            val updatedRecent = (listOf(track) + it.recentlyPlayed.filterNot { r -> r.id == track.id }).take(20)
            it.copy(
                currentTrack = track,
                positionMs = 0L,
                durationMs = track.durationMs,
                queue = queueEngine.currentQueue(),
                queueIndex = queueEngine.currentQueueIndex(),
                lyricsData = LyricsData(),
                recentlyPlayed = updatedRecent
            )
        }

        lyricsPaletteJob?.cancel()
        lyricsPaletteJob = scope.launch {
            val palette = mediaLibraryRepository.extractPaletteColors(track)
            val lyrics = lyricsRepository.loadLyrics(track)
            _playerSnapshot.update {
                if (it.currentTrack?.id == track.id) {
                    it.copy(paletteColors = palette, lyricsData = lyrics)
                } else it
            }
        }
    }

    private fun startPositionTicker() {
        if (positionTickerJob?.isActive == true) return
        positionTickerJob = scope.launch {
            while (true) {
                val p = player
                if (p != null) {
                    val pos = p.currentPosition.coerceAtLeast(0L)
                    val dur = p.duration.takeIf { it > 0L } ?: _playerSnapshot.value.durationMs
                    _playerSnapshot.update {
                        it.copy(positionMs = pos, durationMs = dur, isPlaying = p.isPlaying)
                    }
                }
                delay(80L) // ~12.5fps smooth ticker for word-by-word synced lyrics
            }
        }
    }

    private fun stopPositionTicker() {
        positionTickerJob?.cancel()
        positionTickerJob = null
    }

    companion object {
        private const val TAG = "SonoraCoordinator"

        @Volatile
        private var instance: SonoraPlaybackCoordinator? = null

        fun getInstance(context: Context): SonoraPlaybackCoordinator {
            return instance ?: synchronized(this) {
                instance ?: SonoraPlaybackCoordinator(context).also { instance = it }
            }
        }
    }
}
