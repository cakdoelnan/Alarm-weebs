package com.example

import android.net.Uri
import com.example.audio.AudioFormatProbe
import com.example.lyrics.Id3FlacLyricsExtractor
import com.example.lyrics.LrcParser
import com.example.lyrics.Mp4LyricsExtractor
import com.example.model.Album
import com.example.model.PlaybackMode
import com.example.model.Track
import com.example.player.QueueEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.SeekableByteChannel
import java.nio.charset.StandardCharsets
import kotlin.random.Random

class SonoraEnginesTest {

    @Test
    fun `LrcParser parses enhanced word-by-word and line timestamps`() {
        val raw = """
            [ti:Starlight]
            [00:10.00] <00:10.00> Hold <00:10.50> you <00:11.20> close
            [00:14.50] Shining through the night
        """.trimIndent()

        val parsed = LrcParser.parse(raw, "Test")
        assertTrue(parsed.isSynced)
        assertTrue(parsed.isWordSynced)
        assertEquals(2, parsed.lines.size)

        val line1 = parsed.lines[0]
        assertEquals(10_000L, line1.startTimeMs)
        assertEquals(14_500L, line1.endTimeMs)
        assertEquals("Hold you close", line1.text)
        assertEquals(3, line1.words.size)
        assertEquals(10_500L, line1.words[1].startTimeMs)
        assertEquals("you", line1.words[1].text)
    }

    @Test
    fun `Mp4LyricsExtractor reads embedded ©lyr atom from moov udta meta ilst`() {
        val lyricText = "[00:01.00] Hello ALAC World"
        val lyricBytes = lyricText.toByteArray(StandardCharsets.UTF_8)

        val dataPayload = ByteArrayOutputStream().apply {
            write(byteArrayOf(0, 0, 0, 1)) // type indicator UTF-8
            write(byteArrayOf(0, 0, 0, 0)) // locale
            write(lyricBytes)
        }.toByteArray()

        val dataBox = wrapBox("data", dataPayload)
        val lyrBox = wrapBytesBox(byteArrayOf(0xA9.toByte(), 'l'.code.toByte(), 'y'.code.toByte(), 'r'.code.toByte()), dataBox)
        val ilstBox = wrapBox("ilst", lyrBox)
        // FullBox 'meta' starts with 4-byte version/flags
        val metaPayload = byteArrayOf(0, 0, 0, 0) + ilstBox
        val metaBox = wrapBox("meta", metaPayload)
        val udtaBox = wrapBox("udta", metaBox)
        val moovBox = wrapBox("moov", udtaBox)
        val mp4 = wrapBox("ftyp", byteArrayOf(0, 0, 0, 0)) + moovBox

        val extracted = Mp4LyricsExtractor.extract(ByteArrayChannel(mp4))
        assertEquals(lyricText, extracted)
    }

    @Test
    fun `Id3FlacLyricsExtractor reads USLT and FLAC Vorbis comments`() {
        // ID3v2.3 USLT frame (UTF-8)
        val usltPayload = byteArrayOf(3) + "eng".toByteArray() + byteArrayOf(0) + "[00:02.00] ID3 Lyric".toByteArray()
        val usltFrame = "USLT".toByteArray() +
            ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(usltPayload.size).array() +
            byteArrayOf(0, 0) + usltPayload
        val tagSize = usltFrame.size
        val synchSafe = byteArrayOf(
            ((tagSize ushr 21) and 0x7F).toByte(),
            ((tagSize ushr 14) and 0x7F).toByte(),
            ((tagSize ushr 7) and 0x7F).toByte(),
            (tagSize and 0x7F).toByte()
        )
        val id3File = "ID3".toByteArray() + byteArrayOf(3, 0, 0) + synchSafe + usltFrame

        val id3Result = Id3FlacLyricsExtractor.extract(ByteArrayChannel(id3File))
        assertNotNull(id3Result)
        assertEquals("[00:02.00] ID3 Lyric", id3Result?.rawText)

        // FLAC Vorbis comment
        val commentStr = "LYRICS=[00:05.00] FLAC Tag Lyric"
        val commentBytes = commentStr.toByteArray(StandardCharsets.UTF_8)
        val vorbisPayload = ByteArrayOutputStream().apply {
            write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(4).array())
            write("test".toByteArray())
            write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(1).array())
            write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(commentBytes.size).array())
            write(commentBytes)
        }.toByteArray()
        val blockLen = vorbisPayload.size
        val flacHeader = "fLaC".toByteArray() +
            byteArrayOf(
                (0x80 or 4).toByte(),
                ((blockLen ushr 16) and 0xFF).toByte(),
                ((blockLen ushr 8) and 0xFF).toByte(),
                (blockLen and 0xFF).toByte()
            ) + vorbisPayload

        val flacResult = Id3FlacLyricsExtractor.extract(ByteArrayChannel(flacHeader))
        assertNotNull(flacResult)
        assertEquals("[00:05.00] FLAC Tag Lyric", flacResult?.rawText)
    }

    @Test
    fun `AudioFormatProbe parses FLAC STREAMINFO 96kHz 24-bit`() {
        // Sample rate = 96000 (0x17700), channels = 2 (1), bitsPerSample = 24 (23)
        // 20 bits sampleRate: 0x17, 0x70, high nibble 0x0
        // 3 bits channels-1 = 001 -> bits 3..1 of byte 20 = 001 -> 0x02
        // 5 bits bps-1 = 23 (10111) -> top 1 bit (1) in bit 0 of byte 20 -> 0x03, bottom 4 bits (0111) in top nibble of byte 21 -> 0x70
        val flac = ByteArray(42)
        flac[0] = 'f'.code.toByte()
        flac[1] = 'L'.code.toByte()
        flac[2] = 'a'.code.toByte()
        flac[3] = 'C'.code.toByte()
        flac[4] = 0 // STREAMINFO
        flac[18] = 0x17.toByte()
        flac[19] = 0x70.toByte()
        flac[20] = 0x03.toByte()
        flac[21] = 0x70.toByte()

        val info = AudioFormatProbe.parseFlacStreamInfo(ByteArrayInputStream(flac))
        assertNotNull(info)
        assertEquals(96000, info?.sampleRateHz)
        assertEquals(24, info?.bitDepth)
        assertEquals("FLAC", info?.codecLabel)
    }

    @Test
    fun `QueueEngine Smart Cross-Album Shuffle jumps across albums and Album Shuffle plays 1 to N`() {
        val tracks = (1..9).map { idx ->
            val albumIdx = ((idx - 1) / 3) + 1
            Track(
                id = idx.toLong(),
                contentUriString = "content://media/external/audio/media/$idx",
                title = "Track $idx",
                artist = "Artist $albumIdx",
                album = "Album $albumIdx",
                albumId = albumIdx.toLong(),
                albumArtUri = null,
                durationMs = 180_000L,
                trackNumber = ((idx - 1) % 3) + 1,
                year = 2024,
                mimeType = "audio/flac",
                filePath = "/Music/Album$albumIdx/Track$idx.flac",
                folderName = "Album$albumIdx",
                folderPath = "/Music/Album$albumIdx"
            )
        }
        val albums = tracks.groupBy { it.albumId }.map { (id, list) ->
            Album(id, "Album $id", "Artist $id", null, 2024, list)
        }

        val engine = QueueEngine(Random(42))
        engine.updateLibrary(tracks, albums)

        // 1. Smart Cross-Album Shuffle
        engine.setPlaybackMode(PlaybackMode.SMART_CROSS_ALBUM_SHUFFLE)
        val first = engine.startQueue(tracks.subList(0, 3), 0)!!
        val next = engine.nextTrack()!!
        assertNotEquals(first.albumId, next.albumId)

        // 2. Album Shuffle: plays track 1 -> 2 -> 3 in Album 1, then jumps to Track 1 of another album
        engine.setPlaybackMode(PlaybackMode.ALBUM_SHUFFLE)
        val a1t1 = engine.startQueue(albums[0].tracks, 0)!!
        assertEquals(1, a1t1.trackNumber)
        val a1t2 = engine.nextTrack()!!
        assertEquals(2, a1t2.trackNumber)
        val a1t3 = engine.nextTrack()!!
        assertEquals(3, a1t3.trackNumber)
        val nextAlbumTrack1 = engine.nextTrack()!!
        assertNotEquals(a1t1.albumId, nextAlbumTrack1.albumId)
        assertEquals(1, nextAlbumTrack1.trackNumber)
        assertFalse(nextAlbumTrack1.id == a1t3.id)
    }

    private fun wrapBox(type: String, payload: ByteArray): ByteArray {
        return wrapBytesBox(type.toByteArray(StandardCharsets.ISO_8859_1), payload)
    }

    private fun wrapBytesBox(typeBytes: ByteArray, payload: ByteArray): ByteArray {
        val total = 8 + payload.size
        return ByteBuffer.allocate(total).order(ByteOrder.BIG_ENDIAN)
            .putInt(total)
            .put(typeBytes)
            .put(payload)
            .array()
    }

    private class ByteArrayChannel(private val data: ByteArray) : SeekableByteChannel {
        private var pos = 0L
        private var open = true

        override fun read(dst: ByteBuffer): Int {
            if (pos >= data.size) return -1
            val toRead = minOf(dst.remaining(), (data.size - pos).toInt())
            dst.put(data, pos.toInt(), toRead)
            pos += toRead
            return toRead
        }

        override fun write(src: ByteBuffer): Int = throw UnsupportedOperationException()
        override fun position(): Long = pos
        override fun position(newPosition: Long): SeekableByteChannel {
            pos = newPosition
            return this
        }
        override fun size(): Long = data.size.toLong()
        override fun truncate(size: Long): SeekableByteChannel = throw UnsupportedOperationException()
        override fun isOpen(): Boolean = open
        override fun close() { open = false }
    }
}
