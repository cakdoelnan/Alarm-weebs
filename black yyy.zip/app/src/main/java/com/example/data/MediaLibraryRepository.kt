package com.example.data

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import com.example.audio.AudioFormatProbe
import com.example.model.Album
import com.example.model.Artist
import com.example.model.MusicFolder
import com.example.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class LibraryScanResult(
    val tracks: List<Track> = emptyList(),
    val albums: List<Album> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val folders: List<MusicFolder> = emptyList()
)

class MediaLibraryRepository(private val context: Context) {

    private val supportedExtensions = setOf("flac", "alac", "wav", "m4a", "mp3", "aac", "ogg", "opus")

    suspend fun scanLibrary(): LibraryScanResult = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<Track>()

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.BITRATE,
            MediaStore.Audio.Media.SIZE
        )

        val selection = "${MediaStore.Audio.Media.DURATION} >= 1000"
        val sortOrder = "${MediaStore.Audio.Media.ALBUM} ASC, ${MediaStore.Audio.Media.TRACK} ASC, ${MediaStore.Audio.Media.TITLE} ASC"

        runCatching {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val trackCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                val yearCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val displayCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val bitrateCol = cursor.getColumnIndex(MediaStore.Audio.Media.BITRATE)
                val sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val filePath = cursor.getString(dataCol).orEmpty()
                    val displayName = cursor.getString(displayCol).orEmpty()
                    val mimeType = cursor.getString(mimeCol).orEmpty()
                    val ext = (filePath.ifBlank { displayName }).substringAfterLast('.', "").lowercase()

                    if (ext !in supportedExtensions && !mimeType.startsWith("audio/")) continue

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val albumId = cursor.getLong(albumIdCol)
                    val albumArtUri = ContentUris.withAppendedId(
                        Uri.parse("content://media/external/audio/albumart"),
                        albumId
                    )

                    val fileObj = filePath.takeIf { it.isNotBlank() }?.let(::File)
                    val folderPath = fileObj?.parent ?: "/Music"
                    val folderName = fileObj?.parentFile?.name?.ifBlank { "Music" } ?: "Music"

                    val streamInfo = AudioFormatProbe.probe(
                        context = context,
                        uri = contentUri,
                        mimeType = mimeType,
                        fileName = displayName.ifBlank { filePath }
                    )

                    val durationMs = cursor.getLong(durationCol).coerceAtLeast(0L)
                    val msBitrateBps = if (bitrateCol >= 0) cursor.getInt(bitrateCol) else 0
                    val fileSizeBytes = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L

                    val resolvedBitrateKbps = when {
                        msBitrateBps > 0 -> (msBitrateBps / 1000)
                        streamInfo.bitrateKbps > 0 -> streamInfo.bitrateKbps
                        durationMs > 0L && fileSizeBytes > 0L -> ((fileSizeBytes * 8L) / durationMs).toInt()
                        else -> 0
                    }

                    val rawTitle = cursor.getString(titleCol).orEmpty()
                    val title = rawTitle.ifBlank {
                        displayName.substringBeforeLast('.').ifBlank { "Unknown Track" }
                    }
                    val artist = cursor.getString(artistCol)
                        ?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: "Unknown Artist"
                    val album = cursor.getString(albumCol)
                        ?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: folderName
                    val rawTrackNum = cursor.getInt(trackCol)
                    val normalizedTrackNum = if (rawTrackNum >= 1000) rawTrackNum % 1000 else rawTrackNum

                    tracks.add(
                        Track(
                            id = id,
                            contentUriString = contentUri.toString(),
                            title = title,
                            artist = artist,
                            album = album,
                            albumId = albumId,
                            albumArtUri = albumArtUri,
                            durationMs = durationMs,
                            trackNumber = normalizedTrackNum,
                            year = cursor.getInt(yearCol),
                            mimeType = mimeType,
                            filePath = filePath,
                            folderName = folderName,
                            folderPath = folderPath,
                            sampleRateHz = streamInfo.sampleRateHz,
                            bitDepth = streamInfo.bitDepth,
                            codecLabel = streamInfo.codecLabel,
                            bitrateKbps = resolvedBitrateKbps
                        )
                    )
                }
            }
        }

        buildLibraryResult(tracks)
    }

    suspend fun loadTrackFromUri(uri: Uri): Track? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "Audio Track"
            val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                ?.takeIf { it.isNotBlank() } ?: fileName.substringBeforeLast('.')
            val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                ?.takeIf { it.isNotBlank() } ?: "Unknown Artist"
            val album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
                ?.takeIf { it.isNotBlank() } ?: "Direct File"
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val bitrateKbps = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
                ?.toIntOrNull()?.let { it / 1000 } ?: 0
            val mimeType = context.contentResolver.getType(uri).orEmpty()
            val streamInfo = AudioFormatProbe.probe(context, uri, mimeType, fileName)

            Track(
                id = uri.toString().hashCode().toLong(),
                contentUriString = uri.toString(),
                title = title,
                artist = artist,
                album = album,
                albumId = album.hashCode().toLong(),
                albumArtUri = null,
                durationMs = durationMs,
                trackNumber = 1,
                year = 0,
                mimeType = mimeType,
                filePath = uri.path.orEmpty(),
                folderName = "Opened Files",
                folderPath = uri.path.orEmpty(),
                sampleRateHz = streamInfo.sampleRateHz,
                bitDepth = streamInfo.bitDepth,
                codecLabel = streamInfo.codecLabel,
                bitrateKbps = if (bitrateKbps > 0) bitrateKbps else streamInfo.bitrateKbps
            )
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    fun buildLibraryResult(tracks: List<Track>): LibraryScanResult {
        val albums = tracks.groupBy { it.albumId to it.album }
            .map { (key, albumTracks) ->
                val sortedTracks = albumTracks.sortedWith(
                    compareBy<Track> { if (it.trackNumber <= 0) Int.MAX_VALUE else it.trackNumber }
                        .thenBy { it.title }
                )
                val first = sortedTracks.first()
                Album(
                    id = key.first,
                    title = key.second,
                    artist = first.artist,
                    artworkUri = first.albumArtUri,
                    year = first.year,
                    tracks = sortedTracks
                )
            }
            .sortedBy { it.title.lowercase() }

        val artists = tracks.groupBy { it.artist }
            .map { (artistName, artistTracks) ->
                val artistAlbums = albums.filter { alb ->
                    artistTracks.any { it.albumId == alb.id }
                }
                Artist(
                    name = artistName,
                    albums = artistAlbums,
                    tracks = artistTracks.sortedBy { it.title.lowercase() }
                )
            }
            .sortedBy { it.name.lowercase() }

        val folders = tracks.groupBy { it.folderPath }
            .map { (path, folderTracks) ->
                val name = folderTracks.first().folderName
                MusicFolder(
                    name = name,
                    path = path,
                    tracks = folderTracks.sortedBy { it.title.lowercase() }
                )
            }
            .sortedBy { it.name.lowercase() }

        return LibraryScanResult(
            tracks = tracks,
            albums = albums,
            artists = artists,
            folders = folders
        )
    }
}
