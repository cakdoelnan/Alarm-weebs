package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioMixerAttributes
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.model.AudioOutputState
import com.example.model.Track
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.Executors

class BitPerfectAudioManager(context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()

    private val mediaAudioAttributes: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    private var activeUsbDevice: AudioDeviceInfo? = null
    private var currentTrack: Track? = null
    private var isRegistered = false

    private val _outputState = MutableStateFlow(AudioOutputState())
    val outputState: StateFlow<AudioOutputState> = _outputState.asStateFlow()

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
            refreshOutputRouting()
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
            val removedIds = removedDevices.map { it.id }.toSet()
            if (activeUsbDevice?.id in removedIds) {
                activeUsbDevice = null
            }
            refreshOutputRouting()
        }
    }

    private val mixerListener = AudioManager.OnPreferredMixerAttributesChangedListener { attributes, device, mixerAttributes ->
        if (attributes.usage == AudioAttributes.USAGE_MEDIA && isUsbAudioDevice(device)) {
            val isBitPerfect = mixerAttributes?.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT
            val fmt = mixerAttributes?.format
            val track = currentTrack
            _outputState.value = _outputState.value.copy(
                isUsbDacConnected = true,
                isBitPerfectActive = isBitPerfect,
                modeLabel = if (isBitPerfect) "BIT-PERFECT USB DIRECT" else "SYSTEM MIXER",
                deviceName = device.productName?.toString()?.ifBlank { "USB Audio DAC" } ?: "USB Audio DAC",
                sampleRateHz = fmt?.sampleRate ?: track?.sampleRateHz ?: 48000,
                bitDepth = fmt?.let { encodingToBitDepth(it.encoding) } ?: track?.bitDepth ?: 16,
                codecLabel = track?.codecLabel ?: "PCM",
                statusDetail = if (isBitPerfect) {
                    "Bypassing Android AudioFlinger mixer via HAL Bit-Perfect"
                } else {
                    "USB DAC connected using standard AudioFlinger mixer"
                }
            )
        }
    }

    fun start() {
        if (isRegistered) return
        isRegistered = true
        audioManager.registerAudioDeviceCallback(deviceCallback, mainHandler)
        runCatching {
            audioManager.addOnPreferredMixerAttributesChangedListener(executor, mixerListener)
        }.onFailure {
            Log.w(TAG, "Unable to register mixer attributes listener: ${it.message}")
        }
        refreshOutputRouting()
    }

    fun stop() {
        if (!isRegistered) return
        isRegistered = false
        runCatching { audioManager.unregisterAudioDeviceCallback(deviceCallback) }
        runCatching { audioManager.removeOnPreferredMixerAttributesChangedListener(mixerListener) }
        activeUsbDevice?.let { device ->
            runCatching { audioManager.clearPreferredMixerAttributes(mediaAudioAttributes, device) }
        }
        activeUsbDevice = null
    }

    fun configureForTrack(track: Track?) {
        currentTrack = track
        refreshOutputRouting()
    }

    fun refreshOutputRouting() {
        val outputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val usbDevice = outputDevices.firstOrNull { isUsbAudioDevice(it) }
        val track = currentTrack

        if (usbDevice == null) {
            // Clear any stale preference if previously set
            activeUsbDevice?.let { old ->
                runCatching { audioManager.clearPreferredMixerAttributes(mediaAudioAttributes, old) }
            }
            activeUsbDevice = null

            val activeDeviceName = resolveDefaultOutputName(outputDevices)
            _outputState.value = AudioOutputState(
                isUsbDacConnected = false,
                isBitPerfectActive = false,
                modeLabel = "SYSTEM MIXER",
                deviceName = activeDeviceName,
                sampleRateHz = track?.sampleRateHz ?: 48000,
                bitDepth = track?.bitDepth ?: 16,
                codecLabel = track?.codecLabel ?: "PCM",
                supportedProfiles = emptyList(),
                statusDetail = "Standard Android AudioFlinger output"
            )
            return
        }

        activeUsbDevice = usbDevice
        val dacName = usbDevice.productName?.toString()?.ifBlank { "USB Audio DAC" } ?: "USB Audio DAC"
        val targetRate = track?.sampleRateHz ?: 44100
        val targetBitDepth = track?.bitDepth ?: 16
        val codec = track?.codecLabel ?: "PCM"

        val supportedAttrs: List<AudioMixerAttributes> = runCatching {
            audioManager.getSupportedMixerAttributes(usbDevice)
        }.getOrElse {
            Log.w(TAG, "getSupportedMixerAttributes failed: ${it.message}")
            emptyList()
        }

        val bitPerfectAttrs = supportedAttrs.filter {
            it.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT
        }

        val profileDescriptions = supportedAttrs.map { attr ->
            val f = attr.format
            val behavior = if (attr.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT) {
                "BIT-PERFECT"
            } else {
                "MIXER"
            }
            val bits = encodingToBitDepth(f.encoding)
            "$behavior • ${formatRate(f.sampleRate)} / ${bits}-bit"
        }.distinct()

        val chosenAttr = selectBestBitPerfectProfile(bitPerfectAttrs, targetRate, targetBitDepth)

        if (chosenAttr != null) {
            val applied = runCatching {
                audioManager.setPreferredMixerAttributes(mediaAudioAttributes, usbDevice, chosenAttr)
            }.getOrElse {
                Log.w(TAG, "setPreferredMixerAttributes failed: ${it.message}")
                false
            }

            if (applied) {
                val chosenFmt = chosenAttr.format
                _outputState.value = AudioOutputState(
                    isUsbDacConnected = true,
                    isBitPerfectActive = true,
                    modeLabel = "BIT-PERFECT USB DIRECT",
                    deviceName = dacName,
                    sampleRateHz = chosenFmt.sampleRate,
                    bitDepth = encodingToBitDepth(chosenFmt.encoding),
                    codecLabel = codec,
                    supportedProfiles = profileDescriptions,
                    statusDetail = "Direct USB HAL stream active (AudioFlinger bypassed)"
                )
                return
            }
        }

        // Safe fallback to standard mixer if DAC/HAL does not support bit-perfect for this format
        runCatching { audioManager.clearPreferredMixerAttributes(mediaAudioAttributes, usbDevice) }
        _outputState.value = AudioOutputState(
            isUsbDacConnected = true,
            isBitPerfectActive = false,
            modeLabel = "SYSTEM MIXER",
            deviceName = dacName,
            sampleRateHz = targetRate,
            bitDepth = targetBitDepth,
            codecLabel = codec,
            supportedProfiles = profileDescriptions,
            statusDetail = if (bitPerfectAttrs.isEmpty()) {
                "USB DAC connected; HAL did not advertise Bit-Perfect profiles"
            } else {
                "USB DAC connected; fell back safely to System Mixer"
            }
        )
    }

    private fun selectBestBitPerfectProfile(
        candidates: List<AudioMixerAttributes>,
        targetRate: Int,
        targetBitDepth: Int
    ): AudioMixerAttributes? {
        if (candidates.isEmpty()) return null

        val stereoCandidates = candidates.filter {
            it.format.channelMask == AudioFormat.CHANNEL_OUT_STEREO ||
                it.format.channelCount == 2
        }.ifEmpty { candidates }

        val targetEncodings = preferredEncodingsForBitDepth(targetBitDepth)

        // 1. Exact sample rate + exact/preferred bit depth
        for (enc in targetEncodings) {
            stereoCandidates.firstOrNull {
                it.format.sampleRate == targetRate && it.format.encoding == enc
            }?.let { return it }
        }

        // 2. Exact sample rate with any bit-perfect PCM encoding
        stereoCandidates.firstOrNull { it.format.sampleRate == targetRate }?.let { return it }

        // 3. Integer multiple sample rate (e.g., 44.1->88.2 or 48->96)
        stereoCandidates.firstOrNull {
            it.format.sampleRate > targetRate && it.format.sampleRate % targetRate == 0
        }?.let { return it }

        // 4. Highest available bit-perfect profile
        return stereoCandidates.maxByOrNull { it.format.sampleRate }
    }

    private fun preferredEncodingsForBitDepth(bitDepth: Int): List<Int> {
        return when {
            bitDepth >= 32 -> listOf(
                AudioFormat.ENCODING_PCM_32BIT,
                AudioFormat.ENCODING_PCM_FLOAT,
                AudioFormat.ENCODING_PCM_24BIT_PACKED,
                AudioFormat.ENCODING_PCM_16BIT
            )
            bitDepth >= 24 -> listOf(
                AudioFormat.ENCODING_PCM_24BIT_PACKED,
                AudioFormat.ENCODING_PCM_32BIT,
                AudioFormat.ENCODING_PCM_FLOAT,
                AudioFormat.ENCODING_PCM_16BIT
            )
            else -> listOf(
                AudioFormat.ENCODING_PCM_16BIT,
                AudioFormat.ENCODING_PCM_24BIT_PACKED,
                AudioFormat.ENCODING_PCM_32BIT
            )
        }
    }

    private fun encodingToBitDepth(encoding: Int): Int {
        return when (encoding) {
            AudioFormat.ENCODING_PCM_8BIT -> 8
            AudioFormat.ENCODING_PCM_16BIT -> 16
            AudioFormat.ENCODING_PCM_24BIT_PACKED -> 24
            AudioFormat.ENCODING_PCM_32BIT, AudioFormat.ENCODING_PCM_FLOAT -> 32
            else -> 16
        }
    }

    private fun isUsbAudioDevice(device: AudioDeviceInfo): Boolean {
        return device.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
            device.type == AudioDeviceInfo.TYPE_USB_HEADSET
    }

    private fun resolveDefaultOutputName(devices: Array<AudioDeviceInfo>): String {
        val wired = devices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET
        }
        if (wired != null) return "Wired Headphones"

        val bt = devices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
        }
        if (bt != null) return bt.productName?.toString()?.ifBlank { "Bluetooth Audio" } ?: "Bluetooth Audio"

        return "Device Speaker"
    }

    private fun formatRate(rate: Int): String {
        return if (rate % 1000 == 0) {
            "${rate / 1000} kHz"
        } else {
            String.format(java.util.Locale.US, "%.1f kHz", rate / 1000.0)
        }
    }

    companion object {
        private const val TAG = "BitPerfectAudioManager"
    }
}
