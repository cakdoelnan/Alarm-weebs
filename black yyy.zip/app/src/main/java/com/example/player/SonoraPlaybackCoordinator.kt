package com.example.player

import android.content.Context
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import com.example.audio.BitPerfectAudioManager
import com.example.data.LibraryScanResult
import com.example.data.MediaLibraryRepository
import com.example.data.SettingsRepository
import com.example.data.UserSettings
import com.example.lyrics.LyricsRepository
import com.example.model.AudioOutputState
import com.example.model.LyricsData
import com.example.model.PlaybackMode
import com.example.model.SleepTimerOption
import com.example.model.SleepTimerState
import com.example.model.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PlayerSnapshot(
    val currentTrack: Track? = null,
    val isPlaying: Boolean = false,
    val durationMs: Long = 0L,
    val queue: List<Track> = emptyList(),
    val queueIndex: Int = -1,
    val playbackMode: PlaybackMode = PlaybackMode.NORMAL,
    val lyricsData: LyricsData = LyricsData()
)

/**
 * Process-scoped coordinator uniting ExoPlayer (inside MediaSessionService),
 * BitPerfectAudioManager, QueueEngine, SleepTimerManager, and Lyrics loading.
 *
 * Performance & Gapless highlights:
 * - Separate `positionMs` StateFlow so seekbar updates never recompose track lists.
 * - Pre-queues items in ExoPlayer's timeline for true gapless playback across all shuffle modes.
 */
class SonoraPlaybackCoordinator private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    val settingsRepository = SettingsRepository(appContext)
    val mediaLibraryRepository = MediaLibraryRepository(appContext)
    val lyricsRepository = LyricsRepository(appContext)
    val bitPerfectAudioManager = BitPerfectAudioManager(appContext)
    val queueEngine = QueueEngine()

    private val _library = MutableStateFlow(LibraryScanResult())
    val library: StateFlow<LibraryScanResult> = _library.asStateFlow()

    private val _playerSnapshot = MutableStateFlow(PlayerSnapshot())
    val playerSnapshot: StateFlow<PlayerSnapshot> = _playerSnapshot.asStateFlow()

    // Dedicated high-frequency playback position flow so UI lists never recompose on ticker ticks
    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    private val _settings = MutableStateFlow(UserSettings())
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    val audioOutputState: StateFlow<AudioOutputState> = bitPerfectAudioManager.outputState

    private var player: Player? = null
    private var positionTickerJob: Job? = null
    private var lyricsJob: Job? = null
    private var isUpdatingTimelineProgrammatically = false

    val sleepTimerManager = SleepTimerManager(
        scope = scope,
        getTrackRemainingMs = {
            val p = player
            if (p != null && p.duration > 0L) {
                (p.duration - p.currentPosition).coerceAtLeast(0L)
            } else {
                val dur = _playerSnapshot.value.durationMs
                (dur - _positionMs.value).coerceAtLeast(0L)
            }
        },
        setPlayerVolume = { volume ->
            player?.volume = volume
        },
        onTimerExpiredPause = {
            player?.pause()
            player?.volume = 1f
        }
    )

    val sleepTimerState: StateFlow<SleepTimerState> = sleepTimerManager.state

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _playerSnapshot.update { it.copy(isPlaying = isPlaying) }
            if (isPlaying) {
                startPositionTicker()
            } else {
                stopPositionTicker()
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val p = player ?: return
            val dur = p.duration.takeIf { it > 0L } ?: _playerSnapshot.value.currentTrack?.durationMs ?: 0L
            _positionMs.value = p.currentPosition.coerceAtLeast(0L)
            _playerSnapshot.update { it.copy(durationMs = dur) }

            if (playbackState == Player.STATE_ENDED) {
                if (sleepTimerManager.onTrackEndedDuringEndOfSongTimer()) {
                    return
                }
                if (queueEngine.playbackMode == PlaybackMode.ALBUM_SHUFFLE) {
                    val nextAlbumTrack = queueEngine.nextTrack()
                    if (nextAlbumTrack != null) {
                        loadQueueIntoPlayer(queueEngine.currentQueue(), queueEngine.currentQueueIndex())
                    }
                }
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            if (isUpdatingTimelineProgrammatically) return
            val p = player ?: return

            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                if (sleepTimerManager.onTrackEndedDuringEndOfSongTimer()) {
                    p.pause()
                    return
                }

                val nextTrack = when (queueEngine.playbackMode) {
                    PlaybackMode.NORMAL, PlaybackMode.ALBUM_SHUFFLE -> {
                        val idx = p.currentMediaItemIndex
                        queueEngine.jumpToQueueIndex(idx)
                    }
                    PlaybackMode.SMART_CROSS_ALBUM_SHUFFLE -> {
                        val idx = p.currentMediaItemIndex
                        val synced = if (idx in queueEngine.currentQueue().indices) {
                            queueEngine.jumpToQueueIndex(idx)
                        } else {
                            queueEngine.nextTrack()
                        }
                        // Pre-buffer one more track ahead for continuous gapless cross-album shuffle
                        if (synced != null && p.mediaItemCount - 1 <= p.currentMediaItemIndex) {
                            val upcoming = queueEngine.nextTrack()
                            if (upcoming != null) {
                                // Keep queue index pointing to currently playing item until it plays
                                queueEngine.jumpToQueueIndex(idx)
                                p.addMediaItem(buildMediaItem(upcoming))
                            }
                        }
                        synced
                    }
                }

                if (nextTrack != null) {
                    onActiveTrackChanged(nextTrack, p.duration.takeIf { it > 0L } ?: nextTrack.durationMs)
                }
            }
        }
    }

    init {
        bitPerfectAudioManager.start()
        scope.launch {
            settingsRepository.settingsFlow.collect { userSettings ->
                _settings.value = userSettings
                queueEngine.setPlaybackMode(userSettings.playbackMode)
                _playerSnapshot.update {
                    it.copy(
                        playbackMode = userSettings.playbackMode,
                        queue = queueEngine.currentQueue(),
                        queueIndex = queueEngine.currentQueueIndex()
                    )
                }
            }
        }
    }

    fun attachPlayer(exoPlayer: Player) {
        if (player === exoPlayer) return
        player?.removeListener(playerListener)
        player = exoPlayer
        exoPlayer.addListener(playerListener)
        _positionMs.value = exoPlayer.currentPosition.coerceAtLeast(0L)
        _playerSnapshot.update {
            it.copy(
                isPlaying = exoPlayer.isPlaying,
                durationMs = exoPlayer.duration.takeIf { d -> d > 0L } ?: it.durationMs
            )
        }
        if (exoPlayer.isPlaying) {
            startPositionTicker()
        }
    }

    fun detachPlayer(exoPlayer: Player) {
        if (player === exoPlayer) {
            stopPositionTicker()
            exoPlayer.removeListener(playerListener)
            player = null
        }
    }

    suspend fun scanMediaLibrary() {
        val result = mediaLibraryRepository.scanLibrary()
        _library.value = result
        queueEngine.updateLibrary(result.tracks, result.albums)
    }

    suspend fun openExternalUri(uri: android.net.Uri): Track? {
        val track = mediaLibraryRepository.loadTrackFromUri(uri) ?: return null
        val updatedTracks = listOf(track) + _library.value.tracks.filterNot { it.id == track.id }
        val rebuilt = mediaLibraryRepository.buildLibraryResult(updatedTracks)
        _library.value = rebuilt
        queueEngine.updateLibrary(rebuilt.tracks, rebuilt.albums)
        playQueue(listOf(track), 0)
        return track
    }

    fun playQueue(tracks: List<Track>, startIndex: Int) {
        val chosen = queueEngine.startQueue(tracks, startIndex) ?: return
        if (queueEngine.playbackMode == PlaybackMode.SMART_CROSS_ALBUM_SHUFFLE) {
            // Prepare current + 1 upcoming smart-shuffled track for instant gapless transition
            val upcoming = queueEngine.nextTrack()
            if (upcoming != null && upcoming.id != chosen.id) {
                val baseIdx = (queueEngine.currentQueueIndex() - 1).coerceAtLeast(0)
                queueEngine.jumpToQueueIndex(baseIdx)
            }
        }
        loadQueueIntoPlayer(queueEngine.currentQueue(), queueEngine.currentQueueIndex())
    }

    fun jumpToQueueIndex(index: Int) {
        val track = queueEngine.jumpToQueueIndex(index) ?: return
        val p = player
        if (p != null && index in 0 until p.mediaItemCount) {
            p.seekTo(index, 0L)
            p.play()
            onActiveTrackChanged(track, track.durationMs)
        } else {
            loadQueueIntoPlayer(queueEngine.currentQueue(), index)
        }
    }

    fun togglePlayPause() {
        val p = player ?: return
        if (p.isPlaying) {
            p.pause()
        } else {
            if (p.playbackState == Player.STATE_IDLE && _playerSnapshot.value.currentTrack != null) {
                loadQueueIntoPlayer(queueEngine.currentQueue(), queueEngine.currentQueueIndex())
            } else {
                p.play()
            }
        }
    }

    fun skipToNext() {
        val next = queueEngine.nextTrack()
        if (next != null) {
            val p = player
            val targetIdx = queueEngine.currentQueueIndex()
            if (p != null && targetIdx in 0 until p.mediaItemCount) {
                isUpdatingTimelineProgrammatically = true
                p.seekTo(targetIdx, 0L)
                p.play()
                isUpdatingTimelineProgrammatically = false
                onActiveTrackChanged(next, next.durationMs)
            } else {
                loadQueueIntoPlayer(queueEngine.currentQueue(), targetIdx)
            }
        } else {
            player?.pause()
            player?.seekTo(0L)
            _positionMs.value = 0L
        }
    }

    fun skipToPrevious() {
        val p = player
        if (p != null && p.currentPosition > 3500L) {
            p.seekTo(0L)
            _positionMs.value = 0L
            return
        }
        val prev = queueEngine.previousTrack() ?: return
        val targetIdx = queueEngine.currentQueueIndex()
        if (p != null && targetIdx in 0 until p.mediaItemCount) {
            isUpdatingTimelineProgrammatically = true
            p.seekTo(targetIdx, 0L)
            p.play()
            isUpdatingTimelineProgrammatically = false
            onActiveTrackChanged(prev, prev.durationMs)
        } else {
            loadQueueIntoPlayer(queueEngine.currentQueue(), targetIdx)
        }
    }

    fun seekTo(positionMs: Long) {
        val clamped = positionMs.coerceAtLeast(0L)
        player?.seekTo(clamped)
        _positionMs.value = clamped
    }

    fun cyclePlaybackMode() {
        val modes = PlaybackMode.entries
        val nextIdx = (modes.indexOf(_settings.value.playbackMode) + 1) % modes.size
        setPlaybackMode(modes[nextIdx])
    }

    fun setPlaybackMode(mode: PlaybackMode) {
        queueEngine.setPlaybackMode(mode)
        scope.launch {
            settingsRepository.setPlaybackMode(mode)
        }
        _playerSnapshot.update {
            it.copy(
                playbackMode = mode,
                queue = queueEngine.currentQueue(),
                queueIndex = queueEngine.currentQueueIndex()
            )
        }
    }

    fun setLyricsAutoScroll(enabled: Boolean) {
        scope.launch { settingsRepository.setLyricsAutoScroll(enabled) }
    }

    fun setSleepTimer(option: SleepTimerOption) {
        sleepTimerManager.startTimer(option)
    }

    @OptIn(UnstableApi::class)
    private fun loadQueueIntoPlayer(queue: List<Track>, startIndex: Int) {
        val track = queue.getOrNull(startIndex) ?: return
        bitPerfectAudioManager.configureForTrack(track)

        val p = player
        if (p == null) {
            Log.w(TAG, "Player not attached yet; updating snapshot only")
        } else {
            isUpdatingTimelineProgrammatically = true
            try {
                val items = queue.map(::buildMediaItem)
                p.setMediaItems(items, startIndex, 0L)
                p.prepare()
                p.play()
            } finally {
                isUpdatingTimelineProgrammatically = false
            }
        }

        onActiveTrackChanged(track, track.durationMs)
    }

    private fun onActiveTrackChanged(track: Track, durationMs: Long) {
        bitPerfectAudioManager.configureForTrack(track)
        _positionMs.value = 0L
        _playerSnapshot.update {
            it.copy(
                currentTrack = track,
                durationMs = durationMs,
                queue = queueEngine.currentQueue(),
                queueIndex = queueEngine.currentQueueIndex(),
                lyricsData = LyricsData()
            )
        }

        lyricsJob?.cancel()
        lyricsJob = scope.launch {
            val lyrics = lyricsRepository.loadLyrics(track)
            _playerSnapshot.update {
                if (it.currentTrack?.id == track.id) {
                    it.copy(lyricsData = lyrics)
                } else it
            }
        }
    }

    private fun buildMediaItem(track: Track): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(track.title)
            .setArtist(track.artist)
            .setAlbumTitle(track.album)
            .setArtworkUri(track.albumArtUri)
            .build()

        return MediaItem.Builder()
            .setUri(track.contentUri)
            .setMediaId(track.id.toString())
            .setMediaMetadata(metadata)
            .build()
    }

    private fun startPositionTicker() {
        if (positionTickerJob?.isActive == true) return
        positionTickerJob = scope.launch {
            while (true) {
                val p = player
                if (p != null) {
                    _positionMs.value = p.currentPosition.coerceAtLeast(0L)
                    val dur = p.duration.takeIf { it > 0L } ?: _playerSnapshot.value.durationMs
                    if (dur != _playerSnapshot.value.durationMs || p.isPlaying != _playerSnapshot.value.isPlaying) {
                        _playerSnapshot.update {
                            it.copy(durationMs = dur, isPlaying = p.isPlaying)
                        }
                    }
                }
                delay(120L)
            }
        }
    }

    private fun stopPositionTicker() {
        positionTickerJob?.cancel()
        positionTickerJob = null
    }

    companion object {
        private const val TAG = "SonoraCoordinator"

        @Volatile
        private var instance: SonoraPlaybackCoordinator? = null

        fun getInstance(context: Context): SonoraPlaybackCoordinator {
            return instance ?: synchronized(this) {
                instance ?: SonoraPlaybackCoordinator(context).also { instance = it }
            }
        }
    }
}
