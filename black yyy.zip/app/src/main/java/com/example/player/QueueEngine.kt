package com.example.player

import com.example.model.Album
import com.example.model.PlaybackMode
import com.example.model.Track
import kotlin.random.Random

/**
 * Smart Queue Engine supporting:
 * - NORMAL: sequential playback in active queue
 * - SMART_CROSS_ALBUM_SHUFFLE: jumps across all albums in library, prioritizing different albums/artists and avoiding recent repeats
 * - ALBUM_SHUFFLE: plays current album 1..N sequentially, then picks an unplayed random album
 */
class QueueEngine(private val random: Random = Random.Default) {

    private var libraryTracks: List<Track> = emptyList()
    private var libraryAlbums: List<Album> = emptyList()

    private var activeQueue: MutableList<Track> = mutableListOf()
    private var currentIndex: Int = -1
    private val playedTrackIdsHistory = ArrayDeque<Long>()
    private val playedAlbumIdsHistory = ArrayDeque<Long>()

    var playbackMode: PlaybackMode = PlaybackMode.NORMAL
        private set

    fun updateLibrary(tracks: List<Track>, albums: List<Album>) {
        libraryTracks = tracks
        libraryAlbums = albums
    }

    fun setPlaybackMode(mode: PlaybackMode) {
        playbackMode = mode
        if (mode == PlaybackMode.ALBUM_SHUFFLE && currentTrack() != null) {
            // Ensure activeQueue reflects the full album of the current track in track order
            val current = currentTrack() ?: return
            val album = libraryAlbums.firstOrNull { it.id == current.albumId }
            if (album != null && album.tracks.isNotEmpty()) {
                val sorted = album.tracks
                val idx = sorted.indexOfFirst { it.id == current.id }.coerceAtLeast(0)
                activeQueue = sorted.toMutableList()
                currentIndex = idx
            }
        }
    }

    fun startQueue(tracks: List<Track>, startIndex: Int): Track? {
        if (tracks.isEmpty()) return null
        val safeIdx = startIndex.coerceIn(0, tracks.lastIndex)
        val chosen = tracks[safeIdx]

        if (playbackMode == PlaybackMode.ALBUM_SHUFFLE) {
            val album = libraryAlbums.firstOrNull { it.id == chosen.albumId }
            if (album != null && album.tracks.isNotEmpty()) {
                activeQueue = album.tracks.toMutableList()
                currentIndex = activeQueue.indexOfFirst { it.id == chosen.id }.coerceAtLeast(0)
            } else {
                activeQueue = tracks.toMutableList()
                currentIndex = safeIdx
            }
        } else {
            activeQueue = tracks.toMutableList()
            currentIndex = safeIdx
        }

        recordPlayed(chosen)
        return chosen
    }

    fun currentTrack(): Track? = activeQueue.getOrNull(currentIndex)

    fun currentQueue(): List<Track> = activeQueue.toList()

    fun currentQueueIndex(): Int = currentIndex

    fun nextTrack(): Track? {
        val current = currentTrack() ?: return null
        return when (playbackMode) {
            PlaybackMode.NORMAL -> {
                if (currentIndex + 1 < activeQueue.size) {
                    currentIndex++
                    val next = activeQueue[currentIndex]
                    recordPlayed(next)
                    next
                } else {
                    null
                }
            }

            PlaybackMode.SMART_CROSS_ALBUM_SHUFFLE -> {
                val next = pickSmartCrossAlbumTrack(current) ?: return null
                // Append to queue history so Back works naturally
                if (currentIndex + 1 < activeQueue.size) {
                    activeQueue = activeQueue.subList(0, currentIndex + 1).toMutableList()
                }
                activeQueue.add(next)
                currentIndex = activeQueue.lastIndex
                recordPlayed(next)
                next
            }

            PlaybackMode.ALBUM_SHUFFLE -> {
                if (currentIndex + 1 < activeQueue.size) {
                    currentIndex++
                    val next = activeQueue[currentIndex]
                    recordPlayed(next)
                    next
                } else {
                    // Finished current album -> jump to another random unplayed album!
                    val nextAlbum = pickRandomNextAlbum(current.albumId) ?: return null
                    activeQueue = nextAlbum.tracks.toMutableList()
                    currentIndex = 0
                    val first = activeQueue.firstOrNull() ?: return null
                    recordPlayed(first)
                    first
                }
            }
        }
    }

    fun previousTrack(): Track? {
        if (activeQueue.isEmpty()) return null
        if (currentIndex > 0) {
            currentIndex--
            return activeQueue[currentIndex]
        }
        return activeQueue.firstOrNull()
    }

    fun jumpToQueueIndex(index: Int): Track? {
        if (index !in activeQueue.indices) return null
        currentIndex = index
        val track = activeQueue[index]
        recordPlayed(track)
        return track
    }

    private fun pickSmartCrossAlbumTrack(current: Track): Track? {
        val pool = if (libraryTracks.size > 1) libraryTracks else activeQueue
        if (pool.isEmpty()) return null
        if (pool.size == 1) return pool.first()

        val maxHistory = (pool.size * 0.65f).toInt().coerceIn(4, 60)
        while (playedTrackIdsHistory.size > maxHistory) {
            playedTrackIdsHistory.removeFirst()
        }
        val recentIds = playedTrackIdsHistory.toSet()

        // Tier 1: Different album AND different artist AND not recently played
        val tier1 = pool.filter {
            it.id != current.id &&
                it.albumId != current.albumId &&
                !it.artist.equals(current.artist, ignoreCase = true) &&
                it.id !in recentIds
        }
        if (tier1.isNotEmpty()) return tier1[random.nextInt(tier1.size)]

        // Tier 2: Different album AND not recently played
        val tier2 = pool.filter {
            it.id != current.id &&
                it.albumId != current.albumId &&
                it.id !in recentIds
        }
        if (tier2.isNotEmpty()) return tier2[random.nextInt(tier2.size)]

        // Tier 3: Any unplayed track other than current
        val tier3 = pool.filter { it.id != current.id && it.id !in recentIds }
        if (tier3.isNotEmpty()) return tier3[random.nextInt(tier3.size)]

        // History exhausted -> clear recent history and prefer different album
        playedTrackIdsHistory.clear()
        playedTrackIdsHistory.addLast(current.id)
        val tier4 = pool.filter { it.id != current.id && it.albumId != current.albumId }
        if (tier4.isNotEmpty()) return tier4[random.nextInt(tier4.size)]

        val tier5 = pool.filter { it.id != current.id }
        return if (tier5.isNotEmpty()) tier5[random.nextInt(tier5.size)] else current
    }

    private fun pickRandomNextAlbum(currentAlbumId: Long): Album? {
        if (libraryAlbums.isEmpty()) return null
        if (libraryAlbums.size == 1) return libraryAlbums.first()

        val unplayedAlbums = libraryAlbums.filter {
            it.id != currentAlbumId && it.id !in playedAlbumIdsHistory && it.tracks.isNotEmpty()
        }
        if (unplayedAlbums.isNotEmpty()) {
            return unplayedAlbums[random.nextInt(unplayedAlbums.size)]
        }

        // All albums played -> reset history and pick any album other than current
        playedAlbumIdsHistory.clear()
        playedAlbumIdsHistory.addLast(currentAlbumId)
        val others = libraryAlbums.filter { it.id != currentAlbumId && it.tracks.isNotEmpty() }
        return if (others.isNotEmpty()) others[random.nextInt(others.size)] else libraryAlbums.first()
    }

    private fun recordPlayed(track: Track) {
        if (playedTrackIdsHistory.lastOrNull() != track.id) {
            playedTrackIdsHistory.addLast(track.id)
        }
        if (playedAlbumIdsHistory.lastOrNull() != track.albumId) {
            playedAlbumIdsHistory.addLast(track.albumId)
        }
    }
}
