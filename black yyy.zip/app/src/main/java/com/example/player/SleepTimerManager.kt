package com.example.player

import com.example.model.SleepTimerOption
import com.example.model.SleepTimerState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SleepTimerManager(
    private val scope: CoroutineScope,
    private val getTrackRemainingMs: () -> Long,
    private val setPlayerVolume: (Float) -> Unit,
    private val onTimerExpiredPause: () -> Unit
) {
    private val _state = MutableStateFlow(SleepTimerState())
    val state: StateFlow<SleepTimerState> = _state.asStateFlow()

    private var timerJob: Job? = null
    private var endTimestampMs: Long = 0L

    fun startTimer(option: SleepTimerOption) {
        cancel()
        if (option == SleepTimerOption.OFF) return

        if (option == SleepTimerOption.END_OF_SONG) {
            _state.value = SleepTimerState(
                activeOption = option,
                remainingMs = getTrackRemainingMs().coerceAtLeast(0L),
                isFadingOut = false
            )
            timerJob = scope.launch {
                while (true) {
                    val remaining = getTrackRemainingMs().coerceAtLeast(0L)
                    if (remaining in 1L..FADE_DURATION_MS) {
                        val vol = (remaining.toFloat() / FADE_DURATION_MS.toFloat()).coerceIn(0f, 1f)
                        setPlayerVolume(vol)
                        _state.value = SleepTimerState(option, remaining, isFadingOut = true)
                    } else {
                        setPlayerVolume(1f)
                        _state.value = SleepTimerState(option, remaining, isFadingOut = false)
                    }

                    if (remaining <= 150L) {
                        onTimerExpiredPause()
                        cancel()
                        break
                    }
                    delay(150L)
                }
            }
            return
        }

        val durationMs = (option.minutes ?: 15) * 60_000L
        endTimestampMs = System.currentTimeMillis() + durationMs
        _state.value = SleepTimerState(option, durationMs, isFadingOut = false)

        timerJob = scope.launch {
            while (true) {
                val remaining = (endTimestampMs - System.currentTimeMillis()).coerceAtLeast(0L)
                if (remaining <= FADE_DURATION_MS && remaining > 0L) {
                    val vol = (remaining.toFloat() / FADE_DURATION_MS.toFloat()).coerceIn(0f, 1f)
                    setPlayerVolume(vol)
                    _state.value = SleepTimerState(option, remaining, isFadingOut = true)
                } else {
                    _state.value = SleepTimerState(option, remaining, isFadingOut = false)
                }

                if (remaining == 0L) {
                    onTimerExpiredPause()
                    cancel()
                    break
                }
                delay(150L)
            }
        }
    }

    fun onTrackEndedDuringEndOfSongTimer(): Boolean {
        if (_state.value.activeOption == SleepTimerOption.END_OF_SONG) {
            onTimerExpiredPause()
            cancel()
            return true
        }
        return false
    }

    fun cancel() {
        timerJob?.cancel()
        timerJob = null
        setPlayerVolume(1f)
        _state.value = SleepTimerState()
    }

    companion object {
        private const val FADE_DURATION_MS = 10_000L
    }
}
