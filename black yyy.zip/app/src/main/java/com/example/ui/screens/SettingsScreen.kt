package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Usb
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserSettings
import com.example.model.AudioOutputState
import com.example.model.PlaybackMode
import com.example.model.SleepTimerOption
import com.example.model.SleepTimerState
import com.example.ui.components.FoobarThinDivider
import com.example.ui.components.formatDuration
import com.example.ui.theme.BitPerfectEmerald
import com.example.ui.theme.FoobarElevatedSurface
import com.example.ui.theme.FoobarRowSurface
import com.example.ui.theme.FoobarTextPrimary
import com.example.ui.theme.FoobarTextSecondary
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite

/**
 * Minimalist foobar2000 Mobile Settings Screen:
 * - Pure OLED Black (#000000) canvas + #0D0D0D rows + 0.5.dp #222222 dividers
 * - Zero blur, zero DSP/EQ clutter — preserves Bit-Perfect USB DAC, Queue Engine, Sleep Timer, Lyrics
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: UserSettings,
    audioOutputState: AudioOutputState,
    sleepTimerState: SleepTimerState,
    bottomContentPadding: Dp,
    onSelectPlaybackMode: (PlaybackMode) -> Unit,
    onSelectSleepTimer: (SleepTimerOption) -> Unit,
    onToggleLyricsAutoScroll: (Boolean) -> Unit,
    onRefreshAudioRouting: () -> Unit,
    onRescanLibrary: () -> Unit,
    onOpenAudioFile: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showPlaybackSheet by remember { mutableStateOf(false) }
    var showSleepSheet by remember { mutableStateOf(false) }
    var showDacSheet by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(bottom = bottomContentPadding),
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
            .testTag("settings_screen")
    ) {
        item(key = "section_audio") {
            FoobarSectionHeader("AUDIO OUTPUT & BIT-PERFECT USB DAC")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(FoobarRowSurface)
                    .clickable { showDacSheet = true }
                    .padding(horizontal = 14.dp, vertical = 12.dp)
                    .testTag("settings_dac_row"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.Usb,
                    contentDescription = null,
                    tint = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else PureWhite,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = audioOutputState.modeLabel,
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                        color = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else FoobarTextPrimary
                    )
                    Text(
                        text = "${audioOutputState.deviceName} • ${audioOutputState.formattedSampleRate} / ${audioOutputState.bitDepth}-bit • Direct Match (No DSP/EQ)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = FoobarTextSecondary
                    )
                }
                IconButton(
                    onClick = onRefreshAudioRouting,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = "Refresh DAC Routing",
                        tint = PureWhite,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            FoobarThinDivider()
        }

        item(key = "section_playback") {
            Spacer(Modifier.height(16.dp))
            FoobarSectionHeader("PLAYBACK & QUEUE")
            FoobarSettingRow(
                icon = Icons.Rounded.Shuffle,
                title = "Shuffle Mode",
                subtitle = settings.playbackMode.title,
                testTag = "settings_playback_mode_row",
                onClick = { showPlaybackSheet = true }
            )
            FoobarThinDivider()

            val sleepSub = if (sleepTimerState.activeOption != SleepTimerOption.OFF && sleepTimerState.remainingMs > 0L) {
                "${sleepTimerState.activeOption.label} • ${formatDuration(sleepTimerState.remainingMs)}"
            } else {
                sleepTimerState.activeOption.label
            }
            FoobarSettingRow(
                icon = Icons.Rounded.Bedtime,
                title = "Sleep Timer",
                subtitle = sleepSub,
                testTag = "settings_sleep_timer_row",
                onClick = { showSleepSheet = true }
            )
            FoobarThinDivider()
        }

        item(key = "section_lyrics") {
            Spacer(Modifier.height(16.dp))
            FoobarSectionHeader("LYRICS")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(FoobarRowSurface)
                    .clickable { onToggleLyricsAutoScroll(!settings.lyricsAutoScroll) }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.Lyrics,
                    contentDescription = null,
                    tint = PureWhite,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Auto-Scroll Synced Lyrics",
                        style = MaterialTheme.typography.bodyLarge,
                        color = FoobarTextPrimary
                    )
                    Text(
                        text = "Follow active LRC / ALAC / ID3 / FLAC timestamp",
                        style = MaterialTheme.typography.bodyMedium,
                        color = FoobarTextSecondary
                    )
                }
                Switch(
                    checked = settings.lyricsAutoScroll,
                    onCheckedChange = onToggleLyricsAutoScroll,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = PureBlack,
                        checkedTrackColor = PureWhite,
                        uncheckedThumbColor = PureWhite,
                        uncheckedTrackColor = FoobarElevatedSurface,
                        uncheckedBorderColor = FoobarTextSecondary
                    ),
                    modifier = Modifier.scale(0.85f)
                )
            }
            FoobarThinDivider()
        }

        item(key = "section_library") {
            Spacer(Modifier.height(16.dp))
            FoobarSectionHeader("LIBRARY")
            FoobarSettingRow(
                icon = Icons.Rounded.Refresh,
                title = "Rescan Media Library",
                subtitle = "Scan local FLAC, ALAC, WAV, M4A, and MP3 files",
                testTag = "settings_rescan_row",
                onClick = onRescanLibrary
            )
            FoobarThinDivider()
            FoobarSettingRow(
                icon = Icons.Rounded.AudioFile,
                title = "Open External Audio File",
                subtitle = "Play any lossless file directly via document picker",
                testTag = "settings_open_file_row",
                onClick = onOpenAudioFile
            )
            FoobarThinDivider()
        }
    }

    if (showPlaybackSheet) {
        ModalBottomSheet(
            onDismissRequest = { showPlaybackSheet = false },
            containerColor = FoobarRowSurface
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Shuffle Mode", style = MaterialTheme.typography.titleLarge, color = PureWhite)
                Spacer(Modifier.height(12.dp))
                PlaybackMode.entries.forEachIndexed { idx, mode ->
                    val selected = settings.playbackMode == mode
                    FoobarSheetOptionRow(
                        title = mode.title,
                        subtitle = mode.description,
                        selected = selected,
                        testTag = "settings_playback_mode_${mode.name.lowercase()}",
                        onClick = {
                            onSelectPlaybackMode(mode)
                            showPlaybackSheet = false
                        }
                    )
                    if (idx < PlaybackMode.entries.lastIndex) FoobarThinDivider()
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showSleepSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSleepSheet = false },
            containerColor = FoobarRowSurface
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Sleep Timer", style = MaterialTheme.typography.titleLarge, color = PureWhite)
                Text(
                    text = "10-second linear fade-out before pausing",
                    style = MaterialTheme.typography.bodyMedium,
                    color = FoobarTextSecondary
                )
                Spacer(Modifier.height(12.dp))
                SleepTimerOption.entries.forEachIndexed { idx, opt ->
                    val selected = sleepTimerState.activeOption == opt
                    FoobarSheetOptionRow(
                        title = opt.label,
                        subtitle = null,
                        selected = selected,
                        testTag = "sleep_timer_${opt.name.lowercase()}",
                        onClick = {
                            onSelectSleepTimer(opt)
                            showSleepSheet = false
                        }
                    )
                    if (idx < SleepTimerOption.entries.lastIndex) FoobarThinDivider()
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showDacSheet) {
        ModalBottomSheet(
            onDismissRequest = { showDacSheet = false },
            containerColor = FoobarRowSurface
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Audio Signal Path", style = MaterialTheme.typography.titleLarge, color = PureWhite)
                Spacer(Modifier.height(10.dp))
                Text(
                    text = audioOutputState.modeLabel,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else PureWhite
                )
                Text(
                    text = "${audioOutputState.deviceName} • ${audioOutputState.formattedSampleRate} / ${audioOutputState.bitDepth}-bit",
                    style = MaterialTheme.typography.bodyLarge,
                    color = FoobarTextPrimary
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = audioOutputState.statusDetail,
                    style = MaterialTheme.typography.bodyMedium,
                    color = FoobarTextSecondary
                )
                if (audioOutputState.supportedProfiles.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    Text("Supported HAL Mixer Profiles", style = MaterialTheme.typography.titleMedium, color = PureWhite)
                    Spacer(Modifier.height(6.dp))
                    audioOutputState.supportedProfiles.take(12).forEach { profile ->
                        Text(
                            text = "• $profile",
                            style = MaterialTheme.typography.bodyMedium,
                            color = FoobarTextSecondary,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun FoobarSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelMedium.copy(
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.5.sp
        ),
        color = FoobarTextSecondary,
        modifier = Modifier
            .fillMaxWidth()
            .background(PureBlack)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
    FoobarThinDivider()
}

@Composable
private fun FoobarSettingRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(FoobarRowSurface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = PureWhite,
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = FoobarTextPrimary
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = FoobarTextSecondary
            )
        }
        Icon(
            imageVector = Icons.Rounded.ChevronRight,
            contentDescription = null,
            tint = FoobarTextSecondary,
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun FoobarSheetOptionRow(
    title: String,
    subtitle: String?,
    selected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                ),
                color = if (selected) PureWhite else FoobarTextSecondary
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = FoobarTextSecondary
                )
            }
        }
        if (selected) {
            Spacer(Modifier.width(10.dp))
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = "Selected",
                tint = PureWhite,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
