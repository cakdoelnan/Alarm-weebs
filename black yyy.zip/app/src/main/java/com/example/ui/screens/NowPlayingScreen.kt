package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.UserSettings
import com.example.model.AudioOutputState
import com.example.model.PlaybackMode
import com.example.model.SleepTimerOption
import com.example.model.SleepTimerState
import com.example.player.PlayerSnapshot
import com.example.ui.components.AlbumArtworkImage
import com.example.ui.components.FoobarLyricsView
import com.example.ui.components.FoobarThinDivider
import com.example.ui.components.formatDuration
import com.example.ui.theme.BitPerfectEmerald
import com.example.ui.theme.BitPerfectGold
import com.example.ui.theme.FoobarDivider
import com.example.ui.theme.FoobarElevatedSurface
import com.example.ui.theme.FoobarRowSurface
import com.example.ui.theme.FoobarTextPrimary
import com.example.ui.theme.FoobarTextSecondary
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import kotlinx.coroutines.flow.StateFlow

/**
 * Minimalist foobar2000 Mobile Now Playing Screen:
 * - Pure OLED Black (#000000), zero blur, zero mesh gradient, zero heavy shadows
 * - Classic vertical layout: Artwork (4.dp corners) -> Title/Artist/Album ->
 *   foobar2000 Tech & Output Bar (tappable for Stats for Nerds) ->
 *   High-precision Seekbar (isolated recomposition) ->
 *   Classic Controls (Shuffle, Prev, Play/Pause, Next, Sleep Timer) ->
 *   Lyrics panel toggle (zero-blur Synced LRC/ALAC/ID3/FLAC)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(
    snapshot: PlayerSnapshot,
    positionMsFlow: StateFlow<Long>,
    settings: UserSettings,
    audioOutputState: AudioOutputState,
    sleepTimerState: SleepTimerState,
    onCollapse: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onSelectPlaybackMode: (PlaybackMode) -> Unit,
    onSelectSleepTimer: (SleepTimerOption) -> Unit,
    onToggleLyricsAutoScroll: (Boolean) -> Unit,
    onJumpToQueueIndex: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val track = snapshot.currentTrack ?: return

    var showLyrics by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }
    var showSleepSheet by remember { mutableStateOf(false) }
    var showStatsDialog by remember { mutableStateOf(false) }
    var showModeSheet by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Minimalist Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onCollapse,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("now_playing_collapse_btn")
            ) {
                Icon(
                    imageVector = Icons.Rounded.KeyboardArrowDown,
                    contentDescription = "Collapse Now Playing",
                    tint = PureWhite,
                    modifier = Modifier.size(26.dp)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (showLyrics) "Lyrics" else "Now Playing",
                    style = MaterialTheme.typography.titleMedium,
                    color = FoobarTextPrimary
                )
                if (sleepTimerState.activeOption != SleepTimerOption.OFF) {
                    val sleepLabel = if (sleepTimerState.isFadingOut) {
                        "Fading out • ${formatDuration(sleepTimerState.remainingMs)}"
                    } else {
                        "Sleep in ${formatDuration(sleepTimerState.remainingMs)}"
                    }
                    Text(
                        text = sleepLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = FoobarTextSecondary
                    )
                }
            }

            IconButton(
                onClick = { showQueueSheet = true },
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("open_queue_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.QueueMusic,
                    contentDescription = "Playing Queue",
                    tint = PureWhite,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        // Center Area: Large Square Artwork (corner 4.dp) OR Synced Lyrics Panel
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .widthIn(max = 480.dp)
                .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            if (showLyrics) {
                FoobarLyricsView(
                    lyricsData = snapshot.lyricsData,
                    positionMsFlow = positionMsFlow,
                    autoScrollEnabled = settings.lyricsAutoScroll,
                    onToggleAutoScroll = onToggleLyricsAutoScroll,
                    onSeekToLine = onSeekTo
                )
            } else {
                AlbumArtworkImage(
                    artworkUri = track.albumArtUri,
                    contentDescription = track.album,
                    modifier = Modifier
                        .fillMaxWidth(0.88f)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .border(0.5.dp, FoobarDivider, RoundedCornerShape(4.dp))
                )
            }
        }

        // Track Metadata & Controls Block
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 480.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = track.title,
                style = MaterialTheme.typography.headlineMedium,
                color = FoobarTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(3.dp))
            Text(
                text = track.artist,
                style = MaterialTheme.typography.bodyLarge,
                color = FoobarTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
            Text(
                text = track.album,
                style = MaterialTheme.typography.bodyMedium,
                color = FoobarTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(12.dp))

            // foobar2000 Audio Output & Tech Info Bar (tappable -> Stats for Nerds)
            val outputModeTag = if (audioOutputState.isBitPerfectActive) "Direct Match" else "System Mixer"
            val techBarText = buildString {
                append(track.codecLabel)
                append(" | ")
                append(track.formattedSampleRate)
                append(" | ")
                append("${track.bitDepth}-bit")
                append(" | ")
                append(track.formattedBitrate)
                append(" | Output: ")
                append("${audioOutputState.deviceName} - $outputModeTag")
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(FoobarRowSurface)
                    .border(
                        width = 0.5.dp,
                        color = if (audioOutputState.isBitPerfectActive) {
                            BitPerfectEmerald.copy(alpha = 0.55f)
                        } else FoobarDivider,
                        shape = RoundedCornerShape(4.dp)
                    )
                    .clickable { showStatsDialog = true }
                    .padding(horizontal = 10.dp, vertical = 8.dp)
                    .testTag("tech_info_bar"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = techBarText,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                    color = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else FoobarTextSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(Modifier.height(8.dp))

            // High-Precision Seekbar (isolated recomposition)
            NowPlayingSeekBar(
                positionMsFlow = positionMsFlow,
                durationMs = snapshot.durationMs.coerceAtLeast(1L),
                onSeekTo = onSeekTo
            )

            Spacer(Modifier.height(8.dp))

            // Classic Transport Controls Row: Shuffle, Prev, Play/Pause, Next, Sleep Timer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { showModeSheet = true },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("playback_mode_btn")
                ) {
                    Icon(
                        imageVector = when (snapshot.playbackMode) {
                            PlaybackMode.NORMAL -> Icons.Rounded.Repeat
                            PlaybackMode.SMART_CROSS_ALBUM_SHUFFLE -> Icons.Rounded.Shuffle
                            PlaybackMode.ALBUM_SHUFFLE -> Icons.Rounded.Album
                        },
                        contentDescription = snapshot.playbackMode.title,
                        tint = if (snapshot.playbackMode != PlaybackMode.NORMAL) PureWhite else FoobarTextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                IconButton(
                    onClick = onSkipPrevious,
                    modifier = Modifier
                        .size(52.dp)
                        .testTag("now_playing_prev")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.SkipPrevious,
                        contentDescription = "Previous",
                        tint = PureWhite,
                        modifier = Modifier.size(34.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(PureWhite)
                        .clickable(onClick = onTogglePlayPause)
                        .testTag("now_playing_play_pause"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (snapshot.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (snapshot.isPlaying) "Pause" else "Play",
                        tint = PureBlack,
                        modifier = Modifier.size(34.dp)
                    )
                }

                IconButton(
                    onClick = onSkipNext,
                    modifier = Modifier
                        .size(52.dp)
                        .testTag("now_playing_next")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.SkipNext,
                        contentDescription = "Next",
                        tint = PureWhite,
                        modifier = Modifier.size(34.dp)
                    )
                }

                IconButton(
                    onClick = { showSleepSheet = true },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("sleep_timer_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Bedtime,
                        contentDescription = "Sleep Timer",
                        tint = if (sleepTimerState.activeOption != SleepTimerOption.OFF) PureWhite else FoobarTextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            // Compact Lyrics Toggle Bar
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (showLyrics) PureWhite else FoobarRowSurface)
                    .border(0.5.dp, FoobarDivider, RoundedCornerShape(4.dp))
                    .clickable { showLyrics = !showLyrics }
                    .minimumInteractiveComponentSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("toggle_lyrics_btn"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Lyrics,
                    contentDescription = null,
                    tint = if (showLyrics) PureBlack else PureWhite,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = if (showLyrics) "Show Cover Art" else "Synced Lyrics",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = if (showLyrics) PureBlack else PureWhite
                )
            }

            Spacer(Modifier.height(12.dp))
        }
    }

    // Stats for Nerds Dialog (Signal Path, Codec, Sample Rate, Bit Depth, Bitrate, HAL Mixer)
    if (showStatsDialog) {
        AlertDialog(
            onDismissRequest = { showStatsDialog = false },
            containerColor = FoobarRowSurface,
            titleContentColor = PureWhite,
            textContentColor = FoobarTextSecondary,
            title = {
                Text("Stats for Nerds", style = MaterialTheme.typography.titleLarge)
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    StatDialogRow(
                        label = "Output Mode",
                        value = audioOutputState.modeLabel,
                        isHighlight = audioOutputState.isBitPerfectActive
                    )
                    FoobarThinDivider(modifier = Modifier.padding(vertical = 6.dp))
                    StatDialogRow(label = "Audio Device", value = audioOutputState.deviceName)
                    FoobarThinDivider(modifier = Modifier.padding(vertical = 6.dp))
                    StatDialogRow(
                        label = "Source Stream",
                        value = "${track.codecLabel} • ${track.formattedSampleRate} / ${track.bitDepth}-bit • ${track.formattedBitrate}"
                    )
                    FoobarThinDivider(modifier = Modifier.padding(vertical = 6.dp))
                    StatDialogRow(
                        label = "Hardware Stream",
                        value = "${audioOutputState.formattedSampleRate} / ${audioOutputState.bitDepth}-bit (No DSP/EQ)"
                    )
                    FoobarThinDivider(modifier = Modifier.padding(vertical = 6.dp))
                    StatDialogRow(label = "Gapless Engine", value = "Active (ExoPlayer Timeline)")
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = audioOutputState.statusDetail,
                        style = MaterialTheme.typography.bodyMedium,
                        color = FoobarTextSecondary
                    )
                    if (audioOutputState.supportedProfiles.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = "DAC HAL Mixer Profiles",
                            style = MaterialTheme.typography.labelMedium,
                            color = PureWhite
                        )
                        Spacer(Modifier.height(4.dp))
                        audioOutputState.supportedProfiles.take(8).forEach { profile ->
                            Text(
                                text = "• $profile",
                                style = MaterialTheme.typography.bodyMedium,
                                color = FoobarTextSecondary
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showStatsDialog = false }) {
                    Text("Close", color = PureWhite)
                }
            }
        )
    }

    if (showModeSheet) {
        ModalBottomSheet(
            onDismissRequest = { showModeSheet = false },
            containerColor = FoobarRowSurface
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Shuffle Mode", style = MaterialTheme.typography.titleLarge, color = PureWhite)
                Spacer(Modifier.height(12.dp))
                PlaybackMode.entries.forEachIndexed { idx, mode ->
                    val selected = snapshot.playbackMode == mode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectPlaybackMode(mode)
                                showModeSheet = false
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = mode.title,
                                style = MaterialTheme.typography.bodyLarge,
                                color = if (selected) PureWhite else FoobarTextSecondary
                            )
                            Text(
                                text = mode.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = FoobarTextSecondary
                            )
                        }
                        if (selected) {
                            Icon(Icons.Rounded.Check, contentDescription = "Selected", tint = PureWhite)
                        }
                    }
                    if (idx < PlaybackMode.entries.lastIndex) FoobarThinDivider()
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showSleepSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSleepSheet = false },
            containerColor = FoobarRowSurface
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(stringResource(R.string.sleep_timer_title), style = MaterialTheme.typography.titleLarge, color = PureWhite)
                Text(
                    text = "10-second linear fade-out before pausing",
                    style = MaterialTheme.typography.bodyMedium,
                    color = FoobarTextSecondary
                )
                Spacer(Modifier.height(12.dp))
                SleepTimerOption.entries.forEachIndexed { idx, opt ->
                    val selected = sleepTimerState.activeOption == opt
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectSleepTimer(opt)
                                showSleepSheet = false
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = opt.label,
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (selected) PureWhite else FoobarTextSecondary,
                            modifier = Modifier.weight(1f)
                        )
                        if (selected) {
                            Icon(Icons.Rounded.Check, contentDescription = "Selected", tint = PureWhite)
                        }
                    }
                    if (idx < SleepTimerOption.entries.lastIndex) FoobarThinDivider()
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showQueueSheet) {
        ModalBottomSheet(
            onDismissRequest = { showQueueSheet = false },
            containerColor = FoobarRowSurface
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Text(
                    text = "Playing Next (${snapshot.playbackMode.title})",
                    style = MaterialTheme.typography.titleLarge,
                    color = PureWhite
                )
                Spacer(Modifier.height(10.dp))
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(360.dp)
                ) {
                    itemsIndexed(
                        items = snapshot.queue,
                        key = { idx, t -> "q_${t.id}_$idx" }
                    ) { index, item ->
                        val isCurrent = index == snapshot.queueIndex
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (isCurrent) FoobarElevatedSurface else FoobarRowSurface)
                                .clickable {
                                    onJumpToQueueIndex(index)
                                    showQueueSheet = false
                                }
                                .padding(vertical = 8.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AlbumArtworkImage(
                                artworkUri = item.albumArtUri,
                                contentDescription = item.album,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(4.dp))
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (isCurrent) PureWhite else FoobarTextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = item.compactTechSummary,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = FoobarTextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        if (index < snapshot.queue.lastIndex) {
                            FoobarThinDivider()
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun NowPlayingSeekBar(
    positionMsFlow: StateFlow<Long>,
    durationMs: Long,
    onSeekTo: (Long) -> Unit
) {
    val positionMs by positionMsFlow.collectAsStateWithLifecycle()
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubPositionMs by remember { mutableFloatStateOf(0f) }

    val displayedPositionMs = if (isScrubbing) scrubPositionMs.toLong() else positionMs
    val remaining = (durationMs - displayedPositionMs).coerceAtLeast(0L)

    Column(modifier = Modifier.fillMaxWidth()) {
        Slider(
            value = displayedPositionMs.toFloat().coerceIn(0f, durationMs.toFloat()),
            onValueChange = {
                isScrubbing = true
                scrubPositionMs = it
            },
            onValueChangeFinished = {
                onSeekTo(scrubPositionMs.toLong())
                isScrubbing = false
            },
            valueRange = 0f..durationMs.toFloat(),
            colors = SliderDefaults.colors(
                thumbColor = PureWhite,
                activeTrackColor = PureWhite,
                inactiveTrackColor = FoobarDivider
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("now_playing_slider")
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = formatDuration(displayedPositionMs),
                style = MaterialTheme.typography.labelSmall,
                color = FoobarTextSecondary
            )
            Text(
                text = "-${formatDuration(remaining)} / ${formatDuration(durationMs)}",
                style = MaterialTheme.typography.labelSmall,
                color = FoobarTextSecondary
            )
        }
    }
}

@Composable
private fun StatDialogRow(
    label: String,
    value: String,
    isHighlight: Boolean = false
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = FoobarTextSecondary
        )
        Spacer(Modifier.height(1.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
            color = if (isHighlight) BitPerfectEmerald else PureWhite
        )
    }
}
