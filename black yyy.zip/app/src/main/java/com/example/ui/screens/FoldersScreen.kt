package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.MusicFolder
import com.example.ui.components.FoobarThinDivider
import com.example.ui.theme.FoobarDivider
import com.example.ui.theme.FoobarElevatedSurface
import com.example.ui.theme.FoobarRowSurface
import com.example.ui.theme.FoobarTextPrimary
import com.example.ui.theme.FoobarTextSecondary
import com.example.ui.theme.FoobarTextTertiary
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite

@Composable
fun FoldersScreen(
    folders: List<MusicFolder>,
    bottomContentPadding: Dp,
    onFolderClick: (MusicFolder) -> Unit,
    onOpenAudioFile: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        contentPadding = PaddingValues(bottom = bottomContentPadding),
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
            .testTag("folders_list")
    ) {
        item(key = "folders_action_bar") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PureBlack)
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${folders.size} Folders",
                    style = MaterialTheme.typography.bodyMedium,
                    color = FoobarTextSecondary
                )
                TextButton(
                    onClick = onOpenAudioFile,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("folders_open_file_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AudioFile,
                        contentDescription = null,
                        tint = PureWhite,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        text = stringResource(R.string.open_audio_file),
                        color = PureWhite,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            FoobarThinDivider()
        }

        if (folders.isEmpty()) {
            item(key = "folders_empty") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(FoobarRowSurface)
                        .border(0.5.dp, FoobarDivider, RoundedCornerShape(4.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Rounded.Folder,
                            contentDescription = null,
                            tint = FoobarTextTertiary,
                            modifier = Modifier.size(34.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "No audio folders detected yet (FLAC, ALAC, WAV, M4A, MP3).",
                            style = MaterialTheme.typography.bodyMedium,
                            color = FoobarTextSecondary
                        )
                    }
                }
            }
        } else {
            itemsIndexed(
                items = folders,
                key = { _, folder -> "fld_${folder.path}" }
            ) { index, folder ->
                val codecs = folder.tracks.map { it.codecLabel }.distinct().take(3).joinToString(" • ")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(FoobarRowSurface)
                        .clickable { onFolderClick(folder) }
                        .padding(horizontal = 14.dp, vertical = 9.dp)
                        .testTag("folder_row_${folder.name}"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(FoobarElevatedSurface),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Folder,
                            contentDescription = folder.name,
                            tint = PureWhite,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = folder.name,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            ),
                            color = FoobarTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "${folder.tracks.size} tracks • $codecs • ${folder.path}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                            color = FoobarTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Icon(
                        imageVector = Icons.Rounded.ChevronRight,
                        contentDescription = "Open folder",
                        tint = FoobarTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                if (index < folders.lastIndex) {
                    FoobarThinDivider()
                }
            }
        }
    }
}
