package com.example.ui.components

import androidx.activity.compose.PredictiveBackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException

/**
 * iOS-style Predictive Back Transition Container:
 * While swiping back from screen edge:
 * - Active foreground page smoothly scales down (1.0f -> 0.92f) and shifts right
 * - Underlying previous page reveals from below with parallax horizontal offset
 */
@Composable
fun IosPredictiveBackContainer(
    canGoBack: Boolean,
    onBackCompleted: () -> Unit,
    modifier: Modifier = Modifier,
    backgroundContent: @Composable () -> Unit,
    foregroundContent: @Composable () -> Unit
) {
    var gestureProgress by remember { mutableFloatStateOf(0f) }
    val enterSlide = remember(canGoBack) { Animatable(if (canGoBack) 1f else 0f) }

    LaunchedEffect(canGoBack) {
        if (canGoBack) {
            gestureProgress = 0f
            enterSlide.animateTo(
                targetValue = 0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        } else {
            gestureProgress = 0f
        }
    }

    if (canGoBack) {
        PredictiveBackHandler(enabled = true) { progressFlow ->
            try {
                progressFlow.collect { backEvent ->
                    gestureProgress = backEvent.progress.coerceIn(0f, 1f)
                }
                gestureProgress = 0f
                onBackCompleted()
            } catch (e: CancellationException) {
                gestureProgress = 0f
                throw e
            }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        // Underlying previous layer with iOS parallax effect
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    if (canGoBack) {
                        val combined = (1f - gestureProgress - enterSlide.value).coerceIn(0f, 1f)
                        translationX = -size.width * 0.22f * combined
                        val bgScale = 0.96f + 0.04f * (1f - combined)
                        scaleX = bgScale
                        scaleY = bgScale
                    }
                }
        ) {
            backgroundContent()
        }

        if (canGoBack) {
            // Subtle dim scrim between layers during transition
            val scrimAlpha = (0.45f * (1f - gestureProgress) * (1f - enterSlide.value)).coerceIn(0f, 0.45f)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = scrimAlpha))
            )

            // Active foreground page: scales 1.0f -> 0.92f and slides right on swipe-back
            val activeScale = 1f - (0.08f * gestureProgress)
            val cornerRadius = (28f * gestureProgress).dp

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = activeScale
                        scaleY = activeScale
                        translationX = size.width * (enterSlide.value + gestureProgress * 0.85f)
                    }
                    .clip(RoundedCornerShape(cornerRadius))
            ) {
                foregroundContent()
            }
        }
    }
}
