package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val FoobarDarkColorScheme = darkColorScheme(
    primary = PureWhite,
    onPrimary = PureBlack,
    primaryContainer = FoobarElevatedSurface,
    onPrimaryContainer = PureWhite,
    secondary = FoobarTextSecondary,
    onSecondary = PureBlack,
    tertiary = BitPerfectEmerald,
    onTertiary = PureBlack,
    background = PureBlack,
    onBackground = FoobarTextPrimary,
    surface = FoobarRowSurface,
    onSurface = FoobarTextPrimary,
    surfaceVariant = FoobarElevatedSurface,
    onSurfaceVariant = FoobarTextSecondary,
    outline = FoobarDivider,
    outlineVariant = FoobarDivider,
    surfaceContainer = FoobarRowSurface,
    surfaceContainerHigh = FoobarElevatedSurface
)

@Composable
fun UragiristereoTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = FoobarDarkColorScheme,
        typography = SonoraTypography,
        content = content
    )
}
