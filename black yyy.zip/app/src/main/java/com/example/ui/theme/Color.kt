package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// foobar2000 Mobile (OLED Pure Black + Pure White Accent) Palette
val PureBlack = Color(0xFF000000)
val FoobarRowSurface = Color(0xFF0D0D0D)
val FoobarElevatedSurface = Color(0xFF141414)
val FoobarDivider = Color(0xFF222222)
val FoobarMiniPlayerTopBorder = Color(0xFF333333)

val PureWhite = Color(0xFFFFFFFF)
val FoobarTextPrimary = Color(0xFFFFFFFF)
val FoobarTextSecondary = Color(0xFFA0A0A0)
val FoobarTextTertiary = Color(0xFF6B6B6B)

val BitPerfectEmerald = Color(0xFF30D158)
val BitPerfectGold = Color(0xFFF5C451)
