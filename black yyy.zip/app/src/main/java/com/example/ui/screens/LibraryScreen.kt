package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.LibraryScanResult
import com.example.model.Album
import com.example.model.Artist
import com.example.model.Track
import com.example.ui.FoobarTab
import com.example.ui.components.AlbumArtworkImage
import com.example.ui.components.FoobarCompactTrackRow
import com.example.ui.components.FoobarEmptyState
import com.example.ui.components.FoobarThinDivider
import com.example.ui.theme.FoobarElevatedSurface
import com.example.ui.theme.FoobarRowSurface
import com.example.ui.theme.FoobarTextPrimary
import com.example.ui.theme.FoobarTextSecondary
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite

@Composable
fun FoobarLibraryListScreen(
    tab: FoobarTab,
    library: LibraryScanResult,
    searchQuery: String,
    hasAudioPermission: Boolean,
    isScanning: Boolean,
    currentTrackId: Long?,
    bottomContentPadding: Dp,
    onAlbumClick: (Album) -> Unit,
    onArtistClick: (Artist) -> Unit,
    onTrackClick: (List<Track>, Int) -> Unit,
    onRequestPermission: () -> Unit,
    onOpenAudioFile: () -> Unit,
    onRescanLibrary: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
    ) {
        if (!hasAudioPermission && library.tracks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = bottomContentPadding),
                contentAlignment = Alignment.Center
            ) {
                FoobarEmptyState(
                    title = stringResource(R.string.permission_audio_title),
                    body = stringResource(R.string.permission_audio_body),
                    primaryLabel = stringResource(R.string.permission_audio_cta),
                    secondaryLabel = stringResource(R.string.open_audio_file),
                    onPrimaryClick = onRequestPermission,
                    onSecondaryClick = onOpenAudioFile
                )
            }
            return
        }

        if (isScanning && library.tracks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = bottomContentPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = PureWhite, strokeWidth = 2.dp)
            }
            return
        }

        if (library.tracks.isEmpty() && searchQuery.isBlank()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = bottomContentPadding),
                contentAlignment = Alignment.Center
            ) {
                FoobarEmptyState(
                    title = stringResource(R.string.empty_library_title),
                    body = stringResource(R.string.empty_library_body),
                    primaryLabel = stringResource(R.string.open_audio_file),
                    secondaryLabel = stringResource(R.string.rescan_library),
                    onPrimaryClick = onOpenAudioFile,
                    onSecondaryClick = onRescanLibrary
                )
            }
            return
        }

        when (tab) {
            FoobarTab.ALBUMS -> {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = bottomContentPadding),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("library_albums_list")
                ) {
                    itemsIndexed(
                        items = library.albums,
                        key = { _, album -> "alb_${album.id}_${album.title}" }
                    ) { index, album ->
                        FoobarAlbumRow(
                            album = album,
                            onClick = { onAlbumClick(album) }
                        )
                        if (index < library.albums.lastIndex) {
                            FoobarThinDivider()
                        }
                    }
                }
            }

            FoobarTab.ARTISTS -> {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = bottomContentPadding),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("library_artists_list")
                ) {
                    itemsIndexed(
                        items = library.artists,
                        key = { _, artist -> "art_${artist.name}" }
                    ) { index, artist ->
                        FoobarArtistRow(
                            artist = artist,
                            onClick = { onArtistClick(artist) }
                        )
                        if (index < library.artists.lastIndex) {
                            FoobarThinDivider()
                        }
                    }
                }
            }

            FoobarTab.SONGS -> {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = bottomContentPadding),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("library_songs_list")
                ) {
                    itemsIndexed(
                        items = library.tracks,
                        key = { _, track -> "trk_${track.id}" }
                    ) { index, track ->
                        FoobarCompactTrackRow(
                            track = track,
                            isPlayingCurrent = track.id == currentTrackId,
                            onClick = { onTrackClick(library.tracks, index) }
                        )
                        if (index < library.tracks.lastIndex) {
                            FoobarThinDivider()
                        }
                    }
                }
            }

            else -> Unit
        }
    }
}

@Composable
private fun FoobarAlbumRow(
    album: Album,
    onClick: () -> Unit
) {
    val firstTrack = album.tracks.firstOrNull()
    val techNote = if (firstTrack != null) {
        "${album.artist} • ${album.tracks.size} tracks • ${firstTrack.codecLabel} ${firstTrack.formattedSampleRate}"
    } else {
        "${album.artist} • ${album.tracks.size} tracks"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(FoobarRowSurface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag("album_row_${album.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumArtworkImage(
            artworkUri = album.artworkUri,
            contentDescription = album.title,
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(4.dp))
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = album.title,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                ),
                color = FoobarTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = techNote,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                color = FoobarTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Icon(
            imageVector = Icons.Rounded.ChevronRight,
            contentDescription = null,
            tint = FoobarTextSecondary,
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun FoobarArtistRow(
    artist: Artist,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(FoobarRowSurface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp)
            .testTag("artist_row_${artist.name}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(FoobarElevatedSurface),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.Person,
                contentDescription = artist.name,
                tint = PureWhite,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = artist.name,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                ),
                color = FoobarTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = "${artist.albums.size} albums • ${artist.tracks.size} tracks",
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                color = FoobarTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Icon(
            imageVector = Icons.Rounded.ChevronRight,
            contentDescription = null,
            tint = FoobarTextSecondary,
            modifier = Modifier.size(18.dp)
        )
    }
}
