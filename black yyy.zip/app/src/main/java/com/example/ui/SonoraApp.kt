package com.example.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.compose.PredictiveBackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Usb
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.components.FoobarDockedMiniPlayer
import com.example.ui.components.FoobarSearchBar
import com.example.ui.components.FoobarThinDivider
import com.example.ui.components.IosPredictiveBackContainer
import com.example.ui.screens.DetailScreenHost
import com.example.ui.screens.FoobarLibraryListScreen
import com.example.ui.screens.FoldersScreen
import com.example.ui.screens.NowPlayingScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.BitPerfectEmerald
import com.example.ui.theme.FoobarTextSecondary
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.UragiristereoTheme
import kotlinx.coroutines.CancellationException

@Composable
fun SonoraApp(viewModel: MainViewModel) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val hasAudioPermission by viewModel.hasAudioPermission.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val isSearchVisible by viewModel.isSearchVisible.collectAsStateWithLifecycle()
    val detailStack by viewModel.detailStack.collectAsStateWithLifecycle()
    val isNowPlayingExpanded by viewModel.isNowPlayingExpanded.collectAsStateWithLifecycle()
    val snapshot by viewModel.playerSnapshot.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val audioOutputState by viewModel.audioOutputState.collectAsStateWithLifecycle()
    val sleepTimerState by viewModel.sleepTimerState.collectAsStateWithLifecycle()
    val rawLibrary by viewModel.rawLibrary.collectAsStateWithLifecycle()
    val filteredLibrary by viewModel.filteredLibrary.collectAsStateWithLifecycle()

    UragiristereoTheme {
        val permissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestMultiplePermissions()
        ) { results ->
            val audioGranted = results[Manifest.permission.READ_MEDIA_AUDIO] == true ||
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_MEDIA_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
            viewModel.onPermissionStatusChanged(audioGranted)
        }

        val openAudioLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) {
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                viewModel.openExternalAudioUri(uri)
            }
        }

        fun requestAudioAccess() {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.READ_MEDIA_AUDIO,
                    Manifest.permission.POST_NOTIFICATIONS
                )
            )
        }

        DisposableEffect(lifecycleOwner) {
            val observer = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME) {
                    val granted = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.READ_MEDIA_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
                    viewModel.onPermissionStatusChanged(granted)
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
        }

        LaunchedEffect(Unit) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_MEDIA_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            viewModel.onPermissionStatusChanged(granted)
        }

        val currentDetail = detailStack.lastOrNull()
        val hasMiniPlayer = snapshot.currentTrack != null
        val navBarBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
        val bottomListClearance = if (hasMiniPlayer) 12.dp else navBarBottom + 12.dp

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(PureBlack)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    IosPredictiveBackContainer(
                        canGoBack = currentDetail != null && !isNowPlayingExpanded,
                        onBackCompleted = { viewModel.popDetail() },
                        backgroundContent = {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(PureBlack)
                            ) {
                                // 1. Top App Title Bar ("uragiristereo")
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(PureBlack)
                                        .statusBarsPadding()
                                        .padding(start = 14.dp, end = 4.dp, top = 6.dp, bottom = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = stringResource(R.string.app_name),
                                        style = MaterialTheme.typography.displaySmall,
                                        color = PureWhite,
                                        modifier = Modifier.weight(1f)
                                    )

                                    if (audioOutputState.isUsbDacConnected) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier
                                                .padding(end = 6.dp)
                                                .clickable { viewModel.selectTab(FoobarTab.SETTINGS) }
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Usb,
                                                contentDescription = audioOutputState.modeLabel,
                                                tint = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else FoobarTextSecondary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(Modifier.width(3.dp))
                                            Text(
                                                text = if (audioOutputState.isBitPerfectActive) "DIRECT" else "USB",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else FoobarTextSecondary
                                            )
                                        }
                                    }

                                    if (selectedTab != FoobarTab.SETTINGS) {
                                        IconButton(
                                            onClick = viewModel::toggleSearchVisible,
                                            modifier = Modifier
                                                .minimumInteractiveComponentSize()
                                                .testTag("toggle_search_btn")
                                        ) {
                                            Icon(
                                                imageVector = if (isSearchVisible) Icons.Rounded.Close else Icons.Rounded.Search,
                                                contentDescription = "Filter",
                                                tint = PureWhite,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }

                                    IconButton(
                                        onClick = viewModel::rescanLibrary,
                                        modifier = Modifier
                                            .minimumInteractiveComponentSize()
                                            .testTag("rescan_library_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Refresh,
                                            contentDescription = stringResource(R.string.rescan_library),
                                            tint = PureWhite,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                // 2. Minimalist foobar2000 Top Tab Bar (Albums, Artists, Songs, Folders, Settings)
                                FoobarTopTabBar(
                                    selectedTab = selectedTab,
                                    onSelectTab = viewModel::selectTab
                                )

                                if (isSearchVisible && selectedTab != FoobarTab.SETTINGS) {
                                    FoobarSearchBar(
                                        query = searchQuery,
                                        onQueryChange = viewModel::updateSearchQuery
                                    )
                                    FoobarThinDivider()
                                }

                                // 3. Active Tab Content
                                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                                    when (selectedTab) {
                                        FoobarTab.ALBUMS,
                                        FoobarTab.ARTISTS,
                                        FoobarTab.SONGS -> {
                                            FoobarLibraryListScreen(
                                                tab = selectedTab,
                                                library = filteredLibrary,
                                                searchQuery = searchQuery,
                                                hasAudioPermission = hasAudioPermission,
                                                isScanning = isScanning,
                                                currentTrackId = snapshot.currentTrack?.id,
                                                bottomContentPadding = bottomListClearance,
                                                onAlbumClick = viewModel::openAlbum,
                                                onArtistClick = viewModel::openArtist,
                                                onTrackClick = { list, idx ->
                                                    viewModel.playTracks(list, idx, openNowPlaying = false)
                                                },
                                                onRequestPermission = ::requestAudioAccess,
                                                onOpenAudioFile = {
                                                    openAudioLauncher.launch(arrayOf("audio/*"))
                                                },
                                                onRescanLibrary = viewModel::rescanLibrary
                                            )
                                        }

                                        FoobarTab.FOLDERS -> {
                                            FoldersScreen(
                                                folders = filteredLibrary.folders,
                                                bottomContentPadding = bottomListClearance,
                                                onFolderClick = viewModel::openFolder,
                                                onOpenAudioFile = {
                                                    openAudioLauncher.launch(arrayOf("audio/*"))
                                                }
                                            )
                                        }

                                        FoobarTab.SETTINGS -> {
                                            SettingsScreen(
                                                settings = settings,
                                                audioOutputState = audioOutputState,
                                                sleepTimerState = sleepTimerState,
                                                bottomContentPadding = bottomListClearance,
                                                onSelectPlaybackMode = viewModel::setPlaybackMode,
                                                onSelectSleepTimer = viewModel::setSleepTimer,
                                                onToggleLyricsAutoScroll = viewModel::setLyricsAutoScroll,
                                                onRefreshAudioRouting = viewModel::refreshAudioRouting,
                                                onRescanLibrary = viewModel::rescanLibrary,
                                                onOpenAudioFile = {
                                                    openAudioLauncher.launch(arrayOf("audio/*"))
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        },
                        foregroundContent = {
                            if (currentDetail != null) {
                                DetailScreenHost(
                                    destination = currentDetail,
                                    library = rawLibrary,
                                    currentTrackId = snapshot.currentTrack?.id,
                                    bottomContentPadding = bottomListClearance,
                                    onBack = viewModel::popDetail,
                                    onPlayTracks = { tracks, idx, modeOverride ->
                                        if (modeOverride != null) {
                                            viewModel.setPlaybackMode(modeOverride)
                                        }
                                        viewModel.playTracks(tracks, idx, openNowPlaying = false)
                                    }
                                )
                            }
                        }
                    )
                }

                // 4. Flat Docked Mini-Player at screen bottom
                val activeTrack = snapshot.currentTrack
                if (activeTrack != null) {
                    FoobarDockedMiniPlayer(
                        track = activeTrack,
                        isPlaying = snapshot.isPlaying,
                        durationMs = snapshot.durationMs,
                        positionMsFlow = viewModel.positionMs,
                        audioOutputState = audioOutputState,
                        onExpandNowPlaying = { viewModel.setNowPlayingExpanded(true) },
                        onTogglePlayPause = viewModel::togglePlayPause,
                        onSkipNext = viewModel::skipToNext
                    )
                }
            }

            // 5. Full-Screen foobar2000 Now Playing with PredictiveBackHandler
            var nowPlayingBackProgress by remember { mutableFloatStateOf(0f) }

            if (isNowPlayingExpanded && snapshot.currentTrack != null) {
                PredictiveBackHandler(enabled = true) { progressFlow ->
                    try {
                        progressFlow.collect { event ->
                            nowPlayingBackProgress = event.progress.coerceIn(0f, 1f)
                        }
                        nowPlayingBackProgress = 0f
                        viewModel.setNowPlayingExpanded(false)
                    } catch (e: CancellationException) {
                        nowPlayingBackProgress = 0f
                        throw e
                    }
                }
            }

            AnimatedVisibility(
                visible = isNowPlayingExpanded && snapshot.currentTrack != null,
                enter = slideInVertically(
                    initialOffsetY = { it },
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioNoBouncy,
                        stiffness = Spring.StiffnessMedium
                    )
                ) + fadeIn(),
                exit = slideOutVertically(
                    targetOffsetY = { it },
                    animationSpec = spring(stiffness = Spring.StiffnessMedium)
                ) + fadeOut()
            ) {
                val scale = 1f - (0.06f * nowPlayingBackProgress)
                val corner = (16f * nowPlayingBackProgress).dp
                NowPlayingScreen(
                    snapshot = snapshot,
                    positionMsFlow = viewModel.positionMs,
                    settings = settings,
                    audioOutputState = audioOutputState,
                    sleepTimerState = sleepTimerState,
                    onCollapse = { viewModel.setNowPlayingExpanded(false) },
                    onTogglePlayPause = viewModel::togglePlayPause,
                    onSkipNext = viewModel::skipToNext,
                    onSkipPrevious = viewModel::skipToPrevious,
                    onSeekTo = viewModel::seekTo,
                    onSelectPlaybackMode = viewModel::setPlaybackMode,
                    onSelectSleepTimer = viewModel::setSleepTimer,
                    onToggleLyricsAutoScroll = viewModel::setLyricsAutoScroll,
                    onJumpToQueueIndex = viewModel::jumpToQueueIndex,
                    modifier = Modifier
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = size.width * nowPlayingBackProgress * 0.65f
                            translationY = size.height * nowPlayingBackProgress * 0.10f
                        }
                        .clip(RoundedCornerShape(corner))
                )
            }
        }
    }
}

@Composable
private fun FoobarTopTabBar(
    selectedTab: FoobarTab,
    onSelectTab: (FoobarTab) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(PureBlack)
            .testTag("foobar_top_tabs")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            FoobarTab.entries.forEach { tab ->
                val selected = tab == selectedTab
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSelectTab(tab) }
                        .minimumInteractiveComponentSize()
                        .testTag("top_tab_${tab.name.lowercase()}"),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = tab.label,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 12.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                        ),
                        color = if (selected) PureWhite else FoobarTextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 2.dp)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.dp)
                            .background(if (selected) PureWhite else PureBlack)
                    )
                }
            }
        }
        FoobarThinDivider()
    }
}
