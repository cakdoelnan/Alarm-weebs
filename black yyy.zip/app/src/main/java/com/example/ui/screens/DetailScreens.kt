package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.LibraryScanResult
import com.example.model.PlaybackMode
import com.example.model.Track
import com.example.ui.DetailDestination
import com.example.ui.components.AlbumArtworkImage
import com.example.ui.components.FoobarCompactTrackRow
import com.example.ui.components.FoobarThinDivider
import com.example.ui.theme.FoobarDivider
import com.example.ui.theme.FoobarRowSurface
import com.example.ui.theme.FoobarTextPrimary
import com.example.ui.theme.FoobarTextSecondary
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite

@Composable
fun DetailScreenHost(
    destination: DetailDestination,
    library: LibraryScanResult,
    currentTrackId: Long?,
    bottomContentPadding: Dp,
    onBack: () -> Unit,
    onPlayTracks: (List<Track>, Int, PlaybackMode?) -> Unit,
    modifier: Modifier = Modifier
) {
    val title: String
    val subtitle: String
    val artworkUri: Any?
    val tracks: List<Track>

    when (destination) {
        is DetailDestination.AlbumDetail -> {
            val album = library.albums.firstOrNull { it.id == destination.albumId }
            title = album?.title ?: "Album"
            subtitle = album?.let { "${it.artist} • ${it.tracks.size} tracks" } ?: ""
            artworkUri = album?.artworkUri
            tracks = album?.tracks.orEmpty()
        }

        is DetailDestination.ArtistDetail -> {
            val artist = library.artists.firstOrNull { it.name == destination.artistName }
            title = artist?.name ?: destination.artistName
            subtitle = artist?.let { "${it.albums.size} albums • ${it.tracks.size} tracks" } ?: ""
            artworkUri = artist?.albums?.firstOrNull()?.artworkUri
            tracks = artist?.tracks.orEmpty()
        }

        is DetailDestination.FolderDetail -> {
            val folder = library.folders.firstOrNull { it.path == destination.folderPath }
            title = folder?.name ?: "Folder"
            subtitle = folder?.path ?: destination.folderPath
            artworkUri = folder?.tracks?.firstOrNull()?.albumArtUri
            tracks = folder?.tracks.orEmpty()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
    ) {
        // Minimalist flat top bar (#000000)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(PureBlack)
                .statusBarsPadding()
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("detail_back_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = PureWhite
                )
            }
            Spacer(Modifier.width(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = FoobarTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
        }
        FoobarThinDivider()

        LazyColumn(
            contentPadding = PaddingValues(bottom = bottomContentPadding),
            modifier = Modifier.fillMaxSize()
        ) {
            item(key = "detail_header") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PureBlack)
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (destination is DetailDestination.FolderDetail) {
                            Box(
                                modifier = Modifier
                                    .size(84.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(FoobarRowSurface)
                                    .border(0.5.dp, FoobarDivider, RoundedCornerShape(4.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Folder,
                                    contentDescription = title,
                                    tint = PureWhite,
                                    modifier = Modifier.size(38.dp)
                                )
                            }
                        } else {
                            AlbumArtworkImage(
                                artworkUri = artworkUri,
                                contentDescription = title,
                                modifier = Modifier
                                    .size(84.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .border(0.5.dp, FoobarDivider, RoundedCornerShape(4.dp))
                            )
                        }

                        Spacer(Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleLarge,
                                color = FoobarTextPrimary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = subtitle,
                                style = MaterialTheme.typography.bodyMedium,
                                color = FoobarTextSecondary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                if (tracks.isNotEmpty()) {
                                    onPlayTracks(tracks, 0, PlaybackMode.NORMAL)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PureWhite,
                                contentColor = PureBlack
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("detail_play_all_btn")
                        ) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Play All", fontWeight = FontWeight.SemiBold)
                        }

                        OutlinedButton(
                            onClick = {
                                if (tracks.isNotEmpty()) {
                                    onPlayTracks(
                                        tracks,
                                        0,
                                        PlaybackMode.SMART_CROSS_ALBUM_SHUFFLE
                                    )
                                }
                            },
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = FoobarRowSurface,
                                contentColor = PureWhite
                            ),
                            border = androidx.compose.foundation.BorderStroke(0.5.dp, FoobarDivider),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("detail_shuffle_btn")
                        ) {
                            Icon(Icons.Rounded.Shuffle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Shuffle", fontWeight = FontWeight.Medium)
                        }
                    }
                }
                FoobarThinDivider()
            }

            itemsIndexed(
                items = tracks,
                key = { idx, t -> "det_${t.id}_$idx" }
            ) { index, track ->
                FoobarCompactTrackRow(
                    track = track,
                    isPlayingCurrent = track.id == currentTrackId,
                    onClick = { onPlayTracks(tracks, index, null) }
                )
                if (index < tracks.lastIndex) {
                    FoobarThinDivider()
                }
            }
        }
    }
}
