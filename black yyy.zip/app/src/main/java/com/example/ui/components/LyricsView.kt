package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.VerticalAlignCenter
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.LyricsData
import com.example.ui.theme.FoobarDivider
import com.example.ui.theme.FoobarRowSurface
import com.example.ui.theme.FoobarTextSecondary
import com.example.ui.theme.FoobarTextTertiary
import com.example.ui.theme.PureBlack
import com.example.ui.theme.PureWhite
import kotlinx.coroutines.flow.StateFlow

/**
 * Lightweight, zero-blur Synced LRC / ALAC / ID3 / FLAC Lyrics Panel.
 */
@Composable
fun FoobarLyricsView(
    lyricsData: LyricsData,
    positionMsFlow: StateFlow<Long>,
    autoScrollEnabled: Boolean,
    onToggleAutoScroll: (Boolean) -> Unit,
    onSeekToLine: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val positionMs by positionMsFlow.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()

    val activeIndex = remember(lyricsData, positionMs) {
        if (!lyricsData.isSynced || lyricsData.lines.isEmpty()) -1
        else {
            val idx = lyricsData.lines.indexOfLast { it.startTimeMs <= positionMs }
            idx.coerceAtLeast(0)
        }
    }

    LaunchedEffect(activeIndex, autoScrollEnabled) {
        if (autoScrollEnabled && activeIndex >= 0 && activeIndex < lyricsData.lines.size) {
            listState.animateScrollToItem(
                index = activeIndex,
                scrollOffset = -160
            )
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val tagText = buildString {
                append(lyricsData.sourceLabel.ifBlank { "Lyrics" })
                if (lyricsData.isWordSynced) append(" • Word Sync")
                else if (lyricsData.isSynced) append(" • Synced")
            }
            Text(
                text = tagText,
                style = MaterialTheme.typography.labelMedium,
                color = FoobarTextSecondary
            )

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(FoobarRowSurface)
                    .border(
                        width = 0.5.dp,
                        color = if (autoScrollEnabled) PureWhite else FoobarDivider,
                        shape = RoundedCornerShape(4.dp)
                    )
                    .clickable { onToggleAutoScroll(!autoScrollEnabled) }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                    .testTag("lyrics_auto_scroll_toggle"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.VerticalAlignCenter,
                    contentDescription = stringResource(R.string.lyrics_auto_scroll),
                    tint = if (autoScrollEnabled) PureWhite else FoobarTextSecondary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(Modifier.width(5.dp))
                Text(
                    text = stringResource(R.string.lyrics_auto_scroll),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (autoScrollEnabled) PureWhite else FoobarTextSecondary
                )
            }
        }

        FoobarThinDivider()

        if (lyricsData.lines.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lyrics,
                        contentDescription = null,
                        tint = FoobarTextTertiary,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = stringResource(R.string.lyrics_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = FoobarTextSecondary
                    )
                }
            }
        } else {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(vertical = 24.dp, horizontal = 4.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("lyrics_lazy_column")
            ) {
                itemsIndexed(
                    items = lyricsData.lines,
                    key = { index, line -> "${index}_${line.startTimeMs}" }
                ) { index, line ->
                    val isActive = if (lyricsData.isSynced) index == activeIndex else true
                    Text(
                        text = line.text,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontSize = if (isActive) 18.sp else 15.sp,
                            lineHeight = if (isActive) 24.sp else 21.sp,
                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
                        ),
                        color = if (isActive) PureWhite else FoobarTextTertiary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .clickable(enabled = lyricsData.isSynced) {
                                onSeekToLine(line.startTimeMs)
                            }
                            .padding(vertical = 3.dp, horizontal = 4.dp)
                    )
                }
            }
        }
    }
}
