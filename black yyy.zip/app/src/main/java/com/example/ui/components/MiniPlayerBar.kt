package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.AudioOutputState
import com.example.model.Track
import com.example.ui.theme.BitPerfectEmerald
import com.example.ui.theme.FoobarDivider
import com.example.ui.theme.FoobarMiniPlayerTopBorder
import com.example.ui.theme.FoobarRowSurface
import com.example.ui.theme.FoobarTextPrimary
import com.example.ui.theme.FoobarTextSecondary
import com.example.ui.theme.PureWhite
import kotlinx.coroutines.flow.StateFlow

/**
 * foobar2000 Mobile Flat Docked Mini-Player:
 * - Docked flat at screen bottom (#0D0D0D) with 0.5.dp #333333 top divider
 * - Thin pure white seek progress bar along top edge (isolated recomposition scope)
 * - 44.dp square artwork (4.dp corner), title + compact tech spec, Play/Pause & Next
 */
@Composable
fun FoobarDockedMiniPlayer(
    track: Track,
    isPlaying: Boolean,
    durationMs: Long,
    positionMsFlow: StateFlow<Long>,
    audioOutputState: AudioOutputState,
    onExpandNowPlaying: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(FoobarRowSurface)
            .clickable(onClick = onExpandNowPlaying)
            .navigationBarsPadding()
            .testTag("docked_mini_player")
    ) {
        HorizontalDivider(
            thickness = 0.5.dp,
            color = FoobarMiniPlayerTopBorder
        )

        MiniPlayerEdgeProgressBar(
            positionMsFlow = positionMsFlow,
            durationMs = durationMs
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 4.dp, top = 7.dp, bottom = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlbumArtworkImage(
                artworkUri = track.albumArtUri,
                contentDescription = track.album,
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(4.dp))
            )

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    ),
                    color = FoobarTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                val dacTag = if (audioOutputState.isBitPerfectActive) " • BIT-PERFECT" else ""
                Text(
                    text = "${track.compactTechSummary}$dacTag",
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                    color = if (audioOutputState.isBitPerfectActive) BitPerfectEmerald else FoobarTextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(
                onClick = onTogglePlayPause,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("mini_player_play_pause")
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = PureWhite,
                    modifier = Modifier.size(26.dp)
                )
            }

            IconButton(
                onClick = onSkipNext,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("mini_player_next")
            ) {
                Icon(
                    imageVector = Icons.Rounded.SkipNext,
                    contentDescription = "Next Track",
                    tint = PureWhite,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}

@Composable
private fun MiniPlayerEdgeProgressBar(
    positionMsFlow: StateFlow<Long>,
    durationMs: Long
) {
    val positionMs by positionMsFlow.collectAsStateWithLifecycle()
    val progress = if (durationMs > 0L) {
        (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
    } else 0f

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(2.dp)
            .background(FoobarDivider)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(progress)
                .height(2.dp)
                .background(PureWhite)
        )
    }
}
