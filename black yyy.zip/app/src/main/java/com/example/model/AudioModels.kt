package com.example.model

import android.net.Uri

data class Track(
    val id: Long,
    val contentUriString: String,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val albumArtUri: Uri?,
    val durationMs: Long,
    val trackNumber: Int,
    val year: Int,
    val mimeType: String,
    val filePath: String,
    val folderName: String,
    val folderPath: String,
    val sampleRateHz: Int = 44100,
    val bitDepth: Int = 16,
    val codecLabel: String = "PCM",
    val bitrateKbps: Int = 0
) {
    val contentUri: Uri
        get() = Uri.parse(contentUriString)
    val formattedSampleRate: String
        get() {
            val khz = sampleRateHz / 1000.0
            return if (sampleRateHz % 1000 == 0) {
                "${sampleRateHz / 1000} kHz"
            } else {
                String.format(java.util.Locale.US, "%.1f kHz", khz)
            }
        }

    val formattedBitrate: String
        get() = when {
            bitrateKbps > 0 -> "$bitrateKbps kbps"
            codecLabel.equals("WAV", ignoreCase = true) || codecLabel.equals("PCM", ignoreCase = true) -> {
                val est = (sampleRateHz.toLong() * bitDepth * 2L / 1000L).toInt()
                if (est > 0) "$est kbps" else "-- kbps"
            }
            else -> "-- kbps"
        }

    val technicalSpecBadge: String
        get() = "$codecLabel • $formattedSampleRate / ${bitDepth}-bit"

    val compactTechSummary: String
        get() = "$artist • $codecLabel • $formattedSampleRate / ${bitDepth}-bit"
}

data class Album(
    val id: Long,
    val title: String,
    val artist: String,
    val artworkUri: Uri?,
    val year: Int,
    val tracks: List<Track>
)

data class Artist(
    val name: String,
    val albums: List<Album>,
    val tracks: List<Track>
)

data class MusicFolder(
    val name: String,
    val path: String,
    val tracks: List<Track>
)

enum class BlurMode(val title: String, val subtitle: String) {
    LIQUID_GLASS(
        title = "Liquid Glass (Live Haze Blur)",
        subtitle = "Real-time frosted glass blur with specular hairline edges"
    ),
    STATIC_FROSTED(
        title = "Static Frosted Blur",
        subtitle = "Balanced frosted surface without continuous blur pass"
    ),
    SOLID_DARK(
        title = "Off / Solid OLED",
        subtitle = "Pure OLED #000000 performance mode"
    )
}

enum class AccentColorMode(val title: String, val subtitle: String) {
    FOLLOW_DEVICE(
        title = "Follow Device",
        subtitle = "Material You dynamic color from Android system wallpaper"
    ),
    DYNAMIC_ALBUM_ART(
        title = "Dynamic Album Art",
        subtitle = "Adapts automatically to the currently playing cover art"
    ),
    CUSTOM(
        title = "Custom Palette",
        subtitle = "Choose from curated presets or craft your own color"
    )
}

enum class PlaybackMode(val title: String, val description: String) {
    NORMAL(
        title = "Normal",
        description = "Plays queue sequentially in order"
    ),
    SMART_CROSS_ALBUM_SHUFFLE(
        title = "Cross-Album Shuffle",
        description = "Smartly jumps across albums & artists without repeats"
    ),
    ALBUM_SHUFFLE(
        title = "Album Shuffle",
        description = "Plays full album 1→N, then picks another random album"
    )
}

enum class SleepTimerOption(val label: String, val minutes: Int?) {
    OFF("Off", null),
    MINUTES_15("15 minutes", 15),
    MINUTES_30("30 minutes", 30),
    MINUTES_45("45 minutes", 45),
    MINUTES_60("60 minutes", 60),
    END_OF_SONG("End of This Song", 0)
}

data class SleepTimerState(
    val activeOption: SleepTimerOption = SleepTimerOption.OFF,
    val remainingMs: Long = 0L,
    val isFadingOut: Boolean = false
)

data class AudioOutputState(
    val isUsbDacConnected: Boolean = false,
    val isBitPerfectActive: Boolean = false,
    val modeLabel: String = "SYSTEM MIXER",
    val deviceName: String = "Device Speaker",
    val sampleRateHz: Int = 48000,
    val bitDepth: Int = 16,
    val codecLabel: String = "PCM",
    val supportedProfiles: List<String> = emptyList(),
    val statusDetail: String = "Standard Android audio mixer active"
) {
    val formattedSampleRate: String
        get() = if (sampleRateHz % 1000 == 0) {
            "${sampleRateHz / 1000} kHz"
        } else {
            String.format(java.util.Locale.US, "%.1f kHz", sampleRateHz / 1000.0)
        }
}

data class LyricWord(
    val startTimeMs: Long,
    val endTimeMs: Long,
    val text: String
)

data class LyricLine(
    val startTimeMs: Long,
    val endTimeMs: Long,
    val text: String,
    val words: List<LyricWord> = emptyList()
)

data class LyricsData(
    val lines: List<LyricLine> = emptyList(),
    val isSynced: Boolean = false,
    val isWordSynced: Boolean = false,
    val sourceLabel: String = ""
)

data class PaletteColors(
    val color1: Int = 0xFFFA2D48.toInt(),
    val color2: Int = 0xFF4A1942.toInt(),
    val color3: Int = 0xFF1D3557.toInt(),
    val color4: Int = 0xFF0D0D16.toInt()
)
