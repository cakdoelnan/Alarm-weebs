package com.example.lyrics

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.SeekableByteChannel
import java.nio.charset.StandardCharsets

/**
 * Pure Kotlin read-only MP4/M4A atom parser that traverses:
 * moov -> udta -> meta -> ilst -> ©lyr -> data
 * to extract embedded lyrics from Apple ALAC (.m4a) and AAC (.m4a/.mp4) files
 * without altering the source file.
 */
object Mp4LyricsExtractor {

    private data class AtomHeader(
        val typeBytes: ByteArray,
        val payloadStart: Long,
        val endOffset: Long
    ) {
        val typeAscii: String
            get() = String(typeBytes, StandardCharsets.ISO_8859_1)

        fun matches(b0: Int, b1: Int, b2: Int, b3: Int): Boolean {
            return (typeBytes[0].toInt() and 0xFF) == b0 &&
                (typeBytes[1].toInt() and 0xFF) == b1 &&
                (typeBytes[2].toInt() and 0xFF) == b2 &&
                (typeBytes[3].toInt() and 0xFF) == b3
        }
    }

    fun extract(channel: SeekableByteChannel): String? {
        val fileSize = channel.size()
        val moov = findBox(channel, 0L, fileSize, 'm'.code, 'o'.code, 'o'.code, 'v'.code) ?: return null
        val udta = findBox(channel, moov.payloadStart, moov.endOffset, 'u'.code, 'd'.code, 't'.code, 'a'.code)
            ?: return null
        val meta = findBox(channel, udta.payloadStart, udta.endOffset, 'm'.code, 'e'.code, 't'.code, 'a'.code)
            ?: return null

        // Apple/ISO-BMFF 'meta' is a FullBox with 4 bytes of version/flags before children.
        // Verify whether the 4 bytes are version/flags or if a child box starts immediately.
        val metaChildrenStart = resolveMetaChildrenStart(channel, meta.payloadStart, meta.endOffset)
        val ilst = findBox(channel, metaChildrenStart, meta.endOffset, 'i'.code, 'l'.code, 's'.code, 't'.code)
            ?: return null

        // ©lyr atom: 0xA9, 'l', 'y', 'r'
        val lyr = findBox(channel, ilst.payloadStart, ilst.endOffset, 0xA9, 'l'.code, 'y'.code, 'r'.code)
            ?: return null

        val dataBox = findBox(channel, lyr.payloadStart, lyr.endOffset, 'd'.code, 'a'.code, 't'.code, 'a'.code)
            ?: return null

        // Inside 'data': 4 bytes type indicator + 4 bytes locale + payload
        val payloadLength = (dataBox.endOffset - dataBox.payloadStart).toInt()
        if (payloadLength <= 8 || payloadLength > 2 * 1024 * 1024) return null

        val dataBytes = readBytes(channel, dataBox.payloadStart, payloadLength) ?: return null
        val typeIndicator = ByteBuffer.wrap(dataBytes, 0, 4).order(ByteOrder.BIG_ENDIAN).int and 0x00FFFFFF
        val textOffset = 8
        val textLength = payloadLength - textOffset

        val raw = when (typeIndicator) {
            2 -> String(dataBytes, textOffset, textLength, StandardCharsets.UTF_16BE)
            else -> String(dataBytes, textOffset, textLength, StandardCharsets.UTF_8)
        }
        return raw.trim('\u0000', ' ', '\r', '\n').takeIf { it.isNotBlank() }
    }

    private fun resolveMetaChildrenStart(
        channel: SeekableByteChannel,
        start: Long,
        end: Long
    ): Long {
        if (start + 12 > end) return start
        val probe = readBytes(channel, start, 8) ?: return start
        val immediateType = String(probe, 4, 4, StandardCharsets.ISO_8859_1)
        if (immediateType == "hdlr" || immediateType == "ilst") {
            return start
        }
        return start + 4
    }

    private fun findBox(
        channel: SeekableByteChannel,
        rangeStart: Long,
        rangeEnd: Long,
        b0: Int,
        b1: Int,
        b2: Int,
        b3: Int
    ): AtomHeader? {
        var pos = rangeStart
        while (pos + 8 <= rangeEnd) {
            val header = readAtomHeader(channel, pos, rangeEnd) ?: break
            if (header.matches(b0, b1, b2, b3)) {
                return header
            }
            if (header.endOffset <= pos) break
            pos = header.endOffset
        }
        return null
    }

    private fun readAtomHeader(
        channel: SeekableByteChannel,
        offset: Long,
        limit: Long
    ): AtomHeader? {
        val buf = readBytes(channel, offset, 8) ?: return null
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.BIG_ENDIAN)
        val size32 = bb.int.toLong() and 0xFFFFFFFFL
        val typeBytes = buf.copyOfRange(4, 8)

        return when (size32) {
            0L -> AtomHeader(typeBytes, offset + 8, limit)
            1L -> {
                if (offset + 16 > limit) return null
                val ext = readBytes(channel, offset + 8, 8) ?: return null
                val size64 = ByteBuffer.wrap(ext).order(ByteOrder.BIG_ENDIAN).long
                if (size64 < 16) return null
                val end = (offset + size64).coerceAtMost(limit)
                AtomHeader(typeBytes, offset + 16, end)
            }
            else -> {
                if (size32 < 8) return null
                val end = (offset + size32).coerceAtMost(limit)
                AtomHeader(typeBytes, offset + 8, end)
            }
        }
    }

    private fun readBytes(channel: SeekableByteChannel, offset: Long, length: Int): ByteArray? {
        if (length <= 0 || offset < 0 || offset + length > channel.size()) return null
        channel.position(offset)
        val buffer = ByteBuffer.allocate(length)
        while (buffer.hasRemaining()) {
            val read = channel.read(buffer)
            if (read <= 0) break
        }
        return if (buffer.position() == length) buffer.array() else null
    }
}
