package com.example.lyrics

import com.example.model.LyricLine
import com.example.model.LyricWord
import com.example.model.LyricsData

/**
 * Pure Kotlin LRC parser supporting:
 * - Standard line-by-line LRC: [mm:ss.xx] or [mm:ss.xxx] (including multi-timestamp lines)
 * - Enhanced Word-by-Word LRC: [mm:ss.xx] <mm:ss.xx> word1 <mm:ss.xx> word2
 * - Unsynced plain lyrics fallback
 */
object LrcParser {

    private val lineTimestampRegex = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")
    private val wordTimestampRegex = Regex("""<(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?>""")
    private val metadataTagRegex = Regex("""^\[[a-zA-Z]+:.*]$""")

    fun parse(rawText: String, sourceLabel: String = "LRC"): LyricsData {
        if (rawText.isBlank()) return LyricsData()

        val rawLines = rawText.lines()
        val parsedSynced = mutableListOf<LyricLine>()
        val plainLines = mutableListOf<String>()
        var hasWordTimestamps = false

        for (raw in rawLines) {
            val trimmed = raw.trim()
            if (trimmed.isBlank()) continue
            if (metadataTagRegex.matches(trimmed)) continue

            val lineMatches = lineTimestampRegex.findAll(trimmed).toList()
            if (lineMatches.isEmpty()) {
                plainLines.add(trimmed)
                continue
            }

            val contentStart = lineMatches.last().range.last + 1
            val content = if (contentStart < trimmed.length) trimmed.substring(contentStart).trim() else ""
            if (content.isBlank()) continue

            val words = parseEnhancedWords(content)
            if (words.isNotEmpty()) {
                hasWordTimestamps = true
            }
            val cleanText = if (words.isNotEmpty()) {
                words.joinToString(" ") { it.text }.trim()
            } else {
                content.replace(wordTimestampRegex, "").trim()
            }
            if (cleanText.isBlank()) continue

            for (match in lineMatches) {
                val tsMs = parseTimestampMs(match)
                val lineWords = if (words.isNotEmpty()) {
                    // Shift word timestamps relative to this line occurrence if multi-timestamped
                    val delta = tsMs - lineMatches.first().let(::parseTimestampMs)
                    words.map { w ->
                        w.copy(
                            startTimeMs = (w.startTimeMs + delta).coerceAtLeast(0L),
                            endTimeMs = (w.endTimeMs + delta).coerceAtLeast(0L)
                        )
                    }
                } else emptyList()

                parsedSynced.add(
                    LyricLine(
                        startTimeMs = tsMs,
                        endTimeMs = tsMs + 3500L,
                        text = cleanText,
                        words = lineWords
                    )
                )
            }
        }

        if (parsedSynced.isNotEmpty()) {
            val sorted = parsedSynced.sortedBy { it.startTimeMs }
            val resolved = sorted.mapIndexed { idx, line ->
                val nextStart = sorted.getOrNull(idx + 1)?.startTimeMs
                val endMs = if (nextStart != null && nextStart > line.startTimeMs) {
                    nextStart
                } else {
                    val lastWordEnd = line.words.lastOrNull()?.endTimeMs ?: 0L
                    maxOf(line.startTimeMs + 3500L, lastWordEnd)
                }
                val resolvedWords = if (line.words.isNotEmpty()) {
                    line.words.mapIndexed { wIdx, w ->
                        val nextWordStart = line.words.getOrNull(wIdx + 1)?.startTimeMs ?: endMs
                        w.copy(endTimeMs = nextWordStart.coerceAtLeast(w.startTimeMs + 180L))
                    }
                } else emptyList()

                line.copy(endTimeMs = endMs, words = resolvedWords)
            }

            return LyricsData(
                lines = resolved,
                isSynced = true,
                isWordSynced = hasWordTimestamps,
                sourceLabel = sourceLabel
            )
        }

        val unsyncedLines = plainLines.map {
            LyricLine(startTimeMs = 0L, endTimeMs = 0L, text = it)
        }
        return LyricsData(
            lines = unsyncedLines,
            isSynced = false,
            isWordSynced = false,
            sourceLabel = sourceLabel
        )
    }

    private fun parseEnhancedWords(content: String): List<LyricWord> {
        val matches = wordTimestampRegex.findAll(content).toList()
        if (matches.isEmpty()) return emptyList()

        val result = mutableListOf<LyricWord>()
        for (i in matches.indices) {
            val match = matches[i]
            val startMs = parseTimestampMs(match)
            val textStart = match.range.last + 1
            val textEnd = if (i + 1 < matches.size) matches[i + 1].range.first else content.length
            val wordText = content.substring(textStart, textEnd).trim()
            if (wordText.isNotEmpty()) {
                val nextMs = matches.getOrNull(i + 1)?.let(::parseTimestampMs) ?: (startMs + 450L)
                result.add(
                    LyricWord(
                        startTimeMs = startMs,
                        endTimeMs = nextMs.coerceAtLeast(startMs + 120L),
                        text = wordText
                    )
                )
            }
        }
        return result
    }

    private fun parseTimestampMs(match: MatchResult): Long {
        val minutes = match.groupValues[1].toLongOrNull() ?: 0L
        val seconds = match.groupValues[2].toLongOrNull() ?: 0L
        val fractionStr = match.groupValues.getOrNull(3).orEmpty()
        val millis = when (fractionStr.length) {
            0 -> 0L
            1 -> (fractionStr.toLongOrNull() ?: 0L) * 100L
            2 -> (fractionStr.toLongOrNull() ?: 0L) * 10L
            else -> fractionStr.take(3).toLongOrNull() ?: 0L
        }
        return minutes * 60_000L + seconds * 1_000L + millis
    }
}
