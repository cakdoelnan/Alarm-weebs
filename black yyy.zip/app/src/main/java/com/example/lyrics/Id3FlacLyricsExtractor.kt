package com.example.lyrics

import com.example.model.LyricLine
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.SeekableByteChannel
import java.nio.charset.Charset
import java.nio.charset.StandardCharsets

/**
 * Pure Kotlin read-only extractor for:
 * - MP3 ID3v2.3 / ID3v2.4 USLT (Unsynchronised lyrics) & SYLT (Synchronised lyrics)
 * - FLAC VORBIS_COMMENT (LYRICS / UNSYNCEDLYRICS / SYNCEDLYRICS)
 */
object Id3FlacLyricsExtractor {

    data class ExtractedEmbeddedLyrics(
        val rawText: String? = null,
        val syltLines: List<LyricLine>? = null,
        val sourceLabel: String = ""
    )

    fun extract(channel: SeekableByteChannel): ExtractedEmbeddedLyrics? {
        val fileSize = channel.size()
        if (fileSize < 12) return null

        val magic = readBytes(channel, 0L, 4) ?: return null
        return when {
            magic[0] == 'I'.code.toByte() &&
                magic[1] == 'D'.code.toByte() &&
                magic[2] == '3'.code.toByte() -> extractId3v2(channel)

            magic[0] == 'f'.code.toByte() &&
                magic[1] == 'L'.code.toByte() &&
                magic[2] == 'a'.code.toByte() &&
                magic[3] == 'C'.code.toByte() -> extractFlacVorbisLyrics(channel)

            else -> null
        }
    }

    private fun extractId3v2(channel: SeekableByteChannel): ExtractedEmbeddedLyrics? {
        val header = readBytes(channel, 0L, 10) ?: return null
        val majorVersion = header[3].toInt() and 0xFF
        if (majorVersion !in 3..4) return null

        val flags = header[5].toInt() and 0xFF
        val tagSize = readSynchSafeInt(header, 6)
        if (tagSize <= 0) return null

        var pos = 10L
        val tagEnd = (10L + tagSize).coerceAtMost(channel.size())

        // Skip extended header if present
        if ((flags and 0x40) != 0 && pos + 4 <= tagEnd) {
            val extHeader = readBytes(channel, pos, 4) ?: return null
            val extSize = if (majorVersion == 4) {
                readSynchSafeInt(extHeader, 0)
            } else {
                ByteBuffer.wrap(extHeader).order(ByteOrder.BIG_ENDIAN).int + 4
            }
            if (extSize > 0) pos += extSize
        }

        var usltText: String? = null
        var syltLines: List<LyricLine>? = null

        while (pos + 10 <= tagEnd) {
            val frameHeader = readBytes(channel, pos, 10) ?: break
            if (frameHeader[0] == 0.toByte()) break // padding

            val frameId = String(frameHeader, 0, 4, StandardCharsets.US_ASCII)
            val frameSize = if (majorVersion == 4) {
                readSynchSafeInt(frameHeader, 4)
            } else {
                ByteBuffer.wrap(frameHeader, 4, 4).order(ByteOrder.BIG_ENDIAN).int
            }
            if (frameSize <= 0 || frameSize > 4 * 1024 * 1024) break

            val frameStart = pos + 10
            val frameEnd = (frameStart + frameSize).coerceAtMost(tagEnd)

            if (frameId == "SYLT" && syltLines == null) {
                val payload = readBytes(channel, frameStart, (frameEnd - frameStart).toInt())
                if (payload != null) {
                    syltLines = parseSyltFrame(payload)
                }
            } else if (frameId == "USLT" && usltText == null) {
                val payload = readBytes(channel, frameStart, (frameEnd - frameStart).toInt())
                if (payload != null) {
                    usltText = parseUsltFrame(payload)
                }
            }

            pos = frameEnd
            if (syltLines != null && usltText != null) break
        }

        return when {
            !syltLines.isNullOrEmpty() -> ExtractedEmbeddedLyrics(
                syltLines = syltLines,
                sourceLabel = "Embedded ID3 SYLT"
            )
            !usltText.isNullOrBlank() -> ExtractedEmbeddedLyrics(
                rawText = usltText,
                sourceLabel = "Embedded ID3 USLT"
            )
            else -> null
        }
    }

    internal fun parseUsltFrame(payload: ByteArray): String? {
        if (payload.size < 5) return null
        val encodingByte = payload[0].toInt() and 0xFF
        // Bytes 1..3: language (e.g., "eng")
        val charset = id3Charset(encodingByte)
        val isTwoByte = encodingByte == 1 || encodingByte == 2

        val descriptorStart = 4
        val textStart = findNullTerminatorEnd(payload, descriptorStart, isTwoByte)
        if (textStart >= payload.size) return null

        val raw = decodeId3String(payload, textStart, payload.size - textStart, encodingByte, charset)
        return raw.trim('\u0000', ' ', '\r', '\n').takeIf { it.isNotBlank() }
    }

    internal fun parseSyltFrame(payload: ByteArray): List<LyricLine>? {
        if (payload.size < 7) return null
        val encodingByte = payload[0].toInt() and 0xFF
        // Bytes 1..3: language, Byte 4: timestamp format (2 = ms), Byte 5: content type
        val timestampFormat = payload[4].toInt() and 0xFF
        if (timestampFormat != 2) return null

        val isTwoByte = encodingByte == 1 || encodingByte == 2
        val charset = id3Charset(encodingByte)
        var cursor = findNullTerminatorEnd(payload, 6, isTwoByte)

        val entries = mutableListOf<Pair<Long, String>>()
        while (cursor < payload.size) {
            val strEnd = findNullTerminatorStart(payload, cursor, isTwoByte)
            val chunk = decodeId3String(payload, cursor, strEnd - cursor, encodingByte, charset)
            val afterNull = findNullTerminatorEnd(payload, cursor, isTwoByte)
            if (afterNull + 4 > payload.size) break

            val tsMs = ByteBuffer.wrap(payload, afterNull, 4).order(ByteOrder.BIG_ENDIAN).int.toLong() and 0xFFFFFFFFL
            if (chunk.isNotBlank()) {
                entries.add(tsMs to chunk.trim('\u0000', '\r', '\n'))
            }
            cursor = afterNull + 4
        }

        if (entries.isEmpty()) return null
        val sorted = entries.sortedBy { it.first }
        return sorted.mapIndexed { index, (startMs, text) ->
            val endMs = sorted.getOrNull(index + 1)?.first ?: (startMs + 4000L)
            LyricLine(
                startTimeMs = startMs,
                endTimeMs = endMs.coerceAtLeast(startMs + 400L),
                text = text
            )
        }
    }

    private fun extractFlacVorbisLyrics(channel: SeekableByteChannel): ExtractedEmbeddedLyrics? {
        var pos = 4L
        val fileSize = channel.size()

        while (pos + 4 <= fileSize) {
            val blockHeader = readBytes(channel, pos, 4) ?: break
            val isLast = (blockHeader[0].toInt() and 0x80) != 0
            val blockType = blockHeader[0].toInt() and 0x7F
            val blockSize = ((blockHeader[1].toInt() and 0xFF) shl 16) or
                ((blockHeader[2].toInt() and 0xFF) shl 8) or
                (blockHeader[3].toInt() and 0xFF)

            val dataStart = pos + 4
            val dataEnd = (dataStart + blockSize).coerceAtMost(fileSize)

            if (blockType == 4 && blockSize in 8..(4 * 1024 * 1024)) { // VORBIS_COMMENT
                val data = readBytes(channel, dataStart, blockSize)
                if (data != null) {
                    val lyrics = parseVorbisCommentsForLyrics(data)
                    if (!lyrics.isNullOrBlank()) {
                        return ExtractedEmbeddedLyrics(
                            rawText = lyrics,
                            sourceLabel = "Embedded FLAC Tag"
                        )
                    }
                }
                break
            }

            pos = dataEnd
            if (isLast || blockSize <= 0) break
        }
        return null
    }

    internal fun parseVorbisCommentsForLyrics(data: ByteArray): String? {
        if (data.size < 8) return null
        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val vendorLen = bb.int
        if (vendorLen < 0 || bb.position() + vendorLen + 4 > data.size) return null
        bb.position(bb.position() + vendorLen)
        val commentCount = bb.int
        if (commentCount <= 0 || commentCount > 2000) return null

        var syncedFallback: String? = null
        var unsyncedFallback: String? = null

        for (i in 0 until commentCount) {
            if (bb.remaining() < 4) break
            val len = bb.int
            if (len <= 0 || len > bb.remaining()) break
            val commentBytes = ByteArray(len)
            bb.get(commentBytes)
            val comment = String(commentBytes, StandardCharsets.UTF_8)
            val eqIdx = comment.indexOf('=')
            if (eqIdx <= 0) continue

            val key = comment.substring(0, eqIdx).uppercase()
            val value = comment.substring(eqIdx + 1).trim()
            if (value.isBlank()) continue

            when (key) {
                "SYNCEDLYRICS" -> syncedFallback = value
                "LYRICS" -> if (syncedFallback == null) syncedFallback = value
                "UNSYNCEDLYRICS", "UNSYNCED LYRICS" -> if (unsyncedFallback == null) unsyncedFallback = value
            }
        }
        return syncedFallback ?: unsyncedFallback
    }

    private fun readSynchSafeInt(bytes: ByteArray, offset: Int): Int {
        return ((bytes[offset].toInt() and 0x7F) shl 21) or
            ((bytes[offset + 1].toInt() and 0x7F) shl 14) or
            ((bytes[offset + 2].toInt() and 0x7F) shl 7) or
            (bytes[offset + 3].toInt() and 0x7F)
    }

    private fun id3Charset(encodingByte: Int): Charset {
        return when (encodingByte) {
            0 -> StandardCharsets.ISO_8859_1
            1 -> StandardCharsets.UTF_16
            2 -> StandardCharsets.UTF_16BE
            else -> StandardCharsets.UTF_8
        }
    }

    private fun findNullTerminatorStart(data: ByteArray, start: Int, twoByte: Boolean): Int {
        var i = start
        if (twoByte) {
            while (i + 1 < data.size) {
                if (data[i] == 0.toByte() && data[i + 1] == 0.toByte()) return i
                i += 2
            }
        } else {
            while (i < data.size) {
                if (data[i] == 0.toByte()) return i
                i++
            }
        }
        return data.size
    }

    private fun findNullTerminatorEnd(data: ByteArray, start: Int, twoByte: Boolean): Int {
        val term = findNullTerminatorStart(data, start, twoByte)
        return if (term >= data.size) data.size else term + if (twoByte) 2 else 1
    }

    private fun decodeId3String(
        data: ByteArray,
        offset: Int,
        length: Int,
        encodingByte: Int,
        charset: Charset
    ): String {
        if (length <= 0 || offset >= data.size) return ""
        val safeLen = length.coerceAtMost(data.size - offset)
        return if (encodingByte == 1 && safeLen >= 2) {
            // Respect BOM
            val b0 = data[offset].toInt() and 0xFF
            val b1 = data[offset + 1].toInt() and 0xFF
            when {
                b0 == 0xFF && b1 == 0xFE -> String(data, offset + 2, safeLen - 2, StandardCharsets.UTF_16LE)
                b0 == 0xFE && b1 == 0xFF -> String(data, offset + 2, safeLen - 2, StandardCharsets.UTF_16BE)
                else -> String(data, offset, safeLen, StandardCharsets.UTF_16)
            }
        } else {
            String(data, offset, safeLen, charset)
        }
    }

    private fun readBytes(channel: SeekableByteChannel, offset: Long, length: Int): ByteArray? {
        if (length <= 0 || offset < 0 || offset + length > channel.size()) return null
        channel.position(offset)
        val buffer = ByteBuffer.allocate(length)
        while (buffer.hasRemaining()) {
            val read = channel.read(buffer)
            if (read <= 0) break
        }
        return if (buffer.position() == length) buffer.array() else null
    }
}
