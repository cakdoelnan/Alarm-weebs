package com.example.lyrics

import android.content.Context
import android.util.Log
import com.example.model.LyricsData
import com.example.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.nio.channels.FileChannel

class LyricsRepository(private val context: Context) {

    suspend fun loadLyrics(track: Track): LyricsData = withContext(Dispatchers.IO) {
        // 1. Check external .lrc file with same basename in same folder
        findSiblingLrcFile(track.filePath)?.let { lrcFile ->
            runCatching {
                val text = lrcFile.readText(Charsets.UTF_8)
                val parsed = LrcParser.parse(text, sourceLabel = "External .LRC")
                if (parsed.lines.isNotEmpty()) return@withContext parsed
            }.onFailure {
                Log.w(TAG, "Failed reading external LRC ${lrcFile.name}: ${it.message}")
            }
        }

        // 2. Try direct file channel first (faster & supports seekable random access), then ContentResolver PFD
        val fromDirectFile = track.filePath.takeIf { it.isNotBlank() }?.let { path ->
            val file = File(path)
            if (file.exists() && file.canRead()) {
                runCatching {
                    FileInputStream(file).channel.use { ch ->
                        extractFromChannel(ch, track)
                    }
                }.getOrNull()
            } else null
        }
        if (fromDirectFile != null && fromDirectFile.lines.isNotEmpty()) {
            return@withContext fromDirectFile
        }

        // 3. ContentResolver ParcelFileDescriptor fallback (handles scoped storage / OpenDocument URIs)
        runCatching {
            context.contentResolver.openFileDescriptor(track.contentUri, "r")?.use { pfd ->
                FileInputStream(pfd.fileDescriptor).channel.use { ch ->
                    extractFromChannel(ch, track)?.let {
                        if (it.lines.isNotEmpty()) return@withContext it
                    }
                }
            }
        }.onFailure {
            Log.w(TAG, "ContentResolver PFD lyric extraction skipped: ${it.message}")
        }

        LyricsData()
    }

    private fun extractFromChannel(channel: FileChannel, track: Track): LyricsData? {
        val ext = track.filePath.substringAfterLast('.', "").lowercase()
        val mime = track.mimeType.lowercase()

        // Try MP4/M4A atom parser first for m4a/alac/mp4/aac
        if (ext in listOf("m4a", "mp4", "alac", "aac") || mime.contains("mp4") || mime.contains("m4a")) {
            Mp4LyricsExtractor.extract(channel)?.let { raw ->
                val parsed = LrcParser.parse(raw, sourceLabel = "Embedded M4A ©lyr")
                if (parsed.lines.isNotEmpty()) return parsed
            }
        }

        // Try ID3v2 (MP3) or FLAC Vorbis comments
        Id3FlacLyricsExtractor.extract(channel)?.let { extracted ->
            extracted.syltLines?.let { sylt ->
                if (sylt.isNotEmpty()) {
                    return LyricsData(
                        lines = sylt,
                        isSynced = true,
                        isWordSynced = false,
                        sourceLabel = extracted.sourceLabel
                    )
                }
            }
            extracted.rawText?.let { raw ->
                val parsed = LrcParser.parse(raw, sourceLabel = extracted.sourceLabel)
                if (parsed.lines.isNotEmpty()) return parsed
            }
        }

        return null
    }

    private fun findSiblingLrcFile(audioPath: String): File? {
        if (audioPath.isBlank()) return null
        val audioFile = File(audioPath)
        val parent = audioFile.parentFile ?: return null
        if (!parent.exists() || !parent.canRead()) return null
        val baseName = audioFile.nameWithoutExtension
        val candidates = listOf(
            File(parent, "$baseName.lrc"),
            File(parent, "$baseName.LRC")
        )
        return candidates.firstOrNull { it.exists() && it.isFile && it.canRead() }
    }

    companion object {
        private const val TAG = "LyricsRepository"
    }
}
